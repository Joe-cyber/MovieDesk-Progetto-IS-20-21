package org.movied.model.bean;

import java.util.ArrayList;

/**
 * 
 * This class describe a registered user 
 *
 */

public class UtenteRegistrato {
	private String nome;
	private String cognome;
	private String email;
	private String password;
	private String tipo;
	private ArrayList<Contenuto> preferiti;
	private ArrayList<Contenuto> piaciuti;
	private ArrayList<Contenuto> visti;
	
	public UtenteRegistrato(String email,String nome, String cognome, String password, ArrayList<Contenuto> preferiti, ArrayList<Contenuto> piaciuti, ArrayList<Contenuto> visti, String tipo) {
		this.nome = nome;
		this.cognome = cognome;
		this.email = email;
		this.password = password;
		this.preferiti = preferiti;
		this.piaciuti = piaciuti;
		this.visti = visti;
		this.tipo=tipo;
	}

	public UtenteRegistrato(String email,String nome, String cognome, String password, String tipo) {
		this.nome = nome;
		this.cognome = cognome;
		this.email = email;
		this.password = password;
		this.tipo=tipo;
	}

	public UtenteRegistrato(String email,String nome, String cognome,  ArrayList<Contenuto> preferiti, ArrayList<Contenuto> piaciuti, ArrayList<Contenuto> visti, String tipo) {
		this.nome = nome;
		this.cognome = cognome;
		this.email = email;
		this.preferiti = preferiti;
		this.piaciuti = piaciuti;
		this.visti = visti;
		this.tipo=tipo;
	}

	/**
	 * 
	 * @return the user's name
	 */
	public String getNome() {
		return nome;
	}

	/**
	 * 
	 * @param nome
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}

	/**
	 * 
	 * @return the user's surname
	 */
	public String getCognome() {
		return cognome;
	}

	/**
	 * 
	 * @param cognome
	 */
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	/**
	 * 
	 * @return the user's email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * 
	 * @param email
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * 
	 * @return the user's password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * 
	 * @param password 
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * 
	 * @return the user's preferred contents
	 */
	public ArrayList<Contenuto> getPreferiti() {
		return preferiti;
	}

	/**
	 * 
	 * @param preferiti
	 */
	public void setPreferiti(ArrayList<Contenuto> preferiti) {
		this.preferiti = preferiti;
	}

	/**
	 * 
	 * @return the user's liked contents
	 */
	public ArrayList<Contenuto> getPiaciuti() {
		return piaciuti;
	}

	/**
	 * 
	 * @param piaciuti
	 */
	public void setPiaciuti(ArrayList<Contenuto> piaciuti) {
		this.piaciuti = piaciuti;
	}

	/**
	 *  
	 * @return the user's seen contents
	 */
	public ArrayList<Contenuto> getVisti() {
		return visti;
	}

	/**
	 * 
	 * @param visti 
	 */
	public void setVisti(ArrayList<Contenuto> visti) {
		this.visti = visti;
	}
	
	/**
	 * 
	 * @return the user's type
	 */
	public String getTipo() {
		return tipo;
	}

	/**
	 * 
	 * @param tipo
	 */
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	@Override
	public String toString() {
		return getClass().getName()+" [nome=" + nome + ", cognome=" + cognome + ", email=" + email +  ", password=" + password + ", preferiti=" + preferiti + ", piaciuti=" + piaciuti
				+ ", visti=" + visti + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UtenteRegistrato other = (UtenteRegistrato) obj;
		if (cognome == null) {
			if (other.cognome != null)
				return false;
		} else if (!cognome.equals(other.cognome))
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		if (piaciuti == null) {
			if (other.piaciuti != null)
				return false;
		} else if (!piaciuti.equals(other.piaciuti))
			return false;
		if (preferiti == null) {
			if (other.preferiti != null)
				return false;
		} else if (!preferiti.equals(other.preferiti))
			return false;
		if (tipo == null) {
			if (other.tipo != null)
				return false;
		} else if (!tipo.equals(other.tipo))
			return false;
		if (visti == null) {
			if (other.visti != null)
				return false;
		} else if (!visti.equals(other.visti))
			return false;
		return true;
	}
	
}
