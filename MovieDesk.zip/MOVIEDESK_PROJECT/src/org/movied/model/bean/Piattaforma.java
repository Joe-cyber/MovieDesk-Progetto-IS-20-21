package org.movied.model.bean;
/**
 * 
 * This class describe platforms that offer streaming
 *
 */
public class Piattaforma {
	private String imgPiattaforma;
	private String nome;
	private String link;
	private Float abbonamentoMinimo;
	
	public Piattaforma(String imgPiattaforma, String nome, String link, Float abbonamentoMinimo) {
		this.imgPiattaforma = imgPiattaforma;
		this.nome = nome;
		this.link = link;
		this.abbonamentoMinimo = abbonamentoMinimo;
	}

	/**
	 * 
	 * @return the platform's link image
	 */
	public String getImgPiattaforma() {
		return imgPiattaforma;
	}

	/**
	 * 
	 * @param imgPiattaforma
	 */
	public void setImgPiattaforma(String imgPiattaforma) {
		this.imgPiattaforma = imgPiattaforma;
	}
	/**
	 * 
	 * @return the platform's name 
	 */
	public String getNome() {
		return nome;
	}

	/**
	 * 
	 * @param nome
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}

	/**
	 * 
	 * @return the platform's link
	 */
	public String getLink() {
		return link;
	}

	/**
	 * 
	 * @param link
	 */
	public void setLink(String link) {
		this.link = link;
	}

	/**
	 * 
	 * @return the platform's minimum subscription
	 */
	public Float getAbbonamentoMinimo() {
		return abbonamentoMinimo;
	}

	/**
	 * 
	 * @param abbonamentoMinimo
	 */
	public void setAbbonamentoMinimo(Float abbonamentoMinimo) {
		this.abbonamentoMinimo = abbonamentoMinimo;
	}

	@Override
	public String toString() {
		return getClass().getName()+" [imgPiattaforma=" + imgPiattaforma + ", nome=" + nome + ", link=" + link
				+ ", abbonamentoMinimo=" + abbonamentoMinimo + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Piattaforma other = (Piattaforma) obj;
		if (abbonamentoMinimo == null) {
			if (other.abbonamentoMinimo != null)
				return false;
		} else if (!abbonamentoMinimo.equals(other.abbonamentoMinimo))
			return false;
		if (imgPiattaforma == null) {
			if (other.imgPiattaforma != null)
				return false;
		} else if (!imgPiattaforma.equals(other.imgPiattaforma))
			return false;
		if (link == null) {
			if (other.link != null)
				return false;
		} else if (!link.equals(other.link))
			return false;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		return true;
	}

	
}
