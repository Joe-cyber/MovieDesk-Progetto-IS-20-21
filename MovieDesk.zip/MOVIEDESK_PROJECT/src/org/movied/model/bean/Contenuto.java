package org.movied.model.bean;

import java.util.ArrayList;

/**
 * 
 * This class describe a generic multimedia content
 * 
 */

public abstract class Contenuto {
	private Integer idContenuto;
	private String titolo;
	private String anno;
	private String sinossi;
	private String cast;
	private String imgCopertina;
	private String trailer;
	private Integer miPiace;
	private Float valutazione;
	private ArrayList<Genere> generi;
	private ArrayList<Piattaforma> piattaforme;
	
	public Contenuto(Integer idContenuto, String titolo, String anno, String sinossi, String cast, String imgCopertina, String trailer, ArrayList<Genere> generi, ArrayList<Piattaforma> piattaforme, Integer miPiace,Float valutazione) {
		this.idContenuto = idContenuto;
		this.titolo = titolo;
		this.anno = anno;
		this.sinossi = sinossi;
		this.cast = cast;
		this.imgCopertina = imgCopertina;
		this.trailer = trailer;
		this.generi = generi;
		this.piattaforme = piattaforme;
		this.miPiace=miPiace;
		this.valutazione=valutazione;
	}

	public Contenuto(Integer idContenuto, String titolo, String sinossi, String cast, String imgCopertina, ArrayList<Genere> generi, ArrayList<Piattaforma> piattaforme, Integer miPiace,Float valutazione) {
		this.idContenuto = idContenuto;
		this.titolo = titolo;
		this.anno="-";
		this.sinossi = sinossi;
		this.cast = cast;
		this.imgCopertina = imgCopertina;
		this.trailer="Trailer not found :(";
		this.generi = generi;
		this.piattaforme = piattaforme;
		this.miPiace=miPiace;
		this.valutazione=valutazione;
	}

	public Contenuto(Integer idContenuto, String titolo, String sinossi, String cast, String imgCopertina, String trailer, ArrayList<Genere> generi, ArrayList<Piattaforma> piattaforme, Integer miPiace,Float valutazione) {
		this.idContenuto = idContenuto;
		this.titolo = titolo;
		this.anno="-";
		this.sinossi = sinossi;
		this.cast = cast;
		this.imgCopertina = imgCopertina;
		this.trailer = trailer;
		this.generi = generi;
		this.piattaforme = piattaforme;
		this.miPiace=miPiace;
		this.valutazione=valutazione;
	}
	
	public Contenuto(Integer idContenuto, String titolo, String anno, String sinossi, String cast, ArrayList<Genere> generi, String imgCopertina, ArrayList<Piattaforma> piattaforme, Integer miPiace,Float valutazione) {
		this.idContenuto = idContenuto;
		this.titolo = titolo;
		this.anno = anno;
		this.sinossi = sinossi;
		this.cast = cast;
		this.imgCopertina = imgCopertina;
		this.trailer="Trailer not found :(";
		this.generi = generi;
		this.piattaforme = piattaforme;
		this.miPiace=miPiace;
		this.valutazione=valutazione;
	}
	/**
	 * 
	 * @return the content's id 
	 */
	public Integer getIdContenuto() {
		return idContenuto;
	}
	/**
	 * 
	 * @param idContenuto 
	 */
	public void setIdContenuto(Integer idContenuto) {
		this.idContenuto = idContenuto;
	}

	/**
	 * 
	 * @return the content's title
	 */
	public String getTitolo() {
		return titolo;
	}

	/**
	 * 
	 * @return the content's valuation 
	 */
	public Float getValutazione() {
		return valutazione;
	}

	/**
	 * 
	 * @param valutazione
	 */
	public void setValutazione(Float valutazione) {
		this.valutazione = valutazione;
	}

	/**
	 * 
	 * @param titolo
	 */
	public void setTitolo(String titolo) {
		this.titolo = titolo;
	}

	/**
	 * 
	 * @return the content's  year of production 
	 */
	public String getAnno() {
		return anno;
	}

	/**
	 * 
	 * @param anno
	 */
	public void setAnno(String anno) {
		this.anno = anno;
	}

	/**
	 * 
	 * @return the content's synopsis
	 */
	public String getSinossi() {
		return sinossi;
	}

	/**
	 * 
	 * @param sinossi 
	 */
	public void setSinossi(String sinossi) {
		this.sinossi = sinossi;
	}
	
	/**
	 * 
	 * @return the content's number of the like 
	 */
	public Integer getMiPiace() {
		return miPiace;
	}

	/**
	 * 
	 * @param miPiace
	 */
	public void setMiPiace(Integer miPiace) {
		this.miPiace = miPiace;
	}

	/**
	 *  
	 * @return the content's cast 
	 */
	public String getCast() {
		return cast;
	}

	/**
	 * 
	 * @param cast
	 */
	public void setCast(String cast) {
		this.cast = cast;
	}

	/**
	 * 
	 * @return the link of the content's image  
	 */
	public String getImgCopertina() {
		return imgCopertina;
	}

	/**
	 * 
	 * @param imgCopertina
	 */
	public void setImgCopertina(String imgCopertina) {
		this.imgCopertina = imgCopertina;
	}

	/**
	 * 
	 * @return the content's link trailer
	 */
	public String getTrailer() {
		return trailer;
	}
	/**
	 * 
	 * @param trailer 
	 */
	public void setTrailer(String trailer) {
		this.trailer = trailer;
	}

	/**
	 * 
	 * @return the content's genres
	 */
	public ArrayList<Genere> getGeneri() {
		return generi;
	}

	/**
	 * 
	 * @param generi
	 */
	public void setGeneri(ArrayList<Genere> generi) {
		this.generi = generi;
	}

	/**
	 * 
	 * @return the content's platforms
	 */
	public ArrayList<Piattaforma> getPiattaforme() {
		return piattaforme;
	}

	/**
	 * 
	 * @param piattaforme
	 */
	public void setPiattaforme(ArrayList<Piattaforma> piattaforme) {
		this.piattaforme = piattaforme;
	}
	
	

	@Override
	public String toString() {
		return getClass().getName()+"[idContenuto=" + idContenuto + ", titolo=" + titolo + ", anno=" + anno + ", sinossi="
				+ sinossi + ", cast=" + cast + ", imgCopertina=" + imgCopertina + ", trailer=" + trailer + ", miPiace="
				+ miPiace + ", generi=" + generi + ", piattaforme=" + piattaforme + "]";
	}



	/**
	 * This is a list of movie genre.
	 */
	
	public enum Genere{ Anime, Drammatico, Bambini, Crime, Romantico, Film, Commedia, Horror, Fantascienza, Fantasy, Documentario }

	@Override
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Contenuto other = (Contenuto) obj;
		if (anno == null) {
			if (other.anno != null)
				return false;
		} else if (!anno.equals(other.anno))
			return false;
		if (cast == null) {
			if (other.cast != null)
				return false;
		} else if (!cast.equals(other.cast))
			return false;
		if (generi == null) {
			if (other.generi != null)
				return false;
		} else if (!generi.equals(other.generi))
			return false;
		if (idContenuto == null) {
			if (other.idContenuto != null)
				return false;
		} else if (!idContenuto.equals(other.idContenuto))
			return false;
		if (imgCopertina == null) {
			if (other.imgCopertina != null)
				return false;
		} else if (!imgCopertina.equals(other.imgCopertina))
			return false;
		if (miPiace == null) {
			if (other.miPiace != null)
				return false;
		} else if (!miPiace.equals(other.miPiace))
			return false;
		if (piattaforme == null) {
			if (other.piattaforme != null)
				return false;
		} else if (!piattaforme.equals(other.piattaforme))
			return false;
		if (sinossi == null) {
			if (other.sinossi != null)
				return false;
		} else if (!sinossi.equals(other.sinossi))
			return false;
		if (titolo == null) {
			if (other.titolo != null)
				return false;
		} else if (!titolo.equals(other.titolo))
			return false;
		if (trailer == null) {
			if (other.trailer != null)
				return false;
		} else if (!trailer.equals(other.trailer))
			return false;
		if (valutazione == null) {
			if (other.valutazione != null)
				return false;
		} else if (!valutazione.equals(other.valutazione))
			return false;
		return true;
	}
	
}
