package org.movied.model.bean;

import java.util.ArrayList;

/**
 * 
 * This class describe a tv series content
 *
 */
public class SerieTv extends Contenuto{
	private String stagioni;
	private String puntate;
	private Float durataEpisodio;
	
	public SerieTv(Integer idContenuto, String titolo, String anno, String sinossi, String cast, String imgCopertina, String trailer, ArrayList<Genere> generi, ArrayList<Piattaforma> piattaforme, String stagioni, String puntate, Float durataEpisodio, Integer miPiace, Float valutazione) {
		super(idContenuto, titolo, anno, sinossi, cast, imgCopertina, trailer, generi, piattaforme, miPiace, valutazione);
		this.stagioni=stagioni;
		this.puntate=puntate;
		this.durataEpisodio=durataEpisodio;
	}	
		
	public SerieTv(Integer idContenuto, String titolo, String sinossi, String cast, String imgCopertina, String trailer, ArrayList<Genere> generi, ArrayList<Piattaforma> piattaforme, String stagioni, String puntate, Float durataEpisodio, Integer miPiace, Float valutazione) {
		super(idContenuto, titolo, sinossi, cast, imgCopertina, trailer, generi, piattaforme, miPiace, valutazione);
		this.stagioni=stagioni;
		this.puntate=puntate;
		this.durataEpisodio=durataEpisodio;
	}	
	
	public SerieTv(Integer idContenuto, String titolo, String anno, String sinossi, String cast, ArrayList<Genere> generi, String imgCopertina, ArrayList<Piattaforma> piattaforme, String stagioni, String puntate, Float durataEpisodio, Integer miPiace, Float valutazione) {
		super(idContenuto, titolo, anno, sinossi, cast, generi, imgCopertina, piattaforme, miPiace, valutazione);
		this.stagioni=stagioni;
		this.puntate=puntate;
		this.durataEpisodio=durataEpisodio;
	}	
	
	public SerieTv(Integer idContenuto, String titolo, String sinossi, String cast, String imgCopertina, ArrayList<Genere> generi, ArrayList<Piattaforma> piattaforme, String stagioni, String puntate, Float durataEpisodio, Integer miPiace, Float valutazione) {
		super(idContenuto, titolo, sinossi, cast, imgCopertina, generi, piattaforme, miPiace, valutazione);
		this.stagioni=stagioni;
		this.puntate=puntate;
		this.durataEpisodio=durataEpisodio;
	}

	/**
	 * 
	 * @return the season's number 
	 */
	public String getStagioni() {
		return stagioni;
	}

	/**
	 * 
	 * @param stagioni 
	 */
	public void setStagioni(String stagioni) {
		this.stagioni = stagioni;
	}

	/**
	 * 
	 * @return the serie's episode
	 */
	public String getPuntate() {
		return puntate;
	}

	/**
	 * 
	 * @param puntate
	 */
	public void setPuntate(String puntate) {
		this.puntate = puntate;
	}

	/**
	 * 
	 * @return the episode's duration
	 */
	public Float getDurataEpisodio() {
		return durataEpisodio;
	}

	/**
	 * 
	 * @param durataEpisodio 
	 */ 
	public void setDurataEpisodio(Float durataEpisodio) {
		this.durataEpisodio = durataEpisodio;
	}

	@Override
	public String toString() {
		return getClass().getName()+" "+super.toString()+" [stagioni=" + stagioni + ", puntate=" + puntate + ", durataEpisodio=" + durataEpisodio + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (!super.equals(obj))
			return false;
		SerieTv other = (SerieTv) obj;
		if (durataEpisodio == null) {
			if (other.durataEpisodio != null)
				return false;
		} else if (!durataEpisodio.equals(other.durataEpisodio))
			return false;
		if (puntate == null) {
			if (other.puntate != null)
				return false;
		} else if (!puntate.equals(other.puntate))
			return false;
		if (stagioni == null) {
			if (other.stagioni != null)
				return false;
		} else if (!stagioni.equals(other.stagioni))
			return false;
		return true;
	}
	
	
}
