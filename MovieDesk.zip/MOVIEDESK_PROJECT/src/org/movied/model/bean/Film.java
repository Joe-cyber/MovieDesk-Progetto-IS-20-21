package org.movied.model.bean;

import java.util.ArrayList;

/**
 * This class describe a film content
 *
 */
public class Film extends Contenuto{
	
	private Float durata;
	private String regista;
		
	public Film(Integer idContenuto, String titolo, String anno, String sinossi, String cast, String imgCopertina, String trailer, ArrayList<Genere> generi, ArrayList<Piattaforma> piattaforme, Float durata, String regista, Integer miPiace,Float valutazione) {
		super(idContenuto, titolo, anno, sinossi, cast, imgCopertina, trailer, generi, piattaforme, miPiace, valutazione);
		this.durata=durata;
		this.regista=regista;
	}
	
	public Film(Integer idContenuto, String titolo, String sinossi, String cast, String imgCopertina, String trailer, ArrayList<Genere> generi, ArrayList<Piattaforma> piattaforme, Float durata, String regista, Integer miPiace,Float valutazione) {
		super(idContenuto, titolo, sinossi, cast, imgCopertina, trailer, generi, piattaforme, miPiace, valutazione);
		this.durata=durata;
		this.regista=regista;
	}
	
	public Film(Integer idContenuto, String titolo, String sinossi, String cast, String imgCopertina,ArrayList<Genere> generi, ArrayList<Piattaforma> piattaforme, Integer miPiace,Float valutazione) {
		super(idContenuto, titolo, sinossi, cast, imgCopertina, generi, piattaforme, miPiace, valutazione);
	}
	
	public Film(Integer idContenuto, String titolo, String anno, String sinossi, String cast, ArrayList<Genere> generi, String imgCopertina, ArrayList<Piattaforma> piattaforme, Float durata, String regista, Integer miPiace,Float valutazione) {
		super(idContenuto, titolo, anno, sinossi, cast, generi, imgCopertina, piattaforme, miPiace, valutazione);
		this.durata=durata;
		this.regista=regista;
	}

	/**
	 * 
	 * @return the film's duration 
	 */
	public Float getDurata() {
		return durata;
	}

	/**
	 * 
	 * @param durata
	 */
	public void setDurata(Float durata) {
		this.durata = durata;
	}

	/**
	 * 
	 * @return the film's movie director
	 */
	public String getRegista() {
		return regista;
	}
	/**
	 * 
	 * @param regista
	 */
	public void setRegista(String regista) {
		this.regista = regista;
	}

	@Override
	public String toString() {
		return getClass().getName()+" "+super.toString()+"[durata=" + durata + ", regista=" + regista + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (!super.equals(obj))
			return false;
		Film other = (Film) obj;
		if (durata == null) {
			if (other.durata != null)
				return false;
		} else if (!durata.equals(other.durata))
			return false;
		if (regista == null) {
			if (other.regista != null)
				return false;
		} else if (!regista.equals(other.regista))
			return false;
		return true;
	}
	
	
	
	
}
