package org.movied.model.bean;

/**
 * 
 *	This class describes a report made by an user
 */
public class Segnalazione {
	private String idSegnalazione;
	private String oggetto;
	private String message;
	private String utenteMail;
	private Stato stato;
	
	
	
	public Segnalazione(String oggetto, String message) {
		super();
		this.oggetto = oggetto;
		this.message = message;
	}

	public Segnalazione(String idSegnalazione, String oggetto,String message,String utenteMail) {
		this.idSegnalazione=idSegnalazione;
		this.oggetto=oggetto;
		this.message=message;
		this.utenteMail=utenteMail;
		stato=Stato.Ricevuta;
	}
	
	public Segnalazione(String idSegnalazione, String oggetto,String message,String utenteMail,Stato stato) {
		this.idSegnalazione=idSegnalazione;
		this.oggetto=oggetto;
		this.message=message;
		this.utenteMail=utenteMail;
		this.stato=stato;
	}
	/**
	 * 	
	 * @return the report's id 
	 */
	public String getIdSegnalazione() {
		return idSegnalazione;
	}

	/**
	 * 
	 * @param idSegnalazione
	 */
	public void setIdSegnalazione(String idSegnalazione) {
		this.idSegnalazione = idSegnalazione;
	}

	/**
	 * 
	 * @return the report's object
	 */
	public String getOggetto() {
		return oggetto;
	}

	/**
	 * 
	 * @param oggetto
	 */
	public void setOggetto(String oggetto) {
		this.oggetto = oggetto;
	}

	/**
	 * 
	 * @return the report's state
	 */
	public Stato getStato() {
		return stato;
	}

	/**
	 * 
	 * @param stato
	 */
	public void setStato(Stato stato) {
		this.stato = stato;
	}
	
	/**
	 * 
	 * @return the report's message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * 
	 * @param message
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * 
	 * @return the MediaManager's mail that take over the report
	 */
	public String getUtenteMail() {
		return utenteMail;
	}

	/**
	 * 
	 * @param utenteMail
	 */
	public void setUtenteMail(String utenteMail) {
		this.utenteMail = utenteMail;
	}
	
	@Override
	public String toString() {
		return "Segnalazione [idSegnalazione=" + idSegnalazione + ", oggetto=" + oggetto + ", message=" + message
				+ ", utenteMail=" + utenteMail + ", stato=" + stato + "]";
	}
	
	/**
	 *	A list of states of the report(Segnalazione).
	 */
	public static enum Stato{ PresaIncarico, Ricevuta, Verificata }

	@Override
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Segnalazione other = (Segnalazione) obj;
		if (idSegnalazione == null) {
			if (other.idSegnalazione != null)
				return false;
		} else if (!idSegnalazione.equals(other.idSegnalazione))
			return false;
		if (message == null) {
			if (other.message != null)
				return false;
		} else if (!message.equals(other.message))
			return false;
		if (oggetto == null) {
			if (other.oggetto != null)
				return false;
		} else if (!oggetto.equals(other.oggetto))
			return false;
		if (stato != other.stato)
			return false;
		if (utenteMail == null) {
			if (other.utenteMail != null)
				return false;
		} else if (!utenteMail.equals(other.utenteMail))
			return false;
		return true;
	}
	
	
}
