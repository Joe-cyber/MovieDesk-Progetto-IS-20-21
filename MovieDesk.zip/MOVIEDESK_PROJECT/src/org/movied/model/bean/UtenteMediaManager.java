package org.movied.model.bean;

import java.util.ArrayList;
/**
 * 
 * This class contains the method that the MediaManager can perform
 *
 */
public class UtenteMediaManager extends UtenteRegistrato{

	private ArrayList<Segnalazione> reports;
	
	public UtenteMediaManager(String nome, String cognome, String email, String password, ArrayList<Contenuto> preferiti, ArrayList<Contenuto> piaciuti, ArrayList<Contenuto> visti) {
		super(email, nome, cognome,password, preferiti, piaciuti, visti, "MM");
	}
	
	public UtenteMediaManager(String nome, String cognome, String email, String password) {
		super(email, nome, cognome, password, "MM");
	}
	
	public UtenteMediaManager(String nome, String cognome, String email, ArrayList<Contenuto> preferiti, ArrayList<Contenuto> piaciuti, ArrayList<Contenuto> visti) {
		super(email, nome, cognome, preferiti, piaciuti, visti,"MM");
	}
	
	/**
	 * 
	 * @param reports 
	 */
	public void setReports(ArrayList<Segnalazione> reports) {
		this.reports=reports;
	}
	
	/**
	 * 
	 * @return the MediaManager's reports token 
	 */
	public ArrayList<Segnalazione> getReports(){
		return reports;
	}
	
	@Override
	public String toString() {
		return getClass().getName()+" "+super.toString();
	}
}
