package org.movied.model.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.movied.control.db.MovieDB;
import org.movied.control.db.QueryManager;
import org.movied.model.bean.Contenuto;
import org.movied.model.bean.Contenuto.Genere;
import org.movied.model.bean.Film;
import org.movied.model.bean.Piattaforma;
import org.movied.model.bean.SerieTv;


public class ContenutoDao {

	private static QueryManager qm=new QueryManager();
	
	public ContenutoDao() { }
	/**
	 * 
	 * @param c represents the content to be updated
	 * @param p represents the platform to add to the content
	 * @return the number of rows updated 
	 */
	public Integer insertPlatformToContent(Contenuto c, Piattaforma p) {
		int n=0;
		Connection conn=MovieDB.getConnection();
		String query="insert into presenteSu (Contenuto_IDContenuto, Piattaforma_Nome)" + 
					"values (" +c.getIdContenuto()+
							",'"+p.getNome()+"');";
		n=qm.execUpdate(query, conn);
		MovieDB.releaseConnection(conn);
		return n;	
	}
	/**
	 * 
	 * @param c represents the content to be updated
	 * @param p represents the platform to remove from the content
	 * @return the number of rows updated 
	 */
	public Integer removePlatformFromContent(Contenuto c, Piattaforma p) {
		Connection conn=MovieDB.getConnection();
		String query="delete from presenteSu where contenuto_idContenuto="+c.getIdContenuto()+" and Piattaforma_nome='"+p.getNome()+"';";
		int n=qm.execUpdate(query, conn);
		MovieDB.releaseConnection(conn);
		return n;
	}
	
	/**
	 * 
	 * @param c is the content to be removed from the system
	 * @return the content removed, null if isn't possible to remove the content
	 */
	public int removeContent(Contenuto c) {
		Connection conn=MovieDB.getConnection();
		String query="DELETE FROM genere WHERE Contenuto_IDContenuto="+c.getIdContenuto()+";";
		qm.execUpdate(query, conn);
		query="DELETE FROM visti WHERE Contenuto_IDContenuto="+c.getIdContenuto()+";";
		qm.execUpdate(query, conn);
		query="DELETE FROM preferiti WHERE Contenuto_IDContenuto="+c.getIdContenuto()+";";
		qm.execUpdate(query, conn);
		query="DELETE FROM piaciuti WHERE Contenuto_IDContenuto="+c.getIdContenuto()+";";
		qm.execUpdate(query, conn);
		query="DELETE FROM presenteSu WHERE Contenuto_IDContenuto="+c.getIdContenuto()+";";
		qm.execUpdate(query, conn);
		query="DELETE FROM serieTv WHERE Contenuto_IDContenuto="+c.getIdContenuto()+";";
		qm.execUpdate(query, conn);
		query="DELETE FROM film WHERE Contenuto_IDContenuto="+c.getIdContenuto()+";";
		qm.execUpdate(query, conn);
		query="DELETE FROM contenuto WHERE IDContenuto="+c.getIdContenuto()+";";
		int n=qm.execUpdate(query, conn);
		MovieDB.releaseConnection(conn);
		return n;
	}
	
	/**
	 * 
	 * @return all the content in the system ordered by title 
	 */
	public ArrayList<Contenuto> selectContent() {
		ArrayList<Contenuto> contenuti=new ArrayList<>();
		Connection conn=MovieDB.getConnection();
		try
		{	
			String query="SELECT * FROM contenuto inner join film on IDContenuto=Contenuto_IDContenuto order by Titolo DESC;";
			ResultSet rs=qm.execQuery(query, conn);
			while(rs.next())
			{
				contenuti.add(
								new Film(
											rs.getInt("IDContenuto"),rs.getString("Titolo"),
											rs.getString("AnnoProduzione"),rs.getString("Sinossi"),
											rs.getString("Cast"),rs.getString("ImgCopertina"),
											rs.getString("Trailer"), new ArrayList<Genere>(),
											new ArrayList<Piattaforma>(), Float.valueOf(rs.getFloat("Durata")),rs.getString("Regista"),
											rs.getInt("miPiace"),rs.getFloat("Valutazione")
										)
							);
			}
			
			query="SELECT * FROM contenuto inner join serieTv on IDContenuto=Contenuto_IDContenuto order by Titolo DESC;";
			rs=qm.execQuery(query, conn);
			while(rs.next())
			{
				contenuti.add(
								new SerieTv(
											rs.getInt("IDContenuto"),rs.getString("Titolo"),
											rs.getString("AnnoProduzione"),rs.getString("Sinossi"),
											rs.getString("Cast"),rs.getString("ImgCopertina"),
											rs.getString("Trailer"), new ArrayList<Genere>(),
											new ArrayList<Piattaforma>(), rs.getString("Stagioni"),rs.getString("Puntate"),Float.valueOf(rs.getFloat("DurataEp")),
											rs.getInt("miPiace"),rs.getFloat("Valutazione")
										)
							);
			}
			rs.close();
			for(Contenuto contenuto:contenuti) {
				ArrayList<Genere> generi=new ArrayList<>();
				query="SELECT * FROM genere WHERE Contenuto_IDContenuto="+contenuto.getIdContenuto()+";";
				ResultSet rs2=qm.execQuery(query, conn);
				while(rs2.next())
				{
					generi.add(Genere.valueOf(rs2.getString("Tipo")));
				}
				contenuto.setGeneri(generi);
				ArrayList<Piattaforma> piattaforme=new ArrayList<>();
				query="SELECT * FROM contenuto inner join presenteSu on IDContenuto=Contenuto_IDContenuto inner join piattaforma on nome=Piattaforma_Nome WHERE Contenuto_IDContenuto="+contenuto.getIdContenuto()+";";
				rs2=qm.execQuery(query, conn);
				while(rs2.next())
				{
					piattaforme.add(new Piattaforma(rs2.getString("ImgPiattaforma"),rs2.getString("Nome"),
													rs2.getString("Link"),rs2.getFloat("abbMinimo")
							));
				}
				contenuto.setPiattaforme(piattaforme);
				contenuto.setGeneri(generi);
				rs2.close();
			}
		}
		
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			MovieDB.releaseConnection(conn);
		}
		return contenuti;
	}
	/**
	 * 
	 * @param title the title you want to search 
	 * @return all the content that contains the title in their own title and description 
	 */
	public ArrayList<Contenuto> selectContent(String title){
		ArrayList<Contenuto> contenuti=new ArrayList<>();
		Connection conn=MovieDB.getConnection();
		try
		{	
			String query="SELECT * FROM contenuto inner join film on IDContenuto=Contenuto_IDContenuto WHERE titolo LIKE'%"+title+"%' order by Titolo DESC;";
			ResultSet rs=qm.execQuery(query, conn);
			while(rs.next())
			{
				contenuti.add(
								new Film(
											rs.getInt("IDContenuto"),rs.getString("Titolo"),
											rs.getString("AnnoProduzione"),rs.getString("Sinossi"),
											rs.getString("Cast"),rs.getString("ImgCopertina"),
											rs.getString("Trailer"), new ArrayList<Genere>(),
											new ArrayList<Piattaforma>(), Float.valueOf(rs.getFloat("Durata")),rs.getString("Regista"),
											rs.getInt("miPiace"),rs.getFloat("Valutazione")
										)
							);
			}
			query="SELECT * FROM contenuto inner join serieTv on IDContenuto=Contenuto_IDContenuto WHERE titolo LIKE'%"+title+"%' order by Titolo DESC;";
			rs=qm.execQuery(query, conn);
			while(rs.next())
			{
				contenuti.add(
								new SerieTv(
											rs.getInt("IDContenuto"),rs.getString("Titolo"),
											rs.getString("AnnoProduzione"),rs.getString("Sinossi"),
											rs.getString("Cast"),rs.getString("ImgCopertina"),
											rs.getString("Trailer"), new ArrayList<Genere>(),
											new ArrayList<Piattaforma>(), rs.getString("Stagioni"),rs.getString("Puntate"),Float.valueOf(rs.getFloat("DurataEp")),
											rs.getInt("miPiace"),rs.getFloat("Valutazione")
										)
							);
			}
			rs.close();
			for(Contenuto contenuto:contenuti) {
				ArrayList<Genere> generi=new ArrayList<>();
				query="SELECT * FROM genere WHERE Contenuto_IDContenuto="+contenuto.getIdContenuto()+";";
				ResultSet rs2=qm.execQuery(query, conn);
				while(rs2.next())
				{
					generi.add(Genere.valueOf(rs2.getString("Tipo")));
				}
				contenuto.setGeneri(generi);
				ArrayList<Piattaforma> piattaforme=new ArrayList<>();
				query="SELECT * FROM contenuto inner join presenteSu on IDContenuto=Contenuto_IDContenuto inner join piattaforma on nome=Piattaforma_Nome WHERE Contenuto_IDContenuto="+contenuto.getIdContenuto()+";";
				rs2=qm.execQuery(query, conn);
				while(rs2.next())
				{
					piattaforme.add(new Piattaforma(rs2.getString("ImgPiattaforma"),rs2.getString("Nome"),
													rs2.getString("Link"),rs2.getFloat("abbMinimo")
							));
				}
				contenuto.setPiattaforme(piattaforme);
				contenuto.setGeneri(generi);
				rs2.close();
			}
		}
		
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			MovieDB.releaseConnection(conn);
		}
		return contenuti;
	}
	/**
	 * 
	 * @param attribute represent the attribute you want to filter by the content
	 * @param value is the value of the attribute 
	 * @return all the content compliant at the attribute's value 
	 */
	public ArrayList<Contenuto> selectContent(String attribute, String value){
		ArrayList<Contenuto> contenuti=new ArrayList<>();
		Connection conn=MovieDB.getConnection();
		Contenuto content = null;
		try
		{	switch(attribute) {
				case "anno":{
					String query="SELECT * FROM contenuto inner join film on IDContenuto=Contenuto_IDContenuto WHERE annoProduzione='"+value+"' order by Titolo DESC;";
					ResultSet rs=qm.execQuery(query, conn);
					while(rs.next())
					{
						contenuti.add(
										new Film(
													rs.getInt("IDContenuto"),rs.getString("Titolo"),
													rs.getString("AnnoProduzione"),rs.getString("Sinossi"),
													rs.getString("Cast"),rs.getString("ImgCopertina"),
													rs.getString("Trailer"), new ArrayList<Genere>(),
													new ArrayList<Piattaforma>(), Float.valueOf(rs.getFloat("Durata")),rs.getString("Regista"),
													rs.getInt("miPiace"),rs.getFloat("Valutazione")
												)
									);
					}
					query="SELECT * FROM contenuto inner join serieTv on IDContenuto=Contenuto_IDContenuto WHERE annoProduzione='"+value+"' order by Titolo DESC;";
					rs=qm.execQuery(query, conn);
					while(rs.next())
					{
						contenuti.add(
										new SerieTv(
													rs.getInt("IDContenuto"),rs.getString("Titolo"),
													rs.getString("AnnoProduzione"),rs.getString("Sinossi"),
													rs.getString("Cast"),rs.getString("ImgCopertina"),
													rs.getString("Trailer"), new ArrayList<Genere>(),
													new ArrayList<Piattaforma>(), rs.getString("Stagioni"),rs.getString("Puntate"),Float.valueOf(rs.getFloat("DurataEp")),
													rs.getInt("miPiace"),rs.getFloat("Valutazione")
												)
									);
					}
					rs.close();
					for(Contenuto contenuto:contenuti) {
						ArrayList<Genere> generi=new ArrayList<>();
						query="SELECT * FROM genere WHERE Contenuto_IDContenuto="+contenuto.getIdContenuto()+";";
						ResultSet rs2=qm.execQuery(query, conn);
						while(rs2.next())
						{
							generi.add(Genere.valueOf(rs2.getString("Tipo")));
						}
						contenuto.setGeneri(generi);
						ArrayList<Piattaforma> piattaforme=new ArrayList<>();
						query="SELECT * FROM contenuto inner join presenteSu on IDContenuto=Contenuto_IDContenuto inner join piattaforma on nome=Piattaforma_Nome WHERE Contenuto_IDContenuto="+contenuto.getIdContenuto()+";";
						rs2=qm.execQuery(query, conn);
						while(rs2.next())
						{
							piattaforme.add(new Piattaforma(rs2.getString("ImgPiattaforma"),rs2.getString("Nome"),
															rs2.getString("Link"),rs2.getFloat("abbMinimo")
									));
						}
						contenuto.setPiattaforme(piattaforme);
						contenuto.setGeneri(generi);
						rs2.close();
					}
				}
				break;
				case "genere":{
					String query="SELECT * FROM contenuto inner join film on IDContenuto=Film.Contenuto_IDContenuto inner join Genere on IDContenuto=Genere.Contenuto_IDContenuto WHERE tipo='"+value+"' order by Titolo DESC;";
					ResultSet rs=qm.execQuery(query, conn);
					while(rs.next())
					{
						contenuti.add(
										new Film(
													rs.getInt("IDContenuto"),rs.getString("Titolo"),
													rs.getString("AnnoProduzione"),rs.getString("Sinossi"),
													rs.getString("Cast"),rs.getString("ImgCopertina"),
													rs.getString("Trailer"), new ArrayList<Genere>(),
													new ArrayList<Piattaforma>(), Float.valueOf(rs.getFloat("Durata")),rs.getString("Regista"),
													rs.getInt("miPiace"),rs.getFloat("Valutazione")
												)
									);
					}
					query="SELECT * FROM contenuto inner join serieTv on IDContenuto=SerieTV.Contenuto_IDContenuto inner join Genere on IDContenuto=Genere.Contenuto_IDContenuto WHERE tipo='"+value+"' order by Titolo DESC;";
					rs=qm.execQuery(query, conn);
					while(rs.next())
					{
						contenuti.add(
										new SerieTv(
													rs.getInt("IDContenuto"),rs.getString("Titolo"),
													rs.getString("AnnoProduzione"),rs.getString("Sinossi"),
													rs.getString("Cast"),rs.getString("ImgCopertina"),
													rs.getString("Trailer"), new ArrayList<Genere>(),
													new ArrayList<Piattaforma>(), rs.getString("Stagioni"),rs.getString("Puntate"),Float.valueOf(rs.getFloat("DurataEp")),
													rs.getInt("miPiace"),rs.getFloat("Valutazione")
												)
									);
					}
					rs.close();
					for(Contenuto contenuto:contenuti) {
						ArrayList<Genere> generi=new ArrayList<>();
						query="SELECT * FROM genere WHERE Contenuto_IDContenuto="+contenuto.getIdContenuto()+";";
						ResultSet rs2=qm.execQuery(query, conn);
						while(rs2.next())
						{
							generi.add(Genere.valueOf(rs2.getString("Tipo")));
						}
						contenuto.setGeneri(generi);
						ArrayList<Piattaforma> piattaforme=new ArrayList<>();
						query="SELECT * FROM contenuto inner join presenteSu on IDContenuto=Contenuto_IDContenuto inner join piattaforma on nome=Piattaforma_Nome WHERE Contenuto_IDContenuto="+contenuto.getIdContenuto()+";";
						rs2=qm.execQuery(query, conn);
						while(rs2.next())
						{
							piattaforme.add(new Piattaforma(rs2.getString("ImgPiattaforma"),rs2.getString("Nome"),
															rs2.getString("Link"),rs2.getFloat("abbMinimo")
									));
						}
						contenuto.setPiattaforme(piattaforme);
						contenuto.setGeneri(generi);
						rs2.close();
					}
				}
				break;
				case "valutazioni":{
					String query="SELECT * FROM contenuto left join film on IDContenuto=Film.Contenuto_IDContenuto left join SerieTV on IDContenuto=SerieTv.Contenuto_IDContenuto order by MiPiace DESC;";
					ResultSet rs=qm.execQuery(query, conn);
					while(rs.next())
					{
						if(rs.getString("Regista")!=null && rs.getString("Durata")!=null && !rs.getString("Regista").equals("") && !rs.getString("Durata").equals("")) {
							contenuti.add(
											content=new Film(
														rs.getInt("IDContenuto"),rs.getString("Titolo"),
														rs.getString("AnnoProduzione"),rs.getString("Sinossi"),
														rs.getString("Cast"),rs.getString("ImgCopertina"),
														rs.getString("Trailer"), new ArrayList<Genere>(),
														new ArrayList<Piattaforma>(), Float.valueOf(rs.getFloat("Durata")),rs.getString("Regista"),
														rs.getInt("miPiace"),rs.getFloat("Valutazione")
													)
										);
						}
						else if(rs.getString("Stagioni")!=null && rs.getString("Puntate")!=null && !rs.getString("Stagioni").equals("") && !rs.getString("Puntate").equals("")) {
							contenuti.add(
									content=new SerieTv(
												rs.getInt("IDContenuto"),rs.getString("Titolo"),
												rs.getString("AnnoProduzione"),rs.getString("Sinossi"),
												rs.getString("Cast"),rs.getString("ImgCopertina"),
												rs.getString("Trailer"), new ArrayList<Genere>(),
												new ArrayList<Piattaforma>(), rs.getString("Stagioni"),rs.getString("Puntate"),Float.valueOf(rs.getFloat("DurataEp")),
												rs.getInt("miPiace"),rs.getFloat("Valutazione")
											)
								);
						}
						ArrayList<Genere> generi=new ArrayList<>();
						query="SELECT * FROM genere WHERE Contenuto_IDContenuto="+content.getIdContenuto()+";";
						ResultSet rs2=qm.execQuery(query, conn);
						while(rs2.next())
						{
							generi.add(Genere.valueOf(rs2.getString("Tipo")));
						}
						content.setGeneri(generi);
						ArrayList<Piattaforma> piattaforme=new ArrayList<>();
						query="SELECT * FROM contenuto inner join presenteSu on IDContenuto=Contenuto_IDContenuto inner join piattaforma on nome=Piattaforma_Nome WHERE Contenuto_IDContenuto="+content.getIdContenuto()+";";
						rs2=qm.execQuery(query, conn);
						while(rs2.next())
						{
							piattaforme.add(new Piattaforma(rs2.getString("ImgPiattaforma"),rs2.getString("Nome"),
															rs2.getString("Link"),rs2.getFloat("abbMinimo")
									));
						}
						content.setPiattaforme(piattaforme);
						content.setGeneri(generi);
						rs2.close();
					}
					rs.close();
				}
				break;
				case "consigliati":{
					String query="SELECT DISTINCT(IDContenuto) as ID, Contenuto.*, Film.* FROM contenuto INNER JOIN film ON contenuto.IDContenuto=film.Contenuto_IDContenuto INNER JOIN genere ON contenuto.IDContenuto=Genere.Contenuto_IDContenuto WHERE tipo IN (SELECT tipo FROM piaciuti WHERE Utente_email='"+value+"') AND IDContenuto NOT IN (SELECT Contenuto_IDContenuto FROM piaciuti WHERE Utente_email='"+value+"');";
					ResultSet rs=qm.execQuery(query, conn);
					while(rs.next())
					{
						contenuti.add(
										new Film(
													rs.getInt("IDContenuto"),rs.getString("Titolo"),
													rs.getString("AnnoProduzione"),rs.getString("Sinossi"),
													rs.getString("Cast"),rs.getString("ImgCopertina"),
													rs.getString("Trailer"), new ArrayList<Genere>(),
													new ArrayList<Piattaforma>(), Float.valueOf(rs.getFloat("Durata")),rs.getString("Regista"),
													rs.getInt("miPiace"),rs.getFloat("Valutazione")
												)
									);
					}
					query="SELECT DISTINCT(IDContenuto) as ID, Contenuto.*, SerieTv.* FROM contenuto INNER JOIN serieTv ON contenuto.IDContenuto=serieTv.Contenuto_IDContenuto INNER JOIN genere ON contenuto.IDContenuto=Genere.Contenuto_IDContenuto WHERE tipo IN (SELECT tipo FROM piaciuti WHERE Utente_email='"+value+"') AND IDContenuto NOT IN (SELECT Contenuto_IDContenuto FROM piaciuti WHERE Utente_email='"+value+"');";
					rs=qm.execQuery(query, conn);
					while(rs.next())
					{
						contenuti.add(
										new SerieTv(
													rs.getInt("IDContenuto"),rs.getString("Titolo"),
													rs.getString("AnnoProduzione"),rs.getString("Sinossi"),
													rs.getString("Cast"),rs.getString("ImgCopertina"),
													rs.getString("Trailer"), new ArrayList<Genere>(),
													new ArrayList<Piattaforma>(), rs.getString("Stagioni"),rs.getString("Puntate"),Float.valueOf(rs.getFloat("DurataEp")),
													rs.getInt("miPiace"),rs.getFloat("Valutazione")
												)
									);
					}
					rs.close();
					for(Contenuto contenuto:contenuti) {
						ArrayList<Genere> generi=new ArrayList<>();
						query="SELECT * FROM genere WHERE Contenuto_IDContenuto="+contenuto.getIdContenuto()+";";
						ResultSet rs2=qm.execQuery(query, conn);
						while(rs2.next())
						{
							generi.add(Genere.valueOf(rs2.getString("Tipo")));
						}
						contenuto.setGeneri(generi);
						ArrayList<Piattaforma> piattaforme=new ArrayList<>();
						query="SELECT * FROM contenuto inner join presenteSu on IDContenuto=Contenuto_IDContenuto inner join piattaforma on nome=Piattaforma_Nome WHERE Contenuto_IDContenuto="+contenuto.getIdContenuto()+";";
						rs2=qm.execQuery(query, conn);
						while(rs2.next())
						{
							piattaforme.add(new Piattaforma(rs2.getString("ImgPiattaforma"),rs2.getString("Nome"),
															rs2.getString("Link"),rs2.getFloat("abbMinimo")
									));
						}
						contenuto.setPiattaforme(piattaforme);
						contenuto.setGeneri(generi);
						rs2.close();
					}
				}
			}
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			MovieDB.releaseConnection(conn);
		}
		return contenuti;
	}
	
	/**
	 * 
	 * @param idContenuto the id of the content you want to have details
	 * @return all the info about the content, null if the content isn't in the system
	 */
	public Contenuto getContentDetails(Integer idContenuto) {
		Contenuto content=null;
		Connection conn= MovieDB.getConnection();
		try
		{	
			String query="SELECT * FROM serieTv inner join contenuto on IDContenuto=Contenuto_IDContenuto WHERE Contenuto_IDContenuto="+idContenuto+";";
			ResultSet rs=qm.execQuery(query, conn);
			if(rs.next())
			{
				content=new SerieTv(
						rs.getInt("IDContenuto"),rs.getString("Titolo"),
						rs.getString("AnnoProduzione"),rs.getString("Sinossi"),
						rs.getString("Cast"),rs.getString("ImgCopertina"),
						rs.getString("Trailer"), new ArrayList<Genere>(),
						new ArrayList<Piattaforma>(), rs.getString("Stagioni"),rs.getString("Puntate"),Float.valueOf(rs.getFloat("DurataEp")),
						rs.getInt("miPiace"),rs.getFloat("Valutazione")
					);
			}
			
			query="SELECT * FROM film inner join contenuto on IDContenuto=Contenuto_IDContenuto WHERE Contenuto_IDContenuto="+idContenuto+";";
			rs=qm.execQuery(query, conn);
			if(rs.next())
			{
				content=new Film(
						rs.getInt("IDContenuto"),rs.getString("Titolo"),
						rs.getString("AnnoProduzione"),rs.getString("Sinossi"),
						rs.getString("Cast"),rs.getString("ImgCopertina"),
						rs.getString("Trailer"), new ArrayList<Genere>(),
						new ArrayList<Piattaforma>(), Float.valueOf(rs.getFloat("Durata")),rs.getString("Regista"),
						rs.getInt("miPiace"),rs.getFloat("Valutazione")
					);
			}
			ArrayList<Genere> generi=new ArrayList<>();
			query="SELECT * FROM genere WHERE Contenuto_IDContenuto="+idContenuto+";";
			rs=qm.execQuery(query, conn);
			while(rs.next())
			{
				generi.add(Genere.valueOf(rs.getString("Tipo")));
			}
			if(content==null)
				return null;
			content.setGeneri(generi);
			ArrayList<Piattaforma> piattaforme=new ArrayList<>();
			query="SELECT * FROM contenuto inner join presenteSu on IDContenuto=Contenuto_IDContenuto inner join piattaforma on nome=Piattaforma_Nome WHERE Contenuto_IDContenuto="+idContenuto+";";
			rs=qm.execQuery(query, conn);
			while(rs.next())
			{
				piattaforme.add(new Piattaforma(rs.getString("ImgPiattaforma"),rs.getString("Nome"),
												rs.getString("Link"),rs.getFloat("abbMinimo")
						));
			}
			content.setPiattaforme(piattaforme);
			content.setGeneri(generi);
			rs.close();
		}
		
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			MovieDB.releaseConnection(conn);
		}
		return content;
	}
}
