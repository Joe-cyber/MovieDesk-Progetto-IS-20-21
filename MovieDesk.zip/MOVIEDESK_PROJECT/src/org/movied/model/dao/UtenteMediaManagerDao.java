package org.movied.model.dao;

import java.sql.Connection;

import org.movied.control.db.MovieDB;
import org.movied.control.db.QueryManager;
import org.movied.model.bean.UtenteMediaManager;

public class UtenteMediaManagerDao {

	private static QueryManager qm=new QueryManager();
	
	/**
	 * 
	 * @param u the media manager you want to add to the system
	 * @return the output of the execUpdate that returns the number of columns affected by the query.In this case n=1;
	 */
	public Integer insertUtente(UtenteMediaManager u)
	{
		int n=0;
		Connection conn=MovieDB.getConnection();
		String query=	"insert into Utente (Email,Nome,Cognome,PassUtente,Tipo)" + 
						"values ('" + 
									u.getEmail()+"','" + 
									u.getNome()+"','" + 
									u.getCognome()+"','" + 
									u.getPassword()+ "','"+
									"MM"+
								"');";
		n=qm.execUpdate(query, conn);
		MovieDB.releaseConnection(conn);
		return n;	
	}
}
