package org.movied.model.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.movied.control.db.MovieDB;
import org.movied.control.db.QueryManager;
import org.movied.model.bean.SerieTv;
import org.movied.model.bean.Contenuto.Genere;

public class SerieTVDao {

	private static QueryManager qm=new QueryManager();
	
	public SerieTVDao() {}
	
	/**
	 * 
	 * @param serieTv is the Serie Tv you want to insert in the system
	 * @return the number of rows updated 
	 */
	public Integer insertSerieTVContent(SerieTv serieTv) {
		int n=0;
		Connection conn=MovieDB.getConnection();
		String query="insert into contenuto (Titolo, Sinossi, AnnoProduzione, ImgCopertina, Trailer, MiPiace, Cast, Valutazione)" + 
					 "values ('"+serieTv.getTitolo()+"','"+serieTv.getSinossi()+"','"
								+serieTv.getAnno()+"','"+serieTv.getImgCopertina()+"','"
								+serieTv.getTrailer()+"',"+serieTv.getMiPiace()+",'"+serieTv.getCast()+"',"+serieTv.getValutazione()+");";
		n=qm.execUpdate(query, conn);
		if(n==1) {
			query="SELECT MAX(IDContenuto) as ID FROM contenuto";
			String id=null;
			ResultSet rs=qm.execQuery(query, conn);
			try {
				if(rs.next()) {
					id=rs.getString("ID");
				}
			} 
			catch (SQLException e) {
				e.printStackTrace();
			}
			query="insert into SerieTV (Stagioni, Puntate, DurataEp, Contenuto_IDContenuto)" 
				  +"values ('"+serieTv.getStagioni()+"','"+serieTv.getPuntate()+"',"
				  +serieTv.getDurataEpisodio()+","+id+");";
			qm.execUpdate(query, conn);
			for(Genere g : serieTv.getGeneri()) {
	            query="insert into Genere (Tipo, Contenuto_IDContenuto)" 
	                      +"values ('"+g.toString()+"',"+id+");";
	                n=qm.execUpdate(query, conn);
	        }
		}
		MovieDB.releaseConnection(conn);
		return n;	
	}
}
