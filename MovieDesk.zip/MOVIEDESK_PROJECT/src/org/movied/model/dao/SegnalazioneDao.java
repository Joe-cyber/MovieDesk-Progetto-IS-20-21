package org.movied.model.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.movied.control.db.MovieDB;
import org.movied.control.db.QueryManager;
import org.movied.model.bean.Segnalazione;
import org.movied.model.bean.Segnalazione.Stato;

public class SegnalazioneDao {

	private static QueryManager qm=new QueryManager();
	
	/**
	 * 
	 * @param s The report that needs to be added in the database
	 * @return the output of the execUpdate that returns the number of columns affected by the query.In this case n=1;
	 */
	public Integer insertReport(Segnalazione s)
	{
		int n=0;
		Connection conn=MovieDB.getConnection();
		String query=	"insert into Segnalazione (Oggetto,Messaggio)" + 
						"values ('" + 
									s.getOggetto()+"','" + 
									s.getMessage()+ 										
								"');";
		n=qm.execUpdate(query, conn);
		MovieDB.releaseConnection(conn);
		return n;	
	}
	
	/**
	 * 
	 * @return a report List in which are stored all the report with status "Ricevuta"
	 */
	public ArrayList<Segnalazione> selectReport(){
		Connection conn=MovieDB.getConnection();
		ArrayList<Segnalazione> segnalazioni = new ArrayList<Segnalazione>();
		
		try
		{
			String query="select * from Segnalazione where Stato='"+Stato.Ricevuta.toString()+"';";
			ResultSet rs=qm.execQuery(query, conn);
			while(rs.next())
			{
				segnalazioni.add(
								new Segnalazione	(
										rs.getString("IDSegnalazione"),
										rs.getString("Oggetto"),
										rs.getString("Messaggio"),
										rs.getString("Utente_Email")
									)
							
							);
			}
			rs.close();
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			MovieDB.releaseConnection(conn);
		}
		return segnalazioni;
	}
	/**
	 * 
	 * @param email the key of the media manager that you want the take over report
	 * @return a report List
	 */
	public ArrayList<Segnalazione> selectReport(String email){
		Connection conn=MovieDB.getConnection();
		ArrayList<Segnalazione> segnalazioni = new ArrayList<Segnalazione>();
		
		try
		{
			String query="select * from Segnalazione where Stato='"+Stato.PresaIncarico.toString()+"' and Utente_email='"+email+"';";
			ResultSet rs=qm.execQuery(query, conn);
			while(rs.next())
			{
				segnalazioni.add(
								new Segnalazione	(
										rs.getString("IDSegnalazione"),
										rs.getString("Oggetto"),
										rs.getString("Messaggio"),
										rs.getString("Utente_Email"),
										Stato.PresaIncarico
									)
							
							);
			}
			rs.close();
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			MovieDB.releaseConnection(conn);
		}
		return segnalazioni;
	}
	
	/**
	 * 
	 * @param idSegnalazione the report's id that needs to be updated
	 * @param stato the new state of the report selected in the enum Stato
	 * @return the output of the execUpdate that returns the number of columns affected by the query.In this case n=1;
	 */
	public Integer updateStatusReport(String idSegnalazione,Stato stato) {
		int n=0;
		Connection conn=MovieDB.getConnection();
		String query="update Segnalazione set Stato='"+stato.toString()+"'where IdSegnalazione ='"+Integer.parseInt(idSegnalazione) +"';";
		n=qm.execUpdate(query, conn);
		MovieDB.releaseConnection(conn);
		return n;
	}
	/**
	 * 
	 * @param idSegnalazione the report's id that needs to be updated
	 * @param stato the new state of the report selected in the enum Stato
	 * @param email the key of the media manager that take over the report
	 * @return the output of the execUpdate that returns the number of columns affected by the query.In this case n=1;
	 */
	public Integer updateStatusReport(String idSegnalazione,Stato stato, String email) {
		int n=0;
		Connection conn=MovieDB.getConnection();
		String query="update Segnalazione set Stato='"+stato.toString()+"', Utente_email='"+email+"' where IdSegnalazione ='"+Integer.parseInt(idSegnalazione) +"';";
		n=qm.execUpdate(query, conn);
		MovieDB.releaseConnection(conn);
		return n;
	}
	
	/**
	 * 
	 * @param id the id that the report you want the take over report
	 * @return a report List
	 */
	public Segnalazione selectSingleReport(int id){
		Connection conn=MovieDB.getConnection();
		Segnalazione segnalazione = null;
		
		try
		{
			String query="select * from Segnalazione where IDSegnalazione='"+id+"';";
			ResultSet rs=qm.execQuery(query, conn);
			if(rs.next())
			{
				segnalazione=new Segnalazione	(
										rs.getString("IDSegnalazione"),
										rs.getString("Oggetto"),
										rs.getString("Messaggio"),
										rs.getString("Utente_Email"),
										Stato.valueOf(rs.getString("Stato"))
									);
			}
			rs.close();
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			MovieDB.releaseConnection(conn);
		}
		return segnalazione;
	}
}
