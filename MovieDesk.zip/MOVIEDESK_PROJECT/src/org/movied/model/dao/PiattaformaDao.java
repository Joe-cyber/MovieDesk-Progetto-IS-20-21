package org.movied.model.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.movied.control.db.MovieDB;
import org.movied.control.db.QueryManager;
import org.movied.model.bean.Piattaforma;

public class PiattaformaDao {

	private static QueryManager qm=new QueryManager();

	/**
     * 
     * @param nomeP Name of the platform that needs to be retrieved by it's key (Nome)
     * @return an ArrayList of Platforms found by the query
     */
	public ArrayList<Piattaforma> selectPlatform(String nomeP) 
    {

        ArrayList<Piattaforma> piattaforma= new ArrayList<Piattaforma>();
        Connection conn=MovieDB.getConnection();
        try
        {
            String query="SELECT * FROM PIATTAFORMA WHERE Nome like'%"+nomeP+"%';";
            ResultSet rs=qm.execQuery(query, conn);
            while(rs.next()) 
            {
                piattaforma.add(new Piattaforma    (
                                            rs.getString("ImgPiattaforma"),
                                            rs.getString("Nome"),
                                            rs.getString("Link"),
                                            rs.getFloat("AbbMinimo")
                                        )
                );
            }
            rs.close();
        }
        catch(SQLException e) 
        {
            e.printStackTrace();
        }
        finally
        {
            MovieDB.releaseConnection(conn);
        }
        return piattaforma;

    }
	
	/**
	 * 
	 * @return a list of all the platform in the database
	 */
	public ArrayList<Piattaforma> selectPlatform() 
	{
		ArrayList<Piattaforma> piattaforme=new ArrayList<Piattaforma>();
		Connection conn=MovieDB.getConnection();
		try
		{
			String query="select * from Piattaforma;";
			ResultSet rs=qm.execQuery(query, conn);
			while(rs.next())
			{
				piattaforme.add(
								new Piattaforma	(
										rs.getString("ImgPiattaforma"),
										rs.getString("Nome"),
										rs.getString("Link"),
										rs.getFloat("AbbMinimo")
									)
							
							);
				
			}
			rs.close();
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			MovieDB.releaseConnection(conn);
		}
		return piattaforme;
	}
	
	/**
	 * 
	 * @param p Platform that needs to be added to the database
	 * @return the output of the execUpdate that returns the column affected by the update.In this instance n=1;
	 */
	public Integer insertPiattaforma(Piattaforma p)
	{
		int n=0;
		Connection conn=MovieDB.getConnection();
		String query=	"insert into Piattaforma (Nome,ImgPiattaforma, Link, AbbMinimo)" + 
						"values ('" + 
									p.getNome()+"','" + 
									p.getImgPiattaforma()+"','" + 
									p.getLink()+"','" + 
									p.getAbbonamentoMinimo()+ 									
								"');";
		n=qm.execUpdate(query, conn);
		MovieDB.releaseConnection(conn);
		return n;	
	}
	
	/**
	 * 
	 * @param nomeP The name of the platform to remove
	 * @return the output of the execUpdate that returns the column affected by the update.In this instance n=1
	 */
	public Integer removePiattaforma(String nomeP)
    {
        int n=0;
        Connection conn=MovieDB.getConnection();
        String query="delete from PresenteSu where Piattaforma_Nome='"+nomeP +"';";
        qm.execUpdate(query, conn);
        query="delete from Piattaforma where Nome='"+nomeP +"';";
        n=qm.execUpdate(query, conn);
        MovieDB.releaseConnection(conn);
        return n;
    }
	
	/**
     * 
     * @param nomeP Name of the platform that needs to be retrieved by it's key (Nome)
     * @return the object Piattaforma found by the query
     */
	public Piattaforma selectSinglePlatform(String nomeP) 
    {

        Piattaforma piattaforma= null;
        Connection conn=MovieDB.getConnection();
        try
        {
            String query="SELECT * FROM PIATTAFORMA WHERE Nome like'%"+nomeP+"%';";
            ResultSet rs=qm.execQuery(query, conn);
            if(rs.next()) 
            {
                piattaforma=(new Piattaforma    (
                                            rs.getString("ImgPiattaforma"),
                                            rs.getString("Nome"),
                                            rs.getString("Link"),
                                            rs.getFloat("AbbMinimo")
                                        )
                );
            }
            rs.close();
        }
        catch(SQLException e) 
        {
            e.printStackTrace();
        }
        finally
        {
            MovieDB.releaseConnection(conn);
        }
        return piattaforma;

    }
}
