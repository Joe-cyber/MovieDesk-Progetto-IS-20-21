package org.movied.model.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.movied.control.db.MovieDB;
import org.movied.control.db.QueryManager;
import org.movied.model.bean.Contenuto;
import org.movied.model.bean.Film;
import org.movied.model.bean.Piattaforma;
import org.movied.model.bean.SerieTv;
import org.movied.model.bean.UtenteRegistrato;
import org.movied.model.bean.Contenuto.Genere;

public class UtenteRegistratoDao {

	private static QueryManager qm=new QueryManager();
	/**
	 * 
	 * @param u the user that needs to be added in the database
	 * @return the output of the execUpdate() that returns the columns affected by the update.In this case n=1;
	 */
	public Integer insertUtente(UtenteRegistrato u)
	{
		int n=0;
		Connection conn=MovieDB.getConnection();
		String query=	"insert into Utente (Email,Nome,Cognome,PassUtente,Tipo)" + 
				"values ('" + 
					u.getEmail()+"','" + 
					u.getNome()+"','" + 
					u.getCognome()+"',md5('" + 
					u.getPassword()+ "'),'"+
					"US"+
			"');";
		n=qm.execUpdate(query, conn);
		MovieDB.releaseConnection(conn);
		return n;	
	}
	
	/**
	 * 
	 * @param email the user's email address,passed as a String it serves as the primary key of the entity to find
	 * @param pass The user's password,passed as a String it serves as a secondary key to find the specific user
	 * @return the user found by the query
	 */
	
	public UtenteRegistrato findUtente(String email,String pass) 
	{
		
		UtenteRegistrato utente=null;
		Connection conn=MovieDB.getConnection();
		try
		{
			String query="SELECT * FROM UTENTE WHERE Email='"+email+ "' AND PassUtente=md5('"+pass+"');";
			ResultSet rs=qm.execQuery(query, conn);
			if(rs.next()) 
			{
				utente= new UtenteRegistrato (
											rs.getString("Email"),
											rs.getString("Nome"),
											rs.getString("Cognome"),
											rs.getString("PassUtente"),
											rs.getString("Tipo")
										);
			}
			rs.close();
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			MovieDB.releaseConnection(conn);
		}
		return utente;
				
	}
	
	/**
	 * 
	 * @param email the user's email address,passed as a String it serves as the primary key of the entity to find
	 * @return the user found by the query
	 */
	public UtenteRegistrato findUtente(String email) 
	{
		
		UtenteRegistrato utente=null;
		Connection conn=MovieDB.getConnection();
		try
		{
			String query="SELECT * FROM UTENTE WHERE Email='"+email+"';";
			ResultSet rs=qm.execQuery(query, conn);
			if(rs.next()) 
			{
				utente= new UtenteRegistrato (
											rs.getString("Email"),
											rs.getString("Nome"),
											rs.getString("Cognome"),
											rs.getString("PassUtente"),
											rs.getString("Tipo")
										);
			}
			rs.close();
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			MovieDB.releaseConnection(conn);
		}
		return utente;
				
	}
	
	/**
	 * 
	 * @param idContenuto passed as a String it serves as the primary key to bind the mark to a media content
	 * @param tag passed as a String is serves as the way to specify the type of mark that needs to be binded to the content
	 * @param ut The user who needs to be associated with the mark
	 * @return the output of the execUpdate that returns the number of columns affected by the query.In this case n=1;
	 */
	public Integer insertMark(String idContenuto,String tag,UtenteRegistrato ut) {
		int n=0;
		Connection conn=MovieDB.getConnection();
		int id=Integer.parseInt(idContenuto);
		String query=null;
		switch(tag) {
			case "Preferito":{
				query="insert into Preferiti (Contenuto_IDContenuto,Utente_Email)" + 
					  "values ('"+
									id+"','"+
									ut.getEmail()+
								"');";
				n=qm.execUpdate(query, conn);
			}
			break;		
			case "Piaciuto":{
				query="insert into Piaciuti (Contenuto_IDContenuto,Utente_Email)" + 
						"values ('"+
									id+"','"+
									ut.getEmail()+
								"');";
				n=qm.execUpdate(query, conn);
				query="UPDATE Contenuto SET MiPiace=(Select MiPiace where IDContenuto="+id+")+1 WHERE IDContenuto="+id+";";
				qm.execUpdate(query, conn);
			}
			break;
			case "Visto":{
				query="insert into Visti (Contenuto_IDContenuto,Utente_Email)" + 
						"values ('"+
									id+"','"+
									ut.getEmail()+
								"');";
				n=qm.execUpdate(query, conn);
			}
			break;
		}
		MovieDB.releaseConnection(conn);
		return n;
	}
	
	/**
	 * 
	 * @param utente User who needs to update his/her personal data
	 * @return the output of the execUpdate that returns the number of columns affected by the query.In this instance n=1
	 */
	public Integer updatePersonalData(UtenteRegistrato utente) {
		int n=0;
		Connection conn=MovieDB.getConnection();
		String query=	"update Utente set Nome='"+utente.getNome() +"', Cognome='"+utente.getCognome() + "', PassUtente=md5('"+utente.getPassword()+"') where Email='"+utente.getEmail()+"';";
		n=qm.execUpdate(query, conn);
		MovieDB.releaseConnection(conn);
		return n;
	}
	
	/**
	 * 
	 * @param email the email of the user you want to find the liked contents
	 * @return the liked contents
	 */
	public ArrayList<Contenuto> findPiaciuti(String email){
		Connection conn=MovieDB.getConnection();
		ArrayList<Contenuto> contenuti=new ArrayList<>();
		String query="SELECT * FROM contenuto inner join film on IDContenuto=Film.Contenuto_IDContenuto inner join piaciuti on IDContenuto=Piaciuti.Contenuto_IDContenuto WHERE Utente_Email='"+email+"' order by Titolo DESC;";
		ResultSet rs=qm.execQuery(query, conn);
		try {
			while(rs.next())
			{
				contenuti.add(
								new Film(
											rs.getInt("IDContenuto"),rs.getString("Titolo"),
											rs.getString("AnnoProduzione"),rs.getString("Sinossi"),
											rs.getString("Cast"),rs.getString("ImgCopertina"),
											rs.getString("Trailer"), new ArrayList<Genere>(),
											new ArrayList<Piattaforma>(), Float.valueOf(rs.getFloat("Durata")),rs.getString("Regista"),
											rs.getInt("miPiace"),rs.getFloat("Valutazione")
										)
							);
			}
			query="SELECT * FROM contenuto inner join serieTv on IDContenuto=SerieTv.Contenuto_IDContenuto inner join piaciuti on IDContenuto=Piaciuti.Contenuto_IDContenuto WHERE Utente_Email='"+email+"' order by Titolo DESC;";
			rs=qm.execQuery(query, conn);
			while(rs.next())
			{
				contenuti.add(
								new SerieTv(
											rs.getInt("IDContenuto"),rs.getString("Titolo"),
											rs.getString("AnnoProduzione"),rs.getString("Sinossi"),
											rs.getString("Cast"),rs.getString("ImgCopertina"),
											rs.getString("Trailer"), new ArrayList<Genere>(),
											new ArrayList<Piattaforma>(), rs.getString("Stagioni"),rs.getString("Puntate"),Float.valueOf(rs.getFloat("DurataEp")),
											rs.getInt("miPiace"),rs.getFloat("Valutazione")
										)
							);
			}
			rs.close();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}finally
		{
			MovieDB.releaseConnection(conn);
		}
		return contenuti;
	}		
	/**
	 * 
	 * @param email the email of the user you want to find the preferred contents
	 * @return the preferred contents
	 */
	public ArrayList<Contenuto> findPreferiti(String email){
		Connection conn=MovieDB.getConnection();
		ArrayList<Contenuto> contenuti=new ArrayList<>();
		String query="SELECT * FROM contenuto inner join film on IDContenuto=Film.Contenuto_IDContenuto inner join preferiti on IDContenuto=Preferiti.Contenuto_IDContenuto WHERE Utente_Email='"+email+"' order by Titolo DESC;";
		ResultSet rs=qm.execQuery(query, conn);
		try {
			while(rs.next())
			{
				contenuti.add(
								new Film(
											rs.getInt("IDContenuto"),rs.getString("Titolo"),
											rs.getString("AnnoProduzione"),rs.getString("Sinossi"),
											rs.getString("Cast"),rs.getString("ImgCopertina"),
											rs.getString("Trailer"), new ArrayList<Genere>(),
											new ArrayList<Piattaforma>(), Float.valueOf(rs.getFloat("Durata")),rs.getString("Regista"),
											rs.getInt("miPiace"),rs.getFloat("Valutazione")
										)
							);
			}
			query="SELECT * FROM contenuto inner join serieTv on IDContenuto=SerieTv.Contenuto_IDContenuto inner join preferiti on IDContenuto=Preferiti.Contenuto_IDContenuto WHERE Utente_Email='"+email+"' order by Titolo DESC;";
			rs=qm.execQuery(query, conn);
			while(rs.next())
			{
				contenuti.add(
								new SerieTv(
											rs.getInt("IDContenuto"),rs.getString("Titolo"),
											rs.getString("AnnoProduzione"),rs.getString("Sinossi"),
											rs.getString("Cast"),rs.getString("ImgCopertina"),
											rs.getString("Trailer"), new ArrayList<Genere>(),
											new ArrayList<Piattaforma>(), rs.getString("Stagioni"),rs.getString("Puntate"),Float.valueOf(rs.getFloat("DurataEp")),
											rs.getInt("miPiace"),rs.getFloat("Valutazione")
										)
							);
			}
			rs.close();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}finally
		{
			MovieDB.releaseConnection(conn);
		}
		return contenuti;
	}	
	/**
	 * 
	 * @param email the email of the user you want to find the seen contents
	 * @return the seen contents
	 */
	public ArrayList<Contenuto> findVisti(String email){
		Connection conn=MovieDB.getConnection();
		ArrayList<Contenuto> contenuti=new ArrayList<>();
		String query="SELECT * FROM contenuto inner join film on IDContenuto=Film.Contenuto_IDContenuto inner join visti on IDContenuto=Visti.Contenuto_IDContenuto WHERE Utente_Email='"+email+"' order by Titolo DESC;";
		ResultSet rs=qm.execQuery(query, conn);
		try {
			while(rs.next())
			{
				contenuti.add(
								new Film(
											rs.getInt("IDContenuto"),rs.getString("Titolo"),
											rs.getString("AnnoProduzione"),rs.getString("Sinossi"),
											rs.getString("Cast"),rs.getString("ImgCopertina"),
											rs.getString("Trailer"), new ArrayList<Genere>(),
											new ArrayList<Piattaforma>(), Float.valueOf(rs.getFloat("Durata")),rs.getString("Regista"),
											rs.getInt("miPiace"),rs.getFloat("Valutazione")
										)
							);
			}
			query="SELECT * FROM contenuto inner join serieTv on IDContenuto=SerieTv.Contenuto_IDContenuto inner join visti on IDContenuto=Visti.Contenuto_IDContenuto WHERE Utente_Email='"+email+"' order by Titolo DESC;";
			rs=qm.execQuery(query, conn);
			while(rs.next())
			{
				contenuti.add(
								new SerieTv(
											rs.getInt("IDContenuto"),rs.getString("Titolo"),
											rs.getString("AnnoProduzione"),rs.getString("Sinossi"),
											rs.getString("Cast"),rs.getString("ImgCopertina"),
											rs.getString("Trailer"), new ArrayList<Genere>(),
											new ArrayList<Piattaforma>(), rs.getString("Stagioni"),rs.getString("Puntate"),Float.valueOf(rs.getFloat("DurataEp")),
											rs.getInt("miPiace"),rs.getFloat("Valutazione")
										)
							);
			}
			rs.close();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}finally
		{
			MovieDB.releaseConnection(conn);
		}
		return contenuti;
	}	
	
	/**
	 * 
	 * @param email the email for which you want to know if it is present in the system
	 * @return true if the mail is present in the system, false otherwise
	 */
	public boolean findEmail(String email) {
		Connection conn=MovieDB.getConnection();
		boolean present=false;
		try
		{
			String query="SELECT email FROM UTENTE WHERE Email='"+email+"';";
			ResultSet rs=qm.execQuery(query, conn);
			if(rs.next()) 
			{
				present=true;
			}
			rs.close();
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			MovieDB.releaseConnection(conn);
		}
		return present;
	}
}
