package org.movied.model.dao;

import org.movied.control.db.MovieDB;
import org.movied.control.db.QueryManager;
import org.movied.model.bean.Film;
import org.movied.model.bean.Contenuto.Genere;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class FilmDao {

	private static QueryManager qm=new QueryManager();
	
	public FilmDao() {}
	
	/**
	 * 
	 * @param film is the film you want to insert in the system
	 * @return the number of rows updated 
	 */
	public Integer insertFilmContent(Film film) {
		int n=0;
		Connection conn=MovieDB.getConnection();
		String query="insert into contenuto (Titolo, Sinossi, AnnoProduzione, ImgCopertina, Trailer, MiPiace, Cast, Valutazione)" + 
					 "values ('"+film.getTitolo()+"','"+film.getSinossi()+"','"
								+film.getAnno()+"','"+film.getImgCopertina()+"','"
								+film.getTrailer()+"',"+film.getMiPiace()+",'"+film.getCast()+"',"+film.getValutazione()+");";
		n=qm.execUpdate(query, conn);
		if(n==1) {
			query="SELECT MAX(IDContenuto) as ID FROM contenuto";
			String id=null;
			ResultSet rs=qm.execQuery(query, conn);
			try {
				if(rs.next()) {
					id=rs.getString("ID");
				}
			} 
			catch (SQLException e) {
				e.printStackTrace();
			}
			
			query="insert into film (Durata, Regista, Contenuto_IDContenuto) values ("+film.getDurata()+",'"+film.getRegista()+"',"+id+");";
			qm.execUpdate(query, conn);
			for(Genere g : film.getGeneri()) {
	            query="insert into Genere (Tipo, Contenuto_IDContenuto)"+"values ('"+g.toString()+"',"+id+");";
	            qm.execUpdate(query, conn);
	        }
			MovieDB.releaseConnection(conn);
		}
		return n;	
	}
}
