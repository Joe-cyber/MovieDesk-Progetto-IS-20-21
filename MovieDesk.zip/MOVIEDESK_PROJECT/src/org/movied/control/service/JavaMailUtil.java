package org.movied.control.service;

import java.util.Properties;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;


public class JavaMailUtil {
	public enum EmailType
	{
		RICHIESTA_DI_SOSTITUZIONE,
		NUOVA_PASSWORD
	}
	/**
	 * 
	 * @param recipient the recipient's email 
	 * @param content the mail's object
	 * @param type email's type 
	 */
	public static void sendMail(String recipient,String content,EmailType type) 
	{
		Properties properties= new Properties();
		//smtp.gmail.com
		//port 587
		properties.put("mail.smtp.auth","true");
		properties.put("mail.smtp.starttls.enable","true");
		properties.put("mail.smtp.host", "smtp.gmail.com");
		properties.put("mail.smtp.port", "587");

		String myAccount="moviedb8@gmail.com";
		String password="UnaPassword";

		Session session=Session.getInstance(properties, new Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication(){
				return new PasswordAuthentication(myAccount, password);
			}
		});
		Message message=null;
		if(type.equals(EmailType.RICHIESTA_DI_SOSTITUZIONE))
			message=prepareRichiestaSostituzione(session,myAccount,recipient,content);
		if(type.equals(EmailType.NUOVA_PASSWORD))
			message=prepareNuovaPassword(session, myAccount, recipient, content);
		try 
		{
			Transport.send(message);
		} 
		catch (MessagingException e) 
		{
			e.printStackTrace();
		}
	}

	private static Message prepareRichiestaSostituzione(Session session,String myAccount,String recipient,String link) {
		try 
		{
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(myAccount));
			message.setRecipient(Message.RecipientType.TO, new InternetAddress(recipient));
			message.setSubject("RICHIESTA DI RIPRISTINO PASSWORD");
			message.setText("Ecco come fare per ricevere una nuova password.\r\n" + 
							"Abbiano recentemente ricevuto la richiesta di ripristinare la password del tuo account: "+recipient+"\r\n" + 
							"\r\n" + 
							"Per ripristinare la password, fai clic su questo collegamento (oppure copiarlo e incollarlo nel browser):\r\n" + 
							"\r\n" +link+"\r\n" + 
							"Se non hai richiesto di ripristinare la password, ignora questo messaggio.\r\n Non verr� apportata alcuna modifica al tuo account. Ricorda, il tuo ID LogMeIn e la relativa password, ti offrono l�accesso a diversi straordinari prodotti di JFLCorporation.");
			return message;
		} 
		catch (MessagingException e) 
		{
			Logger.getLogger(JavaMailUtil.class.getName()).log(Level.SEVERE,null,e);
		} 
		return null;
	}
	
	private static Message prepareNuovaPassword(Session session,String myAccount,String recipient,String password) {
		try 
		{
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(myAccount));
			message.setRecipient(Message.RecipientType.TO, new InternetAddress(recipient));
			message.setSubject("RIPRISTINO PASSWORD");
			message.setText("La tua nuova password � : "+password);
			return message;
		} 
		catch (MessagingException e) 
		{
			Logger.getLogger(JavaMailUtil.class.getName()).log(Level.SEVERE,null,e);
		} 
		return null;
	}
	
	/**
	 * 
	 * @return a random new password of ten digits 
	 */
	public static String generatorRandomPassword() 
	{
		int leftLimit = 97; // letter 'a'
		int rightLimit = 122; // letter 'z'
		int targetStringLength = 10;
		Random random = new Random();
		StringBuilder buffer = new StringBuilder(targetStringLength);
		for (int i = 0; i < targetStringLength; i++)
		{
		    int randomLimitedInt = leftLimit + (int)(random.nextFloat() * (rightLimit - leftLimit + 1));
	        buffer.append((char) randomLimitedInt);
		}
		String generatedString = buffer.toString();
	    return generatedString;
	}

}
