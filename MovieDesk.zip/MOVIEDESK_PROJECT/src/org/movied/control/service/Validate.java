package org.movied.control.service;

import java.util.regex.Pattern;

public class Validate 
{
	/**
	 * 
	 * @param email that you want to validate
	 * @return 0 if the value respect length and format, 1 if the value doesn't respect length, 2 if the value doesn't respect the format 
	 */
	public static int email(String email) {
		Pattern emailCheck=Pattern.compile("^[a-zA-Z0-9]+([.-]?[a-zA-z0-9]+)@[a-zA-Z0-9]+([.-]?[a-zA-Z0-9]+)(.[com,it]{2,3}){1,200}$",Pattern.CASE_INSENSITIVE);

		if(email.length()>200 || email.length()<1)
			return 1;
		else if(email != null && emailCheck.matcher(email).matches())
			return 0;
		else 
			return 2;
	}
	/**
	 * 
	 * @param password that you want to validate
	 * @return 0 if the value respect length and format, 1 if the value doesn't respect length, 2 if the value doesn't respect the format 
	 */
	public static int password(String password) {
		Pattern passwordCheck=Pattern.compile("^[A-Za-z0-9]{8,32}$");
		if((password != null) && (passwordCheck.matcher(password).matches()))
			return 0;
		else if(password.length()>32 || password.length()<8)
			return 1;
		else 
			return 2;
	}
	/**
	 *  
	 * @param regista that you want to validate
	 * @return 0 if the value respect length and format, 1 if the value doesn't respect length, 2 if the value doesn't respect the format 
	 */
	public static int regista(String regista) {
		Pattern registaCheck=Pattern.compile("^[a-zA-Z- ]{1,100}$");
		if((regista != null) && (registaCheck.matcher(regista).matches()))
			return 0;
		else if(regista.length()>100 || regista.length()<1)
			return 1;
		else 
			return 2;
	}

	/**
	 * 
	 * @param anno that you want to validate
	 * @return 0 if the value respect length and format, 1 if the value doesn't respect length, 2 if the value doesn't respect the format 
	 */
	public static int anno(String anno) {
		Pattern annoCheck=Pattern.compile("^\\d{4}");
		if((anno != null) && (annoCheck.matcher(anno).matches()))
			return 0;
		else if(anno.length()!=4)
			return 1;
		else 
			return 2;
	}
	/**
	 * 
	 * @param cast that you want to validate
	 * @return 0 if the value respect length and format, 1 if the value doesn't respect length, 2 if the value doesn't respect the format
	 */
	public static int cast(String cast) {
		Pattern castCheck=Pattern.compile("^[A-Za-z0-9',-.'����� ]{1,500}$");
		if ((cast != null) && (castCheck.matcher(cast).matches()))
			return 0;
		else if(cast.length()>500 || cast.length()<1)
			return 1;
		else 
			return 2;
	}
	/**
	 * 
	 * @param link that you want to validate
	 * @return 0 if the value respect length and format, 1 if the value doesn't respect length, 2 if the value doesn't respect the format
	 */
	public static int link(String link) {
		Pattern linkCheck=Pattern.compile("\\b(https?|ftp|file)://[-a-zA-Z0-9+&@#/%?=~_|!:,.;]*[-a-zA-Z0-9+&@#/%=~_|]");
		if ((link != null) && (linkCheck.matcher(link).matches()))
			return 0;
		else if(link.length()>2048 || link.length()<1)
			return 1;
		else 
			return 2;
	}
	/**
	 * 
	 * @param titolo that you want to validate
	 * @return 0 if the value respect length and format, 1 if the value doesn't respect length, 2 if the value doesn't respect the format
	 */
	public static int titolo(String titolo) {
		Pattern titoloCheck=Pattern.compile("^[A-Za-z0-9',-.����� ]{1,50}$");
		if ((titolo != null) && (titoloCheck.matcher(titolo).matches()))
			return 0;
		else if(titolo.length()>50 || titolo.length()<1)
			return 1;
		else 
			return 2;
	}
	/**
	 * 
	 * @param valutazione that you want to validate
	 * @return 0 if the value respect length and format, 1 if the value doesn't respect length, 2 if the value doesn't respect the format
	 */
	public static int valutazione(String valutazione) {
		Pattern valutazioneCheck=Pattern.compile("^[1-4][.][0-9]$|^[1-5]$");
		if ((valutazione != null) && (valutazioneCheck.matcher(valutazione).matches()))
			return 0;		
		else if(valutazione.length()>5||valutazione.length()<1)
			return 1;
		else 
			return 2;
	}
	/**
	 * 
	 * @param sinossi that you want to validate
	 * @return 0 if the value respect length and format, 1 if the value doesn't respect length, 2 if the value doesn't respect the format
	 */
	public static int sinossi(String sinossi) {
		Pattern sinossiCheck=Pattern.compile("^[A-Za-z0-9',-:.�����\\s]{1,500}$");
		if((sinossi != null) && (sinossiCheck.matcher(sinossi).matches()))
			return 0;
		else if(sinossi.length()>500 || sinossi.length()<1)
			return 1;
		else 
			return 2;
	}
	/**
	 * 
	 * @param durata that you want to validate
	 * @return 0 if the value respect length and format, 1 if the value doesn't respect length, 2 if the value doesn't respect the format
	 */
	public static int durata(String durata) {
		Pattern durataCheck=Pattern.compile("^\\d{1,3}.([0-5][0-9])$");
		if ((durata != null) && (durataCheck.matcher(durata).matches()))
			return 0;
		else if(durata.length()>5||durata.length()<1)
			return 1;
		else 
			return 2;
	}
	/**
	 * 
	 * @param numStagioni that you want to validate
	 * @return 0 if the value respect length and format, 1 if the value doesn't respect length, 2 if the value doesn't respect the format
	 */
	public static int numStagioni(String numStagioni) {
		Pattern numStagioniCheck=Pattern.compile("^\\d{1,2}$");
		if ((numStagioni != null) && (numStagioniCheck.matcher(numStagioni).matches()))
			return 0;
		else if(numStagioni.length()>5||numStagioni.length()<1)
			return 1;
		else 
			return 2;
	}
	/**
	 * 
	 * @param numEpisodi that you want to validate
	 * @return 0 if the value respect length and format, 1 if the value doesn't respect length, 2 if the value doesn't respect the format
	 */
	public static int numEpisodi(String numEpisodi) {
		Pattern numEpisodiCheck=Pattern.compile("^\\d{1,4}$");
		if ((numEpisodi != null) && (numEpisodiCheck.matcher(numEpisodi).matches()))
			return 0;
		else if(numEpisodi.length()>4||numEpisodi.length()<1)
			return 1;
		else 
			return 2;
	}
	/**
	 * 
	 * @param abbonamento that you want to validate
	 * @return 0 if the value respect length and format, 1 if the value doesn't respect length, 2 if the value doesn't respect the format
	 */
	public static int abbonamento(String abbonamento) {
		Pattern abbonamentoCheck=Pattern.compile("^[0-9]{1,2}(.\\d{2})$|^\\d{1,5}$");
		if((abbonamento != null) && (abbonamentoCheck.matcher(abbonamento).matches()))
			return 0;
		else if(abbonamento.length()>5||abbonamento.length()<1)
			return 1;
		else 
			return 2;
	}
	/**
	 * 
	 * @param oggetto that you want to validate
	 * @return 0 if the value respect length and format, 1 if the value doesn't respect length, 2 if the value doesn't respect the format
	 */
	public static int oggetto(String oggetto) {
		Pattern oggettoCheck=Pattern.compile("^[A-Za-z0-9',-.�����\\s]{1,26}$");
		if(oggetto!=null &&(oggettoCheck.matcher(oggetto).matches()))
			return 0;
		else if(oggetto.length()>25||oggetto.length()<1)
			return 1;
		else 
			return 2;
	}
	/**
	 * 
	 * @param s the link that you want to suppress the special characters
	 * @return the link with the escape characters
	 * @throws Exception 
	 */
	public static String replaceString (String s)
	{
		return s.replace("'", "\\'");
	}
}
