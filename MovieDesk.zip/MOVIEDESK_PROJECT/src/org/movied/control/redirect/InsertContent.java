package org.movied.control.redirect;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.movied.model.bean.Film;
import org.movied.model.bean.Piattaforma;
import org.movied.model.bean.SerieTv;
import org.movied.model.bean.Contenuto.Genere;
import org.movied.model.dao.FilmDao;
import org.movied.model.dao.SerieTVDao;
import org.movied.control.service.Validate;


@WebServlet("/InsertContent")
public class InsertContent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public InsertContent() {
        super();
    }
    /**
	 * @param request the server request
	 * @param response the server response
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	/**
	 * @param request the server request
	 * @param response the server response
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getServletContext().getAttribute("MovieDB");
		FilmDao daoFilm=new FilmDao();
		SerieTVDao daoSerie=new SerieTVDao();
		String message="Aggiunta fallita";
		int n;
		ArrayList<Genere> generi = new ArrayList<Genere>();
		
		if(request.getParameter("genere1")!=null)
			generi.add(Genere.valueOf(request.getParameter("genere1")));
		if(request.getParameter("genere2")!=null)
			generi.add(Genere.valueOf(request.getParameter("genere2")));
		if(request.getParameter("Regista")!=null && request.getParameter("Durata")!=null) {
			if((n=Validate.titolo(request.getParameter("Titolo")))==0){
				if((n=Validate.link(request.getParameter("ImgCopertina")))==0){
					if((n=Validate.link(request.getParameter("Trailer")))==0){
						if((n=Validate.cast(request.getParameter("Cast")))==0){
							if((n=Validate.sinossi(request.getParameter("Sinossi")))==0){
								if((n=Validate.anno(request.getParameter("AnnoDiProduzione")))==0){
									if((n=Validate.durata(request.getParameter("Durata")))==0){
										if((n=Validate.regista(request.getParameter("Regista")))==0){
											if(generi.size()!=0) {
												if((n=Validate.valutazione(request.getParameter("Valutazione")))==0){
													Film film=new Film(
															0,Validate.replaceString(request.getParameter("Titolo")),
															request.getParameter("AnnoDiProduzione"),Validate.replaceString(request.getParameter("Sinossi")),
															Validate.replaceString(request.getParameter("Cast")),Validate.replaceString(request.getParameter("ImgCopertina")),
															Validate.replaceString(request.getParameter("Trailer")), generi,
															new ArrayList<Piattaforma>(), Float.valueOf(request.getParameter("Durata")),Validate.replaceString(request.getParameter("Regista")),
															Integer.valueOf(0),Float.parseFloat(request.getParameter("Valutazione"))
														);
													if(daoFilm.insertFilmContent(film)>0)
														message="Aggiunta avvenuta con successo.";
												}
												else if(n==1)
													message="Le valutazioni non rispettano la lunghezza richiesta.";
												else
													message="Le valutazioni non rispettano il formato richiesto.";
											}
											else
												message="Il genere non � stato selezionato.";
										}
										else if(n==1)
											message="Il regista non rispetta la lunghezza richiesta.";
										else
											message="Il regista non rispetta il formato richiesto.";
									}
									else if(n==1)
										message="La durata non rispetta la lunghezza richiesta.";
									else
										message="La durata non rispetta il formato richiesto.";
								}
								else if(n==1)
									message="L'anno di produzione non rispetta la lunghezza richiesta.";
								else
									message="L'anno di produzione non rispetta il formato richiesto.";
							}
							else if(n==1)
								message="La sinossi non rispetta la lunghezza richiesta.";
							else
								message="La sinossi non rispetta il formato richiesto.";
						}
						else if(n==1)
							message="Il cast non rispetta la lunghezza richiesta.";
						else
							message="Il cast non rispetta il formato richiesto.";
					}
					else if(n==1)
						message="Il trailer non rispetta la lunghezza richiesta.";
					else
						message="Il trailer non rispetta il formato richiesto.";
				}
				else if(n==1)
					message="L'immagine di copertina non rispetta la lunghezza richiesta.";
				else
					message="L'immagine di copertina non rispetta il formato richiesto.";
			}
			else if(n==1)
				message="Il titolo non rispetta la lunghezza richiesta.";
			else
				message="Il titolo non rispetta il formato richiesto.";
		}
		else if(request.getParameter("Stagioni")!=null&&request.getParameter("Puntate")!=null&&request.getParameter("DurataEp")!=null) {
			if((n=Validate.titolo(request.getParameter("Titolo")))==0){
				if((n=Validate.link(request.getParameter("ImgCopertina")))==0){
					if((n=Validate.link(request.getParameter("Trailer")))==0){
						if((n=Validate.cast(request.getParameter("Cast")))==0){
							if((n=Validate.sinossi(request.getParameter("Sinossi")))==0){
								if((n=Validate.anno(request.getParameter("AnnoDiProduzione")))==0){
									if((n=Validate.durata(request.getParameter("DurataEp")))==0){
										if((n=Validate.numEpisodi(request.getParameter("Puntate")))==0){
											if(generi.size()!=0) {
												if((n=Validate.numStagioni(request.getParameter("Stagioni")))==0){
													if((n=Validate.valutazione(request.getParameter("Valutazione")))==0){
														SerieTv serie=new SerieTv(
																0,Validate.replaceString(request.getParameter("Titolo")),
																request.getParameter("AnnoDiProduzione"),Validate.replaceString(request.getParameter("Sinossi")),
																Validate.replaceString(request.getParameter("Cast")),Validate.replaceString(request.getParameter("ImgCopertina")),
																Validate.replaceString(request.getParameter("Trailer")), generi,
																new ArrayList<Piattaforma>(), request.getParameter("Stagioni"),request.getParameter("Puntate"),Float.parseFloat(request.getParameter("DurataEp")),
																Integer.valueOf(0),Float.parseFloat(request.getParameter("Valutazione"))
															);
														if(daoSerie.insertSerieTVContent(serie)>0)
															message="Aggiunta avvenuta con successo.";
													}
													else if(n==1)
														message="Le valutazioni non rispettano la lunghezza richiesta.";
													else
														message="Le valutazioni non rispettano il formato richiesto.";
												}
												else if(n==1)
													message="Il numero di stagioni non rispetta la lunghezza richiesta.";
												else
													message="Il numero di stagioni non rispetta il formato richiesto.";
											}
											else
												message="Il genere non � stato selezionato.";
										}
										else if(n==1)
											message="Il numero di puntate non rispetta la lunghezza richiesta.";
										else
											message="Il numero di puntate non rispetta il formato richiesto.";
									}
									else if(n==1)
										message="La durata media episodio non rispetta la lunghezza richiesta.";
									else
										message="La durata media episodio non rispetta il formato richiesto.";
								}
								else if(n==1)
									message="L'anno di produzione non rispetta la lunghezza richiesta.";
								else
									message="L'anno di produzione non rispetta il formato richiesto.";
							}
							else if(n==1)
								message="La sinossi non rispetta la lunghezza richiesta.";
							else
								message="La sinossi non rispetta il formato richiesto.";
						}
						else if(n==1)
							message="Il cast non rispetta la lunghezza richiesta.";
						else
							message="Il cast non rispetta il formato richiesto.";
					}
					else if(n==1)
						message="Il trailer non rispetta la lunghezza richiesta.";
					else
						message="Il trailer non rispetta il formato richiesto.";
				}
				else if(n==1)
					message="L'immagine di copertina non rispetta la lunghezza richiesta.";
				else
					message="L'immagine di copertina non rispetta il formato richiesto.";
			}
			else if(n==1)
				message="Il titolo non rispetta la lunghezza richiesta.";
			else
				message="Il titolo non rispetta il formato richiesto.";
		}	
		request.setAttribute("message", message);
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("message.jsp");
		requestDispatcher.forward(request, response);
	}
}
