package org.movied.control.redirect;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.movied.model.bean.Contenuto;
import org.movied.model.dao.ContenutoDao;

@WebServlet("/RemoveContent")
public class RemoveContent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public RemoveContent() {
        super();
      
    }
    /**
	 * @param request the server request
	 * @param response the server response
	 */
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

    /**
	 * @param request the server request
	 * @param response the server response
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getServletContext().getAttribute("MovieDB");
        ContenutoDao dao=new ContenutoDao();
        String message="";
        
        if(request.getParameter("contentKey")!=null && !request.getParameter("contentKey").equals("")) {
	        Contenuto c = dao.getContentDetails(Integer.parseInt(request.getParameter("contentKey")));
	        
	        if(c!=null) {
	        	dao.removeContent(c);
	            message="Rimozione avvenuta con successo.";
	        }
	        else
	        	message="Rimozione fallita.";
	        request.setAttribute("message", message);
        }
        else
        	message="Il titolo non � stato selezionato.";
        RequestDispatcher requestDispatcher = request.getRequestDispatcher("message.jsp");
        requestDispatcher.forward(request, response);
        
	}

}
