package org.movied.control.redirect;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.movied.control.service.Validate;
import org.movied.model.bean.Contenuto;
import org.movied.model.bean.UtenteRegistrato;
import org.movied.model.dao.ContenutoDao;

@WebServlet(name = "ContentList", urlPatterns = { "/ContentList" })
public class ContentList extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
    public ContentList() 
    {
        super();
    }
    
    /**
	 * @param request the server request
	 * @param response the server response
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		int c;
		request.getServletContext().getAttribute("MovieDB");
		String message="Siamo spiacenti, il contenuto non � stato trovato.";
		ArrayList<Contenuto> contenuti=new ArrayList<>();
		ContenutoDao dao=new ContenutoDao();
		if(request.getParameter("filter")!=null){
			if(request.getParameter("filter").contentEquals("genere")) {
				contenuti=dao.selectContent("genere",request.getParameter("value"));	
			}
			else if(request.getParameter("filter").equals("recommended")){
				HttpSession session=request.getSession(false);
				UtenteRegistrato u=(UtenteRegistrato)session.getAttribute("utente");
				if(u==null) {
					request.setAttribute("message", "Accedi per visualizzare i contenuti pi� adatti a te");
					RequestDispatcher requestDispatcher = request.getRequestDispatcher("message.jsp");
					requestDispatcher.forward(request, response);
					return;
				}
				contenuti=dao.selectContent("consigliati",u.getEmail());
			}
			else if(request.getParameter("filter").equals("valutazioni")){
					contenuti=dao.selectContent("valutazioni","");
			}
			else {
				request.setAttribute("message", "Accedi per visualizzare i contenuti pi� adatti a te");
				RequestDispatcher requestDispatcher = request.getRequestDispatcher("message.jsp");
				requestDispatcher.forward(request, response);
				return;
			}
		}
		else if(request.getParameter("title")!=null) {
			if((c=Validate.titolo(request.getParameter("title")))==0) 
				contenuti=dao.selectContent(request.getParameter("title"));			
			else if(c==1)
				message="Il titolo non rispetta la lunghezza richiesto.";
			else 
				message="Il titolo non rispetta il formato richiesta.";
		}
		else if(request.getParameter("year")!=null){
			if(!request.getParameter("year").equals(""))
				contenuti=dao.selectContent("anno",request.getParameter("year"));	
			else 
				message="Seleziona un anno di produzione per filtrare la visualizzazione.";
		}
		else{
			contenuti=dao.selectContent();	
		}
		request.setAttribute("message", message);
		request.setAttribute("contenuti",contenuti);	
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("contenuti.jsp");
		requestDispatcher.forward(request, response);
		
	}

	/**
	 * @param request the server request
	 * @param response the server response
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request, response);
	}
}