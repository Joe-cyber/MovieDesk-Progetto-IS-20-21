package org.movied.control.redirect;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.movied.control.service.Validate;
import org.movied.model.bean.Piattaforma;
import org.movied.model.dao.PiattaformaDao;


@WebServlet("/InsertPlatform")
public class InsertPlatform extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public InsertPlatform() {
        super();
    }

    /**
	 * @param request the server request
	 * @param response the server response
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * @param request the server request
	 * @param response the server response
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
	        request.getServletContext().getAttribute("MovieDB");
	        PiattaformaDao dao=new PiattaformaDao();
	        String message="Aggiunta fallita";
	        int n;
	        if((n=Validate.titolo(request.getParameter("nomePiattaforma")))==0) {
	        	if((n=Validate.link(request.getParameter("imgPiattaforma")))==0) {
			        if((n=Validate.abbonamento(request.getParameter("abbonamentoMinimo")))==0) {
			        	if((n=Validate.link(request.getParameter("link")))==0) {
				        	Piattaforma p=new Piattaforma (	        	
			                        Validate.replaceString(request.getParameter("imgPiattaforma")),
			                        request.getParameter("nomePiattaforma"),
			                        Validate.replaceString(request.getParameter("link")),
			                        Float.parseFloat(request.getParameter("abbonamentoMinimo"))
			                    );
							if(dao.insertPiattaforma(p)>0)
								message="Aggiunta avvenuta con successo.";
				        }
						else if(n==1)
							message="Il link di riferimento non rispetta la lunghezza richiesta.";
						else
							message="Il link di riferimento non rispetta il formato richiesto.";
			        }
					else if(n==1)
						message="L'abbonamento minimo non rispetta la lunghezza richiesta.";
					else
						message="L'abbonamento minimo non rispetta il formato richiesto.";
		        }
				else if(n==1)
					message="L'immagine della piattaforma non rispetta la lunghezza richiesta.";
				else
					message="L'immagine della piattaforma non rispetta il formato richiesto.";
	        }
			else if(n==1)
				message="Il nome della piattaforma non rispetta la lunghezza richiesta.";
			else
				message="Il nome della piattaforma non rispetta il formato richiesto.";
	        
	        
	        request.setAttribute("message", message);
	        
	        RequestDispatcher requestDispatcher = request.getRequestDispatcher("message.jsp");
	        requestDispatcher.forward(request, response);
	    }
	}


