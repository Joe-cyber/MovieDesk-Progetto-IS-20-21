package org.movied.control.redirect;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.movied.model.bean.Contenuto;
import org.movied.model.dao.ContenutoDao;


@WebServlet("/Details")
public class Details extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public Details() {
        super();
    }
    /**
	 * @param request the server request
	 * @param response the server response
	 */
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		request.getServletContext().getAttribute("MovieDB");
		Contenuto content;
		ContenutoDao dao=new ContenutoDao();
		String text="";
		
		if(request.getParameter("id")!=null){
			content=dao.getContentDetails(Integer.parseInt(request.getParameter("id")));	
			text="Con titolo vuoto";
			request.setAttribute("text", text);
			request.setAttribute("content",content);
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("contenuto-details.jsp");
			requestDispatcher.forward(request, response);
		}
		else {
			request.setAttribute("message", "Si � verificato un problema durante la selezione dei dati");
			RequestDispatcher rd=request.getRequestDispatcher("/message.jsp");
			rd.forward(request, response);
		}
	}
    /**
	 * @param request the server request
	 * @param response the server response
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request, response);
	}
}
