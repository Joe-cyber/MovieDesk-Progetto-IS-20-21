package org.movied.control.redirect;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.movied.model.bean.Contenuto;
import org.movied.model.bean.UtenteRegistrato;
import org.movied.model.dao.UtenteRegistratoDao;


@WebServlet("/Mark")
public class Mark extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public Mark() {
        super();
    }
    /**
	 * @param request the server request
	 * @param response the server response
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	/**
	 * @param request the server request
	 * @param response the server response
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String message="Devi essere loggato per aggiungere una marcatura";
		HttpSession session=request.getSession(false);
		request.getServletContext().getAttribute("MovieDB");
		UtenteRegistratoDao dao=new UtenteRegistratoDao();
		UtenteRegistrato user=(UtenteRegistrato) session.getAttribute("utente");
		if(user!=null) {
			if(dao.insertMark(request.getParameter("id"), request.getParameter("tag"),user)>0)
				message="Marcatura aggiunta";
			else
				message="Marcatura non aggiunta";
			
			ArrayList<Contenuto> piaciuti= dao.findPiaciuti(user.getEmail());
			session.setAttribute("piaciuti", piaciuti);
			ArrayList<Contenuto> preferiti= dao.findPreferiti(user.getEmail());
			session.setAttribute("preferiti", preferiti);
			ArrayList<Contenuto> visti= dao.findVisti(user.getEmail());
			session.setAttribute("visti", visti);
		}
		
		request.setAttribute("message", message);
		
		
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("message.jsp");
		requestDispatcher.forward(request, response);
		
	}
}
