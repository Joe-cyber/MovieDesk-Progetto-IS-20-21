package org.movied.control.redirect;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.movied.control.service.JavaMailUtil;
import org.movied.control.service.Validate;
import org.movied.control.service.JavaMailUtil.EmailType;
import org.movied.model.dao.UtenteRegistratoDao;


@WebServlet(name = "EmailCheck", urlPatterns = { "/EmailCheck" })
	
public class EmailCheck extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public EmailCheck() {
        super();
    }
    /**
	 * @param request the server request
	 * @param response the server response
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		request.getServletContext().getAttribute("MovieDB");
		UtenteRegistratoDao dao=new UtenteRegistratoDao();
		if((Validate.email(request.getParameter("email"))==0)&&(dao.findEmail(request.getParameter("email"))))
		{
			HttpSession session=request.getSession(true);
			session.setMaxInactiveInterval(10*60);
			String email=request.getParameter("email");
			String link = "http://localhost:8088/MOVIEDESK_PROJECT/ResetPassword?email="+email;
			JavaMailUtil.sendMail(email,link,EmailType.RICHIESTA_DI_SOSTITUZIONE);
			response.setStatus(HttpServletResponse.SC_ACCEPTED);
		}
		else
			response.setStatus(HttpServletResponse.SC_FORBIDDEN);
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("recover-password.jsp");
		requestDispatcher.forward(request, response);
	}

	/**
	 * @param request the server request
	 * @param response the server response
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
