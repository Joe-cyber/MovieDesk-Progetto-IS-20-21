package org.movied.control.redirect;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.movied.model.dao.PiattaformaDao;


@WebServlet("/RemovePlatform")
public class RemovePlatform extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public RemovePlatform() {
        super();
    }

    /**
	 * @param request the server request
	 * @param response the server response
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * @param request the server request
	 * @param response the server response
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getServletContext().getAttribute("MovieDB");
        PiattaformaDao dao=new PiattaformaDao();
        String message="Il nome non � stato selezionato.";
        if(request.getParameter("nome")!=null && !request.getParameter("nome").equals(""))
        {
	        if(dao.removePiattaforma(request.getParameter("nome"))>0)
	            message="Rimozione avvenuta con successo.";
	        else
	            message="Rimozione fallita.";
        }
        request.setAttribute("message", message);
        RequestDispatcher requestDispatcher = request.getRequestDispatcher("message.jsp");
        requestDispatcher.forward(request, response);     
	}
}
