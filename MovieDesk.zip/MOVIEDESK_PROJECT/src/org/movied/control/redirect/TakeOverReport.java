package org.movied.control.redirect;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.movied.model.bean.Segnalazione.Stato;
import org.movied.model.bean.UtenteRegistrato;
import org.movied.model.dao.SegnalazioneDao;

@WebServlet("/TakeOverReport")
public class TakeOverReport extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
    public TakeOverReport() {
        super();
    }

    /**
	 * @param request the server request
	 * @param response the server response
	 */	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}
	/**
	 * @param request the server request
	 * @param response the server response
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession(false);
        UtenteRegistrato user=(UtenteRegistrato) session.getAttribute("utente");
        request.getServletContext().getAttribute("MovieDB");
        SegnalazioneDao dao=new SegnalazioneDao();
        String message="Segnalazione � presa in incarico da un altro utente";
        if(dao.selectSingleReport(Integer.parseInt(request.getParameter("IdSegnalazione"))).getStato().equals(Stato.Ricevuta))
	        if(dao.updateStatusReport(request.getParameter("IdSegnalazione"), Stato.PresaIncarico, user.getEmail())>0)
	            message="Segnalazione presa in incarico";
            
        request.setAttribute("message", message);
        RequestDispatcher requestDispatcher = request.getRequestDispatcher("message.jsp");
        requestDispatcher.forward(request, response);
	}

}
