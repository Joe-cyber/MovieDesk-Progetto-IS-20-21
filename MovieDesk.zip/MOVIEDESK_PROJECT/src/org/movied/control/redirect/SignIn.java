package org.movied.control.redirect;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.movied.control.service.Validate;
import org.movied.model.bean.UtenteMediaManager;
import org.movied.model.bean.Segnalazione;
import org.movied.model.bean.UtenteRegistrato;
import org.movied.model.dao.SegnalazioneDao;
import org.movied.model.dao.UtenteRegistratoDao;

@WebServlet(name = "SignIn", urlPatterns = { "/SignIn" })
public class SignIn extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
     
    public SignIn() 
    {
        super();
    }
    /**
	 * @param request the server request
	 * @param response the server response
	 */
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
    	doPost(request,response);
	}
    /**
	 * @param request the server request
	 * @param response the server response
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		request.getServletContext().getAttribute("MovieDB");
		UtenteRegistratoDao dao = new UtenteRegistratoDao();
		UtenteRegistrato utente;
		int n1,n2=0;
		if((n1=Validate.password(request.getParameter("j_password")))==0 && (n2=Validate.email(request.getParameter("j_username")))==0) {
			utente=dao.findUtente(request.getParameter("j_username"),request.getParameter("j_password"));	
			if(utente==null)
			{
				String message="Email o password errati.";
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				request.setAttribute("message", message);
				RequestDispatcher rdd=request.getRequestDispatcher("/login.jsp");
				rdd.forward(request, response);
				return;
			}
			utente.setPiaciuti(dao.findPiaciuti(utente.getEmail()));
			utente.setPreferiti(dao.findPreferiti(utente.getEmail()));
			utente.setVisti(dao.findVisti(utente.getEmail()));
			
			HttpSession session=request.getSession(true);
			
			
			
			if(utente.getTipo().equals("MM")) {
				ArrayList<Segnalazione> ricevute;
				SegnalazioneDao segnalazioneDao=new SegnalazioneDao();
				UtenteMediaManager utente2=new UtenteMediaManager(utente.getNome(),utente.getCognome(),utente.getEmail(),utente.getPassword(),utente.getPreferiti(),utente.getPiaciuti(),utente.getVisti());
				utente2.setReports(new SegnalazioneDao().selectReport(utente2.getEmail()));
				ricevute=segnalazioneDao.selectReport();
				session.setAttribute("utente", utente2);
				session.setAttribute("ricevute",ricevute);
			}
			else {
				session.setAttribute("utente", utente);
			}
			session.setMaxInactiveInterval(10*60);
		}
		else{
			String message="Email o password errati.";
			response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			if(n2==1)
				message="L'email non rispetta la lunghezza richiesta.";
			else if(n2==2)
				message="L'email non rispetta il formato richiesto.";
			else if(n1==1)
				message="La password non rispetta la lunghezza richiesta.";
			else if(n1==2)
				message="La password non rispetta il formato richiesto.";
			request.setAttribute("message", message);
			RequestDispatcher rdd=request.getRequestDispatcher("/login.jsp");
			rdd.forward(request, response);
			return;
		}
		response.sendRedirect("j_security_check?j_username="+request.getParameter("j_username")+"&j_password="+request.getParameter("j_password"));
	}
}
