package org.movied.control.redirect;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.movied.control.service.Validate;
import org.movied.model.bean.Segnalazione;
import org.movied.model.bean.UtenteRegistrato;
import org.movied.model.dao.SegnalazioneDao;


@WebServlet("/SendReport")
public class SendReport extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public SendReport() {
        super();
    }

    /**
	 * @param request the server request
	 * @param response the server response
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	/**
	 * @param request the server request
	 * @param response the server response
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getServletContext().getAttribute("MovieDB");
		SegnalazioneDao dao=new SegnalazioneDao();
		HttpSession session=request.getSession(false);
		UtenteRegistrato user=(UtenteRegistrato) session.getAttribute("utente");
		String message="Impossibile inviare la segnalazione";
		int n;

		if(user!=null) {
			if((n=Validate.oggetto(request.getParameter("object")))==0) {
				if((n=Validate.titolo(request.getParameter("message")))==0) {
					Segnalazione report=new Segnalazione(Validate.replaceString(request.getParameter("object")),Validate.replaceString(request.getParameter("message")));
					dao.insertReport(report);
					message="Segnalazione inviata con successo.";
				}
				else if(n==1)
					message="Il messaggio della segnalazione non rispetta la lunghezza richiesta.";
				else
					message="Il messaggio della segnalazione non rispetta il formato richiesto.";
			}
			else if(n==1)
				message="L'oggetto della segnalazione non rispetta la lunghezza richiesta.";
			else
				message="L'oggetto della segnalazione non rispetta il formato richiesto.";
		}
		request.setAttribute("message", message);
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("message.jsp");
		requestDispatcher.forward(request, response);	
	}
}
