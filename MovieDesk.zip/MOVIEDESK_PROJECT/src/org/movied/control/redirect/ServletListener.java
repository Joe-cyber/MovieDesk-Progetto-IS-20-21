package org.movied.control.redirect;



import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.movied.control.db.MovieDB;


public class ServletListener implements ServletContextListener 
{
	/**
	 * initialize the connection attribute for the db.
	 * @param event the event that start the initialization of the db context
	 */
    public void contextInitialized(ServletContextEvent event) 
    {
    	 
    	ServletContext sc = event.getServletContext();
 
    	String url = sc.getInitParameter("url");
    	String username = sc.getInitParameter("username");
    	String password = sc.getInitParameter("password");
    	String database = sc.getInitParameter("database");
    	MovieDB db = new MovieDB(url+database,username,password);
    	sc.getSessionCookieConfig().setSecure(false);
    	sc.setAttribute("MovieDB", db);
    }
}
