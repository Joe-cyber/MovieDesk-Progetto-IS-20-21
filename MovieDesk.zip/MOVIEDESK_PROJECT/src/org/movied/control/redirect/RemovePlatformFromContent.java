package org.movied.control.redirect;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.movied.model.bean.Contenuto;
import org.movied.model.bean.Piattaforma;
import org.movied.model.dao.ContenutoDao;
import org.movied.model.dao.PiattaformaDao;

@WebServlet("/RemovePlatformFromContent")
public class RemovePlatformFromContent extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
    public RemovePlatformFromContent() {
        super();
    }
    /**
	 * @param request the server request
	 * @param response the server response
	 */
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
    /**
	 * @param request the server request
	 * @param response the server response
	 */
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		    getServletContext().getAttribute("MovieDB");
	        String message="Modifica non effettuata";
		    if(request.getParameter("nomeP")!=null && !request.getParameter("nomeP").equals("")) {
	        	if(request.getParameter("contentKey")!=null && !request.getParameter("contentKey").equals("")) {
			        ContenutoDao dao=new ContenutoDao();
			        PiattaformaDao daoP=new PiattaformaDao();
			        Contenuto c = dao.getContentDetails(Integer.parseInt(request.getParameter("contentKey")));
			        Piattaforma p= daoP.selectSinglePlatform(request.getParameter("nomeP"));
			        
			        if(dao.removePlatformFromContent(c, p)>0)
			            message="Rimozione di una piattaforma da un contenuto avvenuta con successo.";
	        	}
	            else
	            	message="Il titolo non � stato selezionato.";
	    	}
	        else
	        	message="Il nome non � stato selezionato.";
	       
	        request.setAttribute("message", message);

	        RequestDispatcher requestDispatcher = request.getRequestDispatcher("message.jsp");
	        requestDispatcher.forward(request, response);
	}

}
