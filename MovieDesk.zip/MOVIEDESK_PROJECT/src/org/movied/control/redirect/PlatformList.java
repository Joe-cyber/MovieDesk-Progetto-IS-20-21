package org.movied.control.redirect;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.movied.model.bean.Piattaforma;
import org.movied.model.dao.PiattaformaDao;

@WebServlet(name = "PlatformList", urlPatterns = { "/PlatformList" })
public class PlatformList extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
    public PlatformList() 
    {
        super();
    }
    
    /**
	 * @param request the server request
	 * @param response the server response
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		request.getServletContext().getAttribute("MovieDB");
		ArrayList<Piattaforma> piattaforme=new ArrayList<Piattaforma>();
		PiattaformaDao dao=new PiattaformaDao();
		
		
		piattaforme=dao.selectPlatform();	

		
		request.setAttribute("piattaforme",piattaforme);

		RequestDispatcher requestDispatcher = request.getRequestDispatcher("piattaforme.jsp");
		requestDispatcher.forward(request, response);
	}
	/**
	 * @param request the server request
	 * @param response the server response
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request, response);
	}

}