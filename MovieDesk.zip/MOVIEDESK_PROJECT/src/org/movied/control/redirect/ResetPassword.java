package org.movied.control.redirect;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.movied.control.service.JavaMailUtil;
import org.movied.control.service.JavaMailUtil.EmailType;
import org.movied.model.bean.UtenteRegistrato;
import org.movied.model.dao.UtenteRegistratoDao;

@WebServlet(name = "ResetPassword", urlPatterns = { "/ResetPassword" })
public class ResetPassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ResetPassword() {
        super();
    }
    /**
	 * @param request the server request
	 * @param response the server response
	 */
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		request.getServletContext().getAttribute("MovieDB");
		String message="� stato riscontrato un problema durante l'esecuzione dell'operazione";
		UtenteRegistratoDao dao=new UtenteRegistratoDao();
		String email=request.getParameter("email");
		if(dao.findEmail(email))
		{
			UtenteRegistrato user=dao.findUtente(request.getParameter("email"));
			user.setPassword(JavaMailUtil.generatorRandomPassword());
			int n=dao.updatePersonalData(user);
			if(n>0)
			{
				JavaMailUtil.sendMail(email, user.getPassword(), EmailType.NUOVA_PASSWORD);
				message="� stata inviata una nuova password. Controlla l'indirizzo di posta elettronica.";
			}
			request.setAttribute("message", message);
			RequestDispatcher rd=request.getRequestDispatcher("/message.jsp");
			rd.forward(request, response);
			return;
		}
		request.setAttribute("message", message);
		RequestDispatcher rd=request.getRequestDispatcher("/message.jsp");
		rd.forward(request, response);
	}
    /**
	 * @param request the server request
	 * @param response the server response
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doGet(request, response);
	}
}
