package org.movied.control.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import java.util.LinkedList;
import java.util.List;
import java.util.TimeZone;



public class MovieDB 
{
	public static String url;
	public static String username;
	public static String password;
	
	private static List<Connection> freeDbConnections;
	
	static 
	{		
		freeDbConnections=new LinkedList<Connection>();	
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		} 
	}
	
	public MovieDB(String url,String username,String password) 
	{
		MovieDB.url=url;
		MovieDB.username=username;
		MovieDB.password=password;
	}
	
	private static Connection createDBConnection() 
	{
		try
		{
			Connection conn=DriverManager.getConnection(url+"?serverTimezone="+TimeZone.getDefault().getID(),username,password);
			//Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/db_movied?serverTimezone="+TimeZone.getDefault().getID(),"StandardUser","Password1");
			conn.setAutoCommit(false);
			return conn;
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 
	 * @return a connection to selected db.
	 */
	public static synchronized Connection getConnection() 
	{
		Connection connection;

		if (!freeDbConnections.isEmpty())
		{
			connection = freeDbConnections.get(0);
			MovieDB.freeDbConnections.remove(0);
			try
			{
				if (connection.isClosed())
					connection = MovieDB.getConnection();
			} 
			catch (SQLException e)
			{
				try
				{
					if (connection != null) 
					{
						connection.close();
						connection=null;
					}
				}
				catch(SQLException ex) 
				{
					ex.printStackTrace();
				}
				connection = MovieDB.getConnection();
				e.printStackTrace();
			}
		} 
		else 
		{
			connection = createDBConnection();
		}
		return connection;
	}
	
	/**
	 * 
	 * @param connection release the passed connection.
	 */
	public static synchronized void releaseConnection(Connection connection)
	{
		try 
		{
			connection.commit();
			MovieDB.freeDbConnections.add(connection);
		} 
		catch (SQLException e) 
		{
			System.err.println(e.getMessage());
		}
	}
	/**
	 * 
	 * @return connection's url.
	 */
	public String getUrl() { 
		return url; 
	}

	/**
	 * 
	 * @return connection's username.
	 */
	public static String getUsername() {
		return username;
	}

	/**
	 * @param username
	 */
	public static void setUsername(String username) {
		MovieDB.username = username;
	}

	/**
	 * 
	 * @return connection's password
	 */
	public static String getPassword() {
		return password;
	}

	/**
	 * 
	 * @param password
	 */
	public static void setPassword(String password) {
		MovieDB.password = password;
	}

	/**
	 * 
	 * @param url
	 */
	public static void setUrl(String url) {
		MovieDB.url = url;
	}
	
	/**
	 * 
	 * @return connection's list freeDbConnection
	 */
	public static List<Connection> getFreeDbConnection() {
		return freeDbConnections;
	}
}
