package org.movied.control.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class QueryManager {

	private PreparedStatement pst=null;
	private ResultSet rs=null;
	
	/**
	 * 
	 * @param query the query you want to exec
	 * @param conn the connection at the db
	 * @return a Result set of the query
	 */
	public ResultSet execQuery(String query, Connection conn) 
	{
		try 
		{
			pst=conn.prepareStatement(query);
			rs=pst.executeQuery();
			return rs;
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 
	 * @param query the query you want to exec
	 * @param conn the connection at the db
	 * @return number of row manipulated
	 */
	public int execUpdate(String query, Connection conn)
	{
		try 
		{
			int n;
			pst=conn.prepareStatement(query);
			n=pst.executeUpdate();
			pst.close();
			return n;
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return 0;
		}
	}
}
