package org.movied.test;

import java.io.IOException;
import javax.servlet.ServletException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.movied.control.db.MovieDB;
import org.movied.control.redirect.RemovePlatform;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

class RemovePlatformTest {

	private RemovePlatform servlet;
	private MockHttpServletRequest request;
	private MockHttpServletResponse response;
	
	@BeforeEach
	void setUp() throws Exception {
		servlet = new RemovePlatform();
		request = new MockHttpServletRequest();
		response = new MockHttpServletResponse();
		new MovieDB("jdbc:mysql://localhost:3306/db_moviedb","StandardUser","Password1");
	}

	@Test
	public void testRemoveSuccess() throws ServletException, IOException{	
		request.addParameter("nome", "Netflix");
		servlet.doGet(request, response);
	}
	
	@Test
	public void testRemoveFailed() throws ServletException, IOException{	
		request.addParameter("nome", "Piattaforma");
		servlet.doPost(request, response);
	}
}
