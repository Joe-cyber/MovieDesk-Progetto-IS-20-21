package org.movied.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.movied.control.db.MovieDB;
import org.movied.model.bean.SerieTv;
import org.movied.model.bean.Piattaforma;
import org.movied.model.bean.Contenuto.Genere;
import org.movied.model.dao.SerieTVDao;
import org.movied.model.dao.PiattaformaDao;

class SerieTvDaoTest {

	private SerieTVDao dao;
	private SerieTv serie;
	
	@BeforeEach
	void setUp() throws Exception {
		dao=new SerieTVDao();
		new MovieDB("jdbc:mysql://localhost:3306/db_moviedb","StandardUser","Password1");
		ArrayList<Genere> generi=new ArrayList<>();
		generi.add(Genere.Anime);
		generi.add(Genere.Bambini);
		ArrayList<Piattaforma> piattaforme=new ArrayList<>();
		piattaforme.add(new PiattaformaDao().selectSinglePlatform("Netflix"));
		serie=new SerieTv(1,"titolo","2000","sinossi","cast","www.imgCopertina.it","www.trailer.com",generi,piattaforme,"5","10",40.0f,0,4.0f);
	}
	
	@Test
	void testInsertSerieSuccess() {
		assertEquals(1,dao.insertSerieTVContent(serie));
	}
	
	@Test
	void testInsertSerieFail() {
		serie.setValutazione(0.0f);
		assertEquals(0,dao.insertSerieTVContent(serie));
	}

}
