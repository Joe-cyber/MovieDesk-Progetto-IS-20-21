package org.movied.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.movied.model.bean.Piattaforma;

class PiattaformaTest {

	//INIZIO TEST GET
	 
	@Test
	void testGetImgPiattaforma() {
		Piattaforma p=new Piattaforma("imgPiattaforma.it/img","Nome","",0.0f);
		assertEquals("imgPiattaforma.it/img", p.getImgPiattaforma());
	}

	@Test
	void testGetNome() {
		Piattaforma p=new Piattaforma("","Nome","",0.0f);
		assertEquals("Nome", p.getNome());
	}
	
	@Test
	void testGetLink() {
		Piattaforma p=new Piattaforma("","Nome","www.link.it/embed/",0.0f);
		assertEquals("www.link.it/embed/", p.getLink());
	}
	
	@Test
	void testGetAbbonamentoMinimo() {
		Piattaforma p=new Piattaforma("","Nome","",10.0f);
		assertEquals(10.0f, p.getAbbonamentoMinimo());
	}
	
	//FINE TEST GET
	//INIZIO TEST SET
	
	@Test
	void testSetImgPiattaforma() {
		Piattaforma p=new Piattaforma("imgPiattaforma.it/img","Nome","",0.0f);
		p.setImgPiattaforma("otherImgPiattaforma.it/img");
		assertEquals("otherImgPiattaforma.it/img", p.getImgPiattaforma());
	}

	@Test
	void testSetNome() {
		Piattaforma p=new Piattaforma("","Nome","",0.0f);
		p.setNome("otherNome");
		assertEquals("otherNome", p.getNome());
	}

	@Test
	void testSetLink() {
		Piattaforma p=new Piattaforma("","Nome","www.link.it/embed/",0.0f);
		p.setLink("www.otherLink.it/embed/");
		assertEquals("www.otherLink.it/embed/", p.getLink());
	}

	

	@Test
	void testSetAbbonamentoMinimo() {
		Piattaforma p=new Piattaforma("","Nome","",0.0f);
		p.setAbbonamentoMinimo(10.0f);
		assertEquals(10.0f, p.getAbbonamentoMinimo());
	}

	//FINE TEST SET
	
	@Test
	void testEqualsSuccess1() {
		Piattaforma p1=new Piattaforma("imgPiattaforma.it","Nome","link.it",0.0f);
		Piattaforma p2=new Piattaforma("imgPiattaforma.it","Nome","link.it",0.0f);
		assertTrue(p1.equals(p2));
	}
	
	@Test
	void testEqualsFail1() {
		Piattaforma p1=new Piattaforma("imgPiattaforma.it","Nome","link.it",0.0f);
		assertFalse(p1.equals(null));
	}
	
	@SuppressWarnings("unlikely-arg-type")
	@Test
	void testEqualsFail2() {
		Piattaforma p1=new Piattaforma("imgPiattaforma.it","Nome","link.it",0.0f);
		assertFalse(p1.equals("piattaforma"));
	}
	
	@Test
	void testEqualsFail3() {
		Piattaforma p1=new Piattaforma("imgPiattaforma.it","Nome","link.it",null);
		Piattaforma p2=new Piattaforma("imgPiattaforma.it","Nome","link.it",null);
		assertTrue(p1.equals(p2));
	}
	
	@Test
	void testEqualsFail4() {
		Piattaforma p1=new Piattaforma("imgPiattaforma.it","Nome","link.it",null);
		Piattaforma p2=new Piattaforma("imgPiattaforma.it","Nome","link.it",0.0f);
		assertFalse(p1.equals(p2));
	}
	
	@Test
	void testEqualsFail5() {
		Piattaforma p1=new Piattaforma("imgPiattaforma.it","Nome","link.it",0.0f);
		Piattaforma p2=new Piattaforma("imgPiattaforma.it","Nome","link.it",1.0f);
		assertFalse(p1.equals(p2));
	}
	
	@Test
	void testEqualsFail6() {
		Piattaforma p1=new Piattaforma(null,"Nome","link.it",null);
		Piattaforma p2=new Piattaforma(null,"Nome","link.it",null);
		assertTrue(p1.equals(p2));
	}
	
	@Test
	void testEqualsFail7() {
		Piattaforma p1=new Piattaforma(null,"Nome","link.it",null);
		Piattaforma p2=new Piattaforma("imgPiattaforma.it","Nome","link.it",null);
		assertFalse(p1.equals(p2));
	}
	
	@Test
	void testEqualsFail8() {
		Piattaforma p1=new Piattaforma("imgPiattaforma.it","Nome","link.it",null);
		Piattaforma p2=new Piattaforma("imgPiattaforma2.it","Nome","link.it",null);
		assertFalse(p1.equals(p2));
	}
	
	@Test
	void testEqualsFail9() {
		Piattaforma p1=new Piattaforma(null,"Nome",null,null);
		Piattaforma p2=new Piattaforma(null,"Nome",null,null);
		assertTrue(p1.equals(p2));
	}
	
	@Test
	void testEqualsFail10() {
		Piattaforma p1=new Piattaforma(null,"Nome",null,null);
		Piattaforma p2=new Piattaforma(null,"Nome","link.it",null);
		assertFalse(p1.equals(p2));
	}
	
	@Test
	void testEqualsFail11() {
		Piattaforma p1=new Piattaforma(null,"Nome","link.it",null);
		Piattaforma p2=new Piattaforma(null,"Nome","link2.it",null);
		assertFalse(p1.equals(p2));
	}
	
	@Test
	void testEqualsFail12() {
		Piattaforma p1=new Piattaforma(null,null,null,null);
		Piattaforma p2=new Piattaforma(null,null,null,null);
		assertTrue(p1.equals(p2));
	}
	
	@Test
	void testEqualsFail13() {
		Piattaforma p1=new Piattaforma(null,null,null,null);
		Piattaforma p2=new Piattaforma(null,"Nome",null,null);
		assertFalse(p1.equals(p2));
	}
	
	@Test
	void testEqualsFail14() {
		Piattaforma p1=new Piattaforma(null,"Nome",null,null);
		Piattaforma p2=new Piattaforma(null,"Nome2",null,null);
		assertFalse(p1.equals(p2));
	}
}
