package org.movied.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.movied.model.bean.Segnalazione;
import org.movied.model.bean.Segnalazione.Stato;

class SegnalazioneTest {

	//INIZIO TEST GET
	
	@Test
	void testGetIdSegnalazione() {
		Segnalazione s=new Segnalazione("1","","","",Stato.Ricevuta);
		assertEquals("1",s.getIdSegnalazione());
	}

	@Test
	void testGetOggetto() {
		Segnalazione s=new Segnalazione("1","oggetto","","",Stato.Ricevuta);
		assertEquals("oggetto",s.getOggetto());
	}

	@Test
	void testGetStato() {
		Segnalazione s=new Segnalazione("1","","","",Stato.Ricevuta);
		assertEquals(Stato.Ricevuta,s.getStato());
	}

	@Test
	void testGetMessage() {
		Segnalazione s=new Segnalazione("1","","messaggio","",Stato.Ricevuta);
		assertEquals("messaggio",s.getMessage());
	}

	@Test
	void testGetUtenteMail() {
		Segnalazione s=new Segnalazione("1","","","mmanager@mail.com",Stato.Ricevuta);
		assertEquals("mmanager@mail.com",s.getUtenteMail());
	}
	
	//FINE TEST GET
	//INIZIO TEST SET
	
	@Test
	void testSetIdSegnalazione() {
		Segnalazione s=new Segnalazione("1","","","",Stato.Ricevuta);
		s.setIdSegnalazione("2");
		assertEquals("2",s.getIdSegnalazione());
	}

	@Test
	void testSetOggetto() {
		Segnalazione s=new Segnalazione("1","oggetto","","",Stato.Ricevuta);
		s.setOggetto("otherOggetto");
		assertEquals("otherOggetto",s.getOggetto());
	}

	@Test
	void testSetStato() {
		Segnalazione s=new Segnalazione("1","","","",Stato.Ricevuta);
		s.setStato(Stato.PresaIncarico);
		assertEquals(Stato.PresaIncarico,s.getStato());
	}

	@Test
	void testSetMessage() {
		Segnalazione s=new Segnalazione("1","","messaggio","",Stato.Ricevuta);
		s.setMessage("otherMessaggio");
		assertEquals("otherMessaggio",s.getMessage());
	}

	@Test
	void testSetUtenteMail() {
		Segnalazione s=new Segnalazione("1","","","mmanager@mail.com",Stato.Ricevuta);
		s.setUtenteMail("ustandard@mail.com");
		assertEquals("ustandard@mail.com",s.getUtenteMail());
	}
	//FINE TEST SET
	
	@Test
	void testEqualsSuccess1() {
		Segnalazione s1=new Segnalazione("1","oggett","messaggio","mmanager@mail.com",Stato.Ricevuta);
		Segnalazione s2=new Segnalazione("1","oggett","messaggio","mmanager@mail.com",Stato.Ricevuta);
		assertTrue(s1.equals(s2));
	}
	
	@Test
	void testEqualsFail1() {
		Segnalazione s1=new Segnalazione("1","oggett","messaggio","mmanager@mail.com",Stato.Ricevuta);
		assertFalse(s1.equals(null));
	}
	
	@SuppressWarnings("unlikely-arg-type")
	@Test
	void testEqualsFail2() {
		Segnalazione s1=new Segnalazione("1","oggett","messaggio","mmanager@mail.com",Stato.Ricevuta);
		assertFalse(s1.equals("segnalazione"));
	}
	
	@Test
	void testEqualsFail3() {
		Segnalazione s1=new Segnalazione(null,"oggett","messaggio","mmanager@mail.com",Stato.Ricevuta);
		Segnalazione s2=new Segnalazione(null,"oggett","messaggio","mmanager@mail.com",Stato.Ricevuta);
		assertTrue(s1.equals(s2));
	}
	
	@Test
	void testEqualsFail4() {
		Segnalazione s1=new Segnalazione(null,"oggett","messaggio","mmanager@mail.com",Stato.Ricevuta);
		Segnalazione s2=new Segnalazione("","oggett","messaggio","mmanager@mail.com",Stato.Ricevuta);
		assertFalse(s1.equals(s2));
	}
	
	@Test
	void testEqualsFail5() {
		Segnalazione s1=new Segnalazione("1","oggett","messaggio","mmanager@mail.com",Stato.Ricevuta);
		Segnalazione s2=new Segnalazione("2","oggett","messaggio","mmanager@mail.com",Stato.Ricevuta);
		assertFalse(s1.equals(s2));
	}
	
	@Test
	void testEqualsFail6() {
		Segnalazione s1=new Segnalazione(null,null,"messaggio","mmanager@mail.com",Stato.Ricevuta);
		Segnalazione s2=new Segnalazione(null,null,"messaggio","mmanager@mail.com",Stato.Ricevuta);
		assertTrue(s1.equals(s2));
	}
	
	@Test
	void testEqualsFail7() {
		Segnalazione s1=new Segnalazione(null,null,"messaggio","mmanager@mail.com",Stato.Ricevuta);
		Segnalazione s2=new Segnalazione(null,"oggett","messaggio","mmanager@mail.com",Stato.Ricevuta);
		assertFalse(s1.equals(s2));
	}
	
	@Test
	void testEqualsFail8() {
		Segnalazione s1=new Segnalazione(null,"oggett","messaggio","mmanager@mail.com",Stato.Ricevuta);
		Segnalazione s2=new Segnalazione(null,"oggetto","messaggio","mmanager@mail.com",Stato.Ricevuta);
		assertFalse(s1.equals(s2));
	}
	
	@Test
	void testEqualsFail9() {
		Segnalazione s1=new Segnalazione(null,null,null,"mmanager@mail.com",Stato.Ricevuta);
		Segnalazione s2=new Segnalazione(null,null,null,"mmanager@mail.com",Stato.Ricevuta);
		assertTrue(s1.equals(s2));
	}
	
	@Test
	void testEqualsFail10() {
		Segnalazione s1=new Segnalazione(null,null,null,"mmanager@mail.com",Stato.Ricevuta);
		Segnalazione s2=new Segnalazione(null,null,"messaggio","mmanager@mail.com",Stato.Ricevuta);
		assertFalse(s1.equals(s2));
	}
	
	@Test
	void testEqualsFail11() {
		Segnalazione s1=new Segnalazione(null,null,"messaggio","mmanager@mail.com",Stato.Ricevuta);
		Segnalazione s2=new Segnalazione(null,null,"messaggi0","mmanager@mail.com",Stato.Ricevuta);
		assertFalse(s1.equals(s2));
	}
	
	@Test
	void testEqualsFail12() {
		Segnalazione s1=new Segnalazione(null,null,"messaggio","mmanager@mail.com",Stato.Ricevuta);
		Segnalazione s2=new Segnalazione(null,null,"messaggio","mmanager@mail.com",Stato.PresaIncarico);
		assertFalse(s1.equals(s2));
	}
	
	@Test
	void testEqualsFail13() {
		Segnalazione s1=new Segnalazione(null,null,null,null,Stato.Ricevuta);
		Segnalazione s2=new Segnalazione(null,null,null,null,Stato.Ricevuta);
		assertTrue(s1.equals(s2));
	}
	
	@Test
	void testEqualsFail14() {
		Segnalazione s1=new Segnalazione(null,null,null,null,Stato.Ricevuta);
		Segnalazione s2=new Segnalazione(null,null,null,"mmanager@mail.com",Stato.Ricevuta);
		assertFalse(s1.equals(s2));
	}
	
	@Test
	void testEqualsFail15() {
		Segnalazione s1=new Segnalazione(null,null,null,"mmanager@mail.com",Stato.Ricevuta);
		Segnalazione s2=new Segnalazione(null,null,null,"mmanager2@mail.com",Stato.Ricevuta);
		assertFalse(s1.equals(s2));
	}
}
