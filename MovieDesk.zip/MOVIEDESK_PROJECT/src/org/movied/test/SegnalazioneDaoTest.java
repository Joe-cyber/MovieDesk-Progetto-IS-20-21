package org.movied.test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.movied.control.db.MovieDB;
import org.movied.model.dao.SegnalazioneDao;

class SegnalazioneDaoTest {

	private SegnalazioneDao dao;
	
	@BeforeEach
	void setUp() throws Exception {
		dao=new SegnalazioneDao();
		new MovieDB("jdbc:mysql://localhost:3306/db_moviedb","StandardUser","Password1");
	}
	
	@Test
	void testSelectAllReport() {
		assertNotNull(dao.selectReport());
	}
	
	@Test
	void testSelectTaked() {
		assertNotNull(dao.selectReport("mmanager@mail.com"));
	}
	
	@Test
	void testSelectSingleReportSuccess() {
		assertNotNull(dao.selectSingleReport(1));
	}
	
	@Test
	void testSelectSingleReportFail() {
		assertNull(dao.selectSingleReport(0));
	}
}
