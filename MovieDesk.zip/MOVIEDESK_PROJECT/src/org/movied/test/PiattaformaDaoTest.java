package org.movied.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.movied.control.db.MovieDB;
import org.movied.model.dao.PiattaformaDao;

class PiattaformaDaoTest {

	private PiattaformaDao dao;
	
	@BeforeEach
	void setUp() throws Exception {
		dao=new PiattaformaDao();
		new MovieDB("jdbc:mysql://localhost:3306/db_moviedb","StandardUser","Password1");
	}

	@Test
	void testSelectAll() {
		assertNotNull(dao.selectPlatform());
	}
	
	@Test
	void testSelectWithName() {
		assertNotNull(dao.selectPlatform("Infinity"));
	}
	
	@Test
	void testSelectSinglePlatformSuccess() {
		assertNotNull(dao.selectSinglePlatform("Infinity"));
	}
	
	@Test
	void testSelectSinglePlatformFail() {
		assertNull(dao.selectSinglePlatform("name"));
	}
}
