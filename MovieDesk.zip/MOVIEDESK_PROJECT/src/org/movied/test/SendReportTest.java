package org.movied.test;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

import javax.servlet.ServletException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.movied.control.db.MovieDB;
import org.movied.control.redirect.SendReport;
import org.movied.model.dao.UtenteRegistratoDao;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockHttpSession;

class SendReportTest {
	
	private SendReport servlet;
	private MockHttpServletRequest request;
	private MockHttpServletResponse response;
	private MockHttpSession session;
	@BeforeEach
	void setUp() throws Exception {
		servlet = new SendReport();
		request = new MockHttpServletRequest();
		response = new MockHttpServletResponse();
		new MovieDB("jdbc:mysql://localhost:3306/db_moviedb","StandardUser","Password1");
		session = new MockHttpSession();
		request.setSession(session);
	}
	
	@Test
	public void testSendReportFail() throws ServletException, IOException{	
		request.setParameter("object", "Object");
		request.setParameter("message", "Message");
		servlet.doGet(request, response);
		assertEquals("Impossibile inviare la segnalazione",request.getAttribute("message"));
	}
	
	@Test
	public void testSendReportSuccess() throws ServletException, IOException{	
		request.setParameter("object", "Object");
		request.setParameter("message", "Message");
		session.setAttribute("utente", new UtenteRegistratoDao().findUtente("ustandard@mail.com", "UtenteStandard01"));
		request.setSession(session);
		servlet.doGet(request, response);
		assertEquals("Segnalazione inviata con successo.",request.getAttribute("message"));
	}
}
