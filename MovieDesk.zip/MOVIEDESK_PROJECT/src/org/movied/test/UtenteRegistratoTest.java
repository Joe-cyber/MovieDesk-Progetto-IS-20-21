package org.movied.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;
import org.movied.model.bean.Contenuto;
import org.movied.model.bean.Film;
import org.movied.model.bean.Piattaforma;
import org.movied.model.bean.SerieTv;
import org.movied.model.bean.UtenteRegistrato;
import org.movied.model.bean.Contenuto.Genere;

class UtenteRegistratoTest {

	//INIZIO TEST GET
	
	@Test
	void testGetNome() {
		UtenteRegistrato u=new UtenteRegistrato("mmanager@mail.com","nome","","",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		assertEquals("nome",u.getNome());
	}
	
	@Test
	void testGetCognome() {
		UtenteRegistrato u=new UtenteRegistrato("mmanager@mail.com","","cognome","",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		assertEquals("cognome",u.getCognome());
	}

	@Test
	void testGetEmail() {
		UtenteRegistrato u=new UtenteRegistrato("mmanager@mail.com","","","",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		assertEquals("mmanager@mail.com",u.getEmail());
	}

	@Test
	void testGetPassword() {
		UtenteRegistrato u=new UtenteRegistrato("mmanager@mail.com","","","password",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		assertEquals("password",u.getPassword());
	}

	@Test
	void testGetPreferiti() {
		UtenteRegistrato u=new UtenteRegistrato("mmanager@mail.com","","","",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		ArrayList<Contenuto> a=new ArrayList<>();
		assertEquals(a,u.getPreferiti());
	}

	@Test
	void testGetPiaciuti() {
		UtenteRegistrato u=new UtenteRegistrato("mmanager@mail.com","","","",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		ArrayList<Contenuto> a=new ArrayList<>();
		assertEquals(a,u.getPiaciuti());
	}

	@Test
	void testGetVisti() {
		UtenteRegistrato u=new UtenteRegistrato("mmanager@mail.com","","","",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		ArrayList<Contenuto> a=new ArrayList<>();
		assertEquals(a,u.getVisti());
	}

	@Test
	void testGetTipo() {
		UtenteRegistrato u=new UtenteRegistrato("mmanager@mail.com","","","",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"MM");
		assertEquals("MM",u.getTipo());
	}

	//FINE TEST GET
	//INIZIO TEST SET
	
	@Test
	void testSetNome() {
		UtenteRegistrato u=new UtenteRegistrato("mmanager@mail.com","nome","","",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		u.setNome("otherNome");
		assertEquals("otherNome",u.getNome());
	}
	
	@Test
	void testSetCognome() {
		UtenteRegistrato u=new UtenteRegistrato("mmanager@mail.com","","cognome","",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		u.setCognome("otherCognome");
		assertEquals("otherCognome",u.getCognome());
	}

	@Test
	void testSetEmail() {
		UtenteRegistrato u=new UtenteRegistrato("mmanager@mail.com","","","",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		u.setEmail("ustandard@mail.com");
		assertEquals("ustandard@mail.com",u.getEmail());
	}

	@Test
	void testSetPassword() {
		UtenteRegistrato u=new UtenteRegistrato("mmanager@mail.com","","","password",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		u.setPassword("otherPassword");
		assertEquals("otherPassword",u.getPassword());
	}

	@Test
	void testSetPreferiti() {
		UtenteRegistrato u=new UtenteRegistrato("mmanager@mail.com","","","",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		ArrayList<Contenuto> a=new ArrayList<>();
		a.add(new Film(1,"","","","","","",new ArrayList<Genere>(), new ArrayList<Piattaforma>(), 0.0f,"",0,0.0f));
		u.setPreferiti(a);
		assertEquals(a,u.getPreferiti());
	}

	@Test
	void testSetPiaciuti() {
		UtenteRegistrato u=new UtenteRegistrato("mmanager@mail.com","","","",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		ArrayList<Contenuto> a=new ArrayList<>();
		a.add(new Film(1,"","","","","","",new ArrayList<Genere>(), new ArrayList<Piattaforma>(), 0.0f,"",0,0.0f));
		u.setPiaciuti(a);
		assertEquals(a,u.getPiaciuti());
	}

	@Test
	void testSetVisti() {
		UtenteRegistrato u=new UtenteRegistrato("mmanager@mail.com","","","",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		ArrayList<Contenuto> a=new ArrayList<>();
		a.add(new Film(1,"","","","","","",new ArrayList<Genere>(), new ArrayList<Piattaforma>(), 0.0f,"",0,0.0f));
		u.setVisti(a);
		assertEquals(a,u.getVisti());
	}

	@Test
	void testSetTipo() {
		UtenteRegistrato u=new UtenteRegistrato("mmanager@mail.com","","","",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"MM");
		u.setTipo("US");
		assertEquals("US",u.getTipo());
	}
	
	//FINE TEST SET
	
	@Test
	void testEqualsSuccess1() {
		UtenteRegistrato u1=new UtenteRegistrato("mmanager@mail.com","","","",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		UtenteRegistrato u2=new UtenteRegistrato("mmanager@mail.com","","","",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		assertTrue(u1.equals(u2));
	}
	
	@Test
	void testEqualsFail1() {
		UtenteRegistrato u1=new UtenteRegistrato("mmanager@mail.com","","","",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		assertFalse(u1.equals(null));
	}
	
	@SuppressWarnings("unlikely-arg-type")
	@Test
	void testEqualsFail2() {
		UtenteRegistrato u1=new UtenteRegistrato("mmanager@mail.com","","","",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		assertFalse(u1.equals("utente"));
	}
	
	@Test
	void testEqualsFail3() {
		UtenteRegistrato u1=new UtenteRegistrato("mmanager@mail.com","",null,"",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		UtenteRegistrato u2=new UtenteRegistrato("mmanager@mail.com","",null,"",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		assertTrue(u1.equals(u2));
	}
	
	@Test
	void testEqualsFail4() {
		UtenteRegistrato u1=new UtenteRegistrato("mmanager@mail.com","",null,"",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		UtenteRegistrato u2=new UtenteRegistrato("mmanager@mail.com","","","",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		assertFalse(u1.equals(u2));
	}
	
	@Test
	void testEqualsFail5() {
		UtenteRegistrato u1=new UtenteRegistrato("mmanager@mail.com","","","",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		UtenteRegistrato u2=new UtenteRegistrato("mmanager@mail.com","","cognome","",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		assertFalse(u1.equals(u2));
	}
	
	@Test
	void testEqualsFail6() {
		UtenteRegistrato u1=new UtenteRegistrato("mmanager@mail.com",null,null,"",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		UtenteRegistrato u2=new UtenteRegistrato("mmanager@mail.com",null,null,"",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		assertTrue(u1.equals(u2));
	}
	
	@Test
	void testEqualsFail7() {
		UtenteRegistrato u1=new UtenteRegistrato("mmanager@mail.com",null,null,"",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		UtenteRegistrato u2=new UtenteRegistrato("mmanager@mail.com","",null,"",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		assertFalse(u1.equals(u2));
	}
	
	@Test
	void testEqualsFail8() {
		UtenteRegistrato u1=new UtenteRegistrato("mmanager@mail.com","",null,"",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		UtenteRegistrato u2=new UtenteRegistrato("mmanager@mail.com","nome",null,"",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		assertFalse(u1.equals(u2));
	}
	
	@Test
	void testEqualsFail9() {
		UtenteRegistrato u1=new UtenteRegistrato(null,null,null,"",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		UtenteRegistrato u2=new UtenteRegistrato(null,null,null,"",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		assertTrue(u1.equals(u2));
	}
	
	@Test
	void testEqualsFail10() {
		UtenteRegistrato u1=new UtenteRegistrato(null,null,null,"",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		UtenteRegistrato u2=new UtenteRegistrato("mmanager@mail.com",null,null,"",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		assertFalse(u1.equals(u2));
	}
	
	@Test
	void testEqualsFail11() {
		UtenteRegistrato u1=new UtenteRegistrato("mmanager@mail.com",null,null,"",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		UtenteRegistrato u2=new UtenteRegistrato("mmanager@mail2.com",null,null,"",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		assertFalse(u1.equals(u2));
	}
	
	@Test
	void testEqualsFail12() {
		UtenteRegistrato u1=new UtenteRegistrato(null,null,null,null,new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		UtenteRegistrato u2=new UtenteRegistrato(null,null,null,null,new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		assertTrue(u1.equals(u2));
	}
	
	@Test
	void testEqualsFail13() {
		UtenteRegistrato u1=new UtenteRegistrato(null,null,null,null,new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		UtenteRegistrato u2=new UtenteRegistrato(null,null,null,"",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		assertFalse(u1.equals(u2));
	}
	
	@Test
	void testEqualsFail14() {
		UtenteRegistrato u1=new UtenteRegistrato(null,null,null,"",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		UtenteRegistrato u2=new UtenteRegistrato(null,null,null,"2",new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		assertFalse(u1.equals(u2));
	}
	
	@Test
	void testEqualsFail15() {
		UtenteRegistrato u1=new UtenteRegistrato(null,null,null,null,new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),null);
		UtenteRegistrato u2=new UtenteRegistrato(null,null,null,null,new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),null);
		assertTrue(u1.equals(u2));
	}
	
	@Test
	void testEqualsFail16() {
		UtenteRegistrato u1=new UtenteRegistrato(null,null,null,null,new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),null);
		UtenteRegistrato u2=new UtenteRegistrato(null,null,null,null,new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		assertFalse(u1.equals(u2));
	}
	
	@Test
	void testEqualsFail17() {
		UtenteRegistrato u1=new UtenteRegistrato(null,null,null,null,new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"");
		UtenteRegistrato u2=new UtenteRegistrato(null,null,null,null,new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),"5");
		assertFalse(u1.equals(u2));
	}
	
	@Test
	void testEqualsFail18() {
		ArrayList<Contenuto> c=new ArrayList<>();
		c.add(new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"","10",0.0f,0,0.0f));
		UtenteRegistrato u1=new UtenteRegistrato(null,null,null,null,null,new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),null);
		UtenteRegistrato u2=new UtenteRegistrato(null,null,null,null,null,new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),null);
		assertTrue(u1.equals(u2));
	}
	
	@Test
	void testEqualsFail19() {
		ArrayList<Contenuto> c=new ArrayList<>();
		c.add(new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"","10",0.0f,0,0.0f));
		UtenteRegistrato u1=new UtenteRegistrato(null,null,null,null,null,new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),null);
		UtenteRegistrato u2=new UtenteRegistrato(null,null,null,null,new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),null);
		assertFalse(u1.equals(u2));
	}
	
	@Test
	void testEqualsFail20() {
		ArrayList<Contenuto> c=new ArrayList<>();
		c.add(new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"","10",0.0f,0,0.0f));
		UtenteRegistrato u1=new UtenteRegistrato(null,null,null,null,new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),null);
		UtenteRegistrato u2=new UtenteRegistrato(null,null,null,null,c,new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),null);
		assertFalse(u1.equals(u2));
	}

	@Test
	void testEqualsFail21() {
		ArrayList<Contenuto> c=new ArrayList<>();
		c.add(new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"","10",0.0f,0,0.0f));
		UtenteRegistrato u1=new UtenteRegistrato(null,null,null,null,null,null,new ArrayList<Contenuto>(),null);
		UtenteRegistrato u2=new UtenteRegistrato(null,null,null,null,null,null,new ArrayList<Contenuto>(),null);
		assertTrue(u1.equals(u2));
	}
	
	@Test
	void testEqualsFail22() {
		ArrayList<Contenuto> c=new ArrayList<>();
		c.add(new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"","10",0.0f,0,0.0f));
		UtenteRegistrato u1=new UtenteRegistrato(null,null,null,null,null,null,new ArrayList<Contenuto>(),null);
		UtenteRegistrato u2=new UtenteRegistrato(null,null,null,null,null,new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),null);
		assertFalse(u1.equals(u2));
	}
	
	@Test
	void testEqualsFail23() {
		ArrayList<Contenuto> c=new ArrayList<>();
		c.add(new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"","10",0.0f,0,0.0f));
		UtenteRegistrato u1=new UtenteRegistrato(null,null,null,null,null,new ArrayList<Contenuto>(),new ArrayList<Contenuto>(),null);
		UtenteRegistrato u2=new UtenteRegistrato(null,null,null,null,null,c,new ArrayList<Contenuto>(),null);
		assertFalse(u1.equals(u2));
	}
	
	@Test
	void testEqualsFail24() {
		ArrayList<Contenuto> c=new ArrayList<>();
		c.add(new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"","10",0.0f,0,0.0f));
		UtenteRegistrato u1=new UtenteRegistrato(null,null,null,null,null,null,null,null);
		UtenteRegistrato u2=new UtenteRegistrato(null,null,null,null,null,null,null,null);
		assertTrue(u1.equals(u2));
	}
	
	@Test
	void testEqualsFail25() {
		ArrayList<Contenuto> c=new ArrayList<>();
		c.add(new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"","10",0.0f,0,0.0f));
		UtenteRegistrato u1=new UtenteRegistrato(null,null,null,null,null,null,null,null);
		UtenteRegistrato u2=new UtenteRegistrato(null,null,null,null,null,null,new ArrayList<Contenuto>(),null);
		assertFalse(u1.equals(u2));
	}
	
	@Test
	void testEqualsFail26() {
		ArrayList<Contenuto> c=new ArrayList<>();
		c.add(new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"","10",0.0f,0,0.0f));
		UtenteRegistrato u1=new UtenteRegistrato(null,null,null,null,null,null,new ArrayList<Contenuto>(),null);
		UtenteRegistrato u2=new UtenteRegistrato(null,null,null,null,null,null,c,null);
		assertFalse(u1.equals(u2));
	}
}
