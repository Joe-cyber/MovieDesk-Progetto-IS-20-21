package org.movied.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;
import org.movied.model.bean.Film;
import org.movied.model.bean.Piattaforma;
import org.movied.model.bean.SerieTv;
import org.movied.model.bean.Contenuto.Genere;

class FilmTest {

	//INIZIO TEST GET
	@Test
	void testGetDurata() {
		Film f=new Film(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),50.0f,"",0,0.0f);
		assertEquals(50.0f,f.getDurata());
	}

	@Test
	void testGetRegista() {
		Film f=new Film(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),0.0f,"regista",0,0.0f);
		assertEquals("regista",f.getRegista());
	}

	@Test
	void testGetIdContenuto() {
		Film f=new Film(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),0.0f,"",0,0.0f);
		assertEquals(1,f.getIdContenuto());
	}

	@Test
	void testGetTitolo() {
		Film f=new Film(1,"titolo","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),0.0f,"",0,0.0f);
		assertEquals("titolo",f.getTitolo());
	}

	@Test
	void testGetValutazione() {
		Film f=new Film(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),0.0f,"",0,5.0f);
		assertEquals(5.0f,f.getValutazione());
	}

	@Test
	void testGetAnno() {
		Film f=new Film(1,"","2000","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),0.0f,"",0,0.0f);
		assertEquals("2000",f.getAnno());
	}

	@Test
	void testGetSinossi() {
		Film f=new Film(1,"","","sinossi","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),0.0f,"",0,0.0f);
		assertEquals("sinossi",f.getSinossi());
	}

	@Test
	void testGetMiPiace() {
		Film f=new Film(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),0.0f,"",50,0.0f);
		assertEquals(50,f.getMiPiace());
	}

	@Test
	void testGetCast() {
		Film f=new Film(1,"","","","cast","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),0.0f,"",0,0.0f);
		assertEquals("cast",f.getCast());
	}

	@Test
	void testGetImgCopertina() {
		Film f=new Film(1,"","","","","imgCopertina.it/img","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		assertEquals("imgCopertina.it/img",f.getImgCopertina());
	}

	@Test
	void testGetTrailer() {
		Film f=new Film(1,"","","","","","www.link.it/embed/",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		assertEquals("www.link.it/embed/",f.getTrailer());
	}

	@Test
	void testGetGeneri() {
		Film f=new Film(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		assertEquals(new ArrayList<Genere>(),f.getGeneri());
	}

	@Test
	void testGetPiattaforme() {
		Film f=new Film(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		assertEquals(new ArrayList<Piattaforma>(),f.getPiattaforme());
	}
	//FINE TEST GET
	//INIZIO TEST SET
	@Test
	void testSetDurata() {
		Film f=new Film(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),50.0f,"",0,0.0f);
		f.setDurata(100.0f);
		assertEquals(100.0f,f.getDurata());
	}

	@Test
	void testSetRegista() {
		Film f=new Film(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),0.0f,"regista",0,0.0f);
		f.setRegista("otherRegista");
		assertEquals("otherRegista",f.getRegista());
	}

	@Test
	void testSetIdContenuto() {
		Film f=new Film(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),0.0f,"",0,0.0f);
		f.setIdContenuto(2);
		assertEquals(2,f.getIdContenuto());
	}

	@Test
	void testSetTitolo() {
		Film f=new Film(1,"titolo","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),0.0f,"",0,0.0f);
		f.setTitolo("otherTitolo");
		assertEquals("otherTitolo",f.getTitolo());
	}

	@Test
	void testSetValutazione() {
		Film f=new Film(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),0.0f,"",0,5.0f);
		f.setValutazione(1.0f);
		assertEquals(1.0f,f.getValutazione());
	}

	@Test
	void testSetAnno() {
		Film f=new Film(1,"","2000","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),0.0f,"",0,0.0f);
		f.setAnno("1980");
		assertEquals("1980",f.getAnno());
	}

	@Test
	void testSetSinossi() {
		Film f=new Film(1,"","","sinossi","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),0.0f,"",0,0.0f);
		f.setSinossi("otherSinossi");
		assertEquals("otherSinossi",f.getSinossi());
	}

	@Test
	void testSetMiPiace() {
		Film f=new Film(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),0.0f,"",50,0.0f);
		f.setMiPiace(10);
		assertEquals(10,f.getMiPiace());
	}

	@Test
	void testSetCast() {
		Film f=new Film(1,"","","","cast","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),0.0f,"",0,0.0f);
		f.setCast("otherCast");
		assertEquals("otherCast",f.getCast());
	}

	@Test
	void testSetImgCopertina() {
		Film f=new Film(1,"","","","","imgCopertina.it/img","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		f.setImgCopertina("otherimgCopertina.it/img");
		assertEquals("otherimgCopertina.it/img",f.getImgCopertina());
	}

	@Test
	void testSetTrailer() {
		Film f=new Film(1,"","","","","","www.link.it/embed/",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		f.setTrailer("www.otherlink.it/embed/");
		assertEquals("www.otherlink.it/embed/",f.getTrailer());
	}

	@Test
	void testSetGeneri() {
		Film f=new Film(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		ArrayList<Genere> g=new ArrayList<>();
		g.add(Genere.Anime);
		f.setGeneri(g);
		assertEquals(g,f.getGeneri());
	}

	@Test
	void testSetPiattaforme() {
		Film f=new Film(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		ArrayList<Piattaforma> p=new ArrayList<>();
		p.add(new Piattaforma("","","",0.0f));
		f.setPiattaforme(p);
		assertEquals(p,f.getPiattaforme());
	}
	
	@Test
	void testEqualsSuccess1() {
		Film f1=new Film(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		Film f2=new Film(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		assertTrue(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail1() {
		Film f1=new Film(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		assertFalse(f1.equals(null));
	}
	
	@SuppressWarnings("unlikely-arg-type")
	@Test
	void testEqualsFail2() {
		Film f1=new Film(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		SerieTv s=new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"5","",0.0f,0,0.0f);
		assertFalse(f1.equals(s));
	}
	
	@Test
	void testEqualsFail3() {
		Film f1=new Film(1,"",null,"","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		Film f2=new Film(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		assertFalse(f1.equals(f2));
	}
	
	@Test
	void testEqualsSuccess2() {
		Film f1=new Film(1,"",null,"","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		Film f2=new Film(1,"",null,"","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		assertTrue(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail4() {
		Film f1=new Film(1,"","2000","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		Film f2=new Film(1,"","2001","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		assertFalse(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail5() {
		Film f1=new Film(1,"","2000","",null,"","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		Film f2=new Film(1,"","2000","",null,"","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		assertTrue(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail6() {
		Film f1=new Film(1,"","2000","",null,"","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		Film f2=new Film(1,"","2000","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		assertFalse(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail7() {
		Film f1=new Film(1,"","2000","","cast1","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		Film f2=new Film(1,"","2000","","cast2","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		assertFalse(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail8() {
		Film f1=new Film(1,"","2000","",null,"","",null,new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		Film f2=new Film(1,"","2000","",null,"","",null,new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		assertTrue(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail9() {
		Film f1=new Film(1,"","2000","",null,"","",null,new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		Film f2=new Film(1,"","2000","",null,"","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		assertFalse(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail10() {
		ArrayList<Genere> g=new ArrayList<Genere>();
		g.add(Genere.Anime);
		Film f1=new Film(1,"","2000","",null,"","",g,new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		Film f2=new Film(1,"","2000","",null,"","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		assertFalse(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail11() {
		Film f1=new Film(null,"","2000","",null,"","",null,new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		Film f2=new Film(null,"","2000","",null,"","",null,new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		assertTrue(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail12() {
		Film f1=new Film(null,"","2000","",null,"","",null,new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		Film f2=new Film(1,"","2000","",null,"","",null,new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		assertFalse(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail13() {
		Film f1=new Film(1,"","2000","",null,"","",null,new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		Film f2=new Film(2,"","2000","",null,"","",null,new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		assertFalse(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail14() {
		Film f1=new Film(1,"","2000","",null,null,"",null,new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		Film f2=new Film(1,"","2000","",null,null,"",null,new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		assertTrue(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail15() {
		Film f1=new Film(1,"","2000","",null,null,"",null,new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		Film f2=new Film(1,"","2000","",null,"","",null,new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		assertFalse(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail16() {
		Film f1=new Film(1,"","2000","",null,"","",null,new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		Film f2=new Film(1,"","2000","",null,"link","",null,new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		assertFalse(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail17() {
		Film f1=new Film(1,"","2000","",null,null,"",null,new ArrayList<Piattaforma>(),00.0f,"",null,0.0f);
		Film f2=new Film(1,"","2000","",null,null,"",null,new ArrayList<Piattaforma>(),00.0f,"",null,0.0f);
		assertTrue(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail18() {
		Film f1=new Film(1,"","2000","",null,null,"",null,new ArrayList<Piattaforma>(),00.0f,"",null,0.0f);
		Film f2=new Film(1,"","2000","",null,null,"",null,new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		assertFalse(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail19() {
		Film f1=new Film(1,"","2000","",null,null,"",null,new ArrayList<Piattaforma>(),00.0f,"",0,0.0f);
		Film f2=new Film(1,"","2000","",null,null,"",null,new ArrayList<Piattaforma>(),00.0f,"",1,0.0f);
		assertFalse(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail20() {
		Film f1=new Film(1,"","2000","",null,null,"",null,null,00.0f,"",null,0.0f);
		Film f2=new Film(1,"","2000","",null,null,"",null,null,00.0f,"",null,0.0f);
		assertTrue(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail21() {
		Film f1=new Film(1,"","2000","",null,null,"",null,null,00.0f,"",null,0.0f);
		Film f2=new Film(1,"","2000","",null,null,"",null,new ArrayList<Piattaforma>(),00.0f,"",null,0.0f);
		assertFalse(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail22() {
		ArrayList<Piattaforma> p=new ArrayList<>();
		p.add(new Piattaforma("img","nome","link",0.0f));
		Film f1=new Film(1,"","2000","",null,null,"",null,new ArrayList<Piattaforma>(),00.0f,"",null,0.0f);
		Film f2=new Film(1,"","2000","",null,null,"",null,p,00.0f,"",null,0.0f);
		assertFalse(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail23() {
		Film f1=new Film(1,"","2000",null,null,null,"",null,null,00.0f,"",null,0.0f);
		Film f2=new Film(1,"","2000",null,null,null,"",null,null,00.0f,"",null,0.0f);
		assertTrue(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail24() {
		Film f1=new Film(1,"","2000",null,null,null,"",null,null,00.0f,"",null,0.0f);
		Film f2=new Film(1,"","2000","",null,null,"",null,null,00.0f,"",null,0.0f);
		assertFalse(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail25() {
		Film f1=new Film(1,"","2000","",null,null,"",null,null,00.0f,"",null,0.0f);
		Film f2=new Film(1,"","2000","sinossi",null,null,"",null,null,00.0f,"",null,0.0f);
		assertFalse(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail26() {
		Film f1=new Film(1,null,"2000",null,null,null,"",null,null,00.0f,"",null,0.0f);
		Film f2=new Film(1,null,"2000",null,null,null,"",null,null,00.0f,"",null,0.0f);
		assertTrue(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail27() {
		Film f1=new Film(1,null,"2000",null,null,null,"",null,null,00.0f,"",null,0.0f);
		Film f2=new Film(1,"","2000",null,null,null,"",null,null,00.0f,"",null,0.0f);
		assertFalse(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail28() {
		Film f1=new Film(1,"","2000",null,null,null,"",null,null,00.0f,"",null,0.0f);
		Film f2=new Film(1,"titolo","2000",null,null,null,"",null,null,00.0f,"",null,0.0f);
		assertFalse(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail29() {
		Film f1=new Film(1,null,"2000",null,null,null,null,null,null,00.0f,"",null,0.0f);
		Film f2=new Film(1,null,"2000",null,null,null,null,null,null,00.0f,"",null,0.0f);
		assertTrue(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail30() {
		Film f1=new Film(1,null,"2000",null,null,null,null,null,null,00.0f,"",null,0.0f);
		Film f2=new Film(1,null,"2000",null,null,null,"",null,null,00.0f,"",null,0.0f);
		assertFalse(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail31() {
		Film f1=new Film(1,null,"2000",null,null,null,"",null,null,00.0f,"",null,0.0f);
		Film f2=new Film(1,null,"2000",null,null,null,"trailer",null,null,00.0f,"",null,0.0f);
		assertFalse(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail32() {
		Film f1=new Film(1,null,"2000",null,null,null,null,null,null,00.0f,"",null,null);
		Film f2=new Film(1,null,"2000",null,null,null,null,null,null,00.0f,"",null,null);
		assertTrue(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail33() {
		Film f1=new Film(1,null,"2000",null,null,null,null,null,null,00.0f,"",null,null);
		Film f2=new Film(1,null,"2000",null,null,null,null,null,null,00.0f,"",null,0.0f);
		assertFalse(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail34() {
		Film f1=new Film(1,null,"2000",null,null,null,null,null,null,00.0f,"",null,0.0f);
		Film f2=new Film(1,null,"2000",null,null,null,null,null,null,00.0f,"",null,1.0f);
		assertFalse(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail35() {
		Film f1=new Film(1,null,"2000",null,null,null,null,null,null,null,"",null,null);
		Film f2=new Film(1,null,"2000",null,null,null,null,null,null,null,"",null,null);
		assertTrue(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail36() {
		Film f1=new Film(1,null,"2000",null,null,null,null,null,null,null,"",null,null);
		Film f2=new Film(1,null,"2000",null,null,null,null,null,null,00.0f,"",null,null);
		assertFalse(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail37() {
		Film f1=new Film(1,null,"2000",null,null,null,null,null,null,00.0f,"",null,null);
		Film f2=new Film(1,null,"2000",null,null,null,null,null,null,10.0f,"",null,null);
		assertFalse(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail38() {
		Film f1=new Film(1,null,"2000",null,null,null,null,null,null,null,null,null,null);
		Film f2=new Film(1,null,"2000",null,null,null,null,null,null,null,null,null,null);
		assertTrue(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail39() {
		Film f1=new Film(1,null,"2000",null,null,null,null,null,null,null,null,null,null);
		Film f2=new Film(1,null,"2000",null,null,null,null,null,null,null,"",null,null);
		assertFalse(f1.equals(f2));
	}
	
	@Test
	void testEqualsFail40() {
		Film f1=new Film(1,null,"2000",null,null,null,null,null,null,null,"",null,null);
		Film f2=new Film(1,null,"2000",null,null,null,null,null,null,null,"1",null,null);
		assertFalse(f1.equals(f2));
	}
}
