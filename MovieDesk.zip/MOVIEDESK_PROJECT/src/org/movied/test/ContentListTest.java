package org.movied.test;

import static org.junit.Assert.assertEquals;
import java.io.IOException;
import javax.servlet.ServletException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.movied.control.db.MovieDB;
import org.movied.control.redirect.ContentList;
import org.movied.model.dao.ContenutoDao;
import org.movied.model.dao.UtenteRegistratoDao;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockHttpSession;

class ContentListTest {

	private ContentList servlet;
	private MockHttpServletRequest request;
	private MockHttpServletResponse response;
	private MockHttpSession session;
	@BeforeEach
	void setUp() throws Exception {
		servlet = new ContentList();
		request = new MockHttpServletRequest();
		response = new MockHttpServletResponse();
		new MovieDB("jdbc:mysql://localhost:3306/db_moviedb","StandardUser","Password1");
		session = new MockHttpSession();
		request.setSession(session);
	}

	@Test
	public void testGetAllContent() throws ServletException, IOException{	
		servlet.doGet(request, response);
		assertEquals(new ContenutoDao().selectContent(),request.getAttribute("contenuti"));
	}
	
	@Test
	public void testGetContentByGenere() throws ServletException, IOException{	
		request.setParameter("filter", "genere");
		request.setParameter("value", "Film");
		servlet.doGet(request, response);
		assertEquals(new ContenutoDao().selectContent("genere","Film"),request.getAttribute("contenuti"));
	}
	
	@Test
	public void testGetContentByValutazione() throws ServletException, IOException{	
		request.setParameter("filter", "valutazioni");
		request.setParameter("value", "");
		servlet.doGet(request, response);
		assertEquals(new ContenutoDao().selectContent("valutazioni",""),request.getAttribute("contenuti"));
	}

	@Test
	public void testGetContentRecommendedFail() throws ServletException, IOException{	
		request.setParameter("filter", "recommended");
		servlet.doGet(request, response);
		assertEquals("Accedi per visualizzare i contenuti pi� adatti a te",request.getAttribute("message"));
	}
	
	@Test
	public void testGetContentRecommendedSuccess() throws ServletException, IOException{	
		request.setParameter("filter", "recommended");
		session.setAttribute("utente", new UtenteRegistratoDao().findUtente("mmanager@mail.com", "MediaManager01"));
		request.setSession(session);
		servlet.doGet(request, response);
		assertEquals(new ContenutoDao().selectContent("consigliati","mmanager@mail.com"),request.getAttribute("contenuti"));
	}
	
	@Test
	public void testGetContentbyTitle() throws ServletException, IOException{	
		request.setParameter("title", "Lucifer");
		servlet.doGet(request, response);
		assertEquals(new ContenutoDao().selectContent("Lucifer"),request.getAttribute("contenuti"));
	}
	
	@Test
	public void testGetContentbyYear() throws ServletException, IOException{	
		request.setParameter("year", "2015");
		servlet.doGet(request, response);
		assertEquals(new ContenutoDao().selectContent("anno","2015"),request.getAttribute("contenuti"));
	}
	
	@Test
	public void testFilterFail() throws ServletException, IOException{	
		request.setParameter("filter", "filter");
		servlet.doGet(request, response);
		assertEquals("Accedi per visualizzare i contenuti pi� adatti a te",request.getAttribute("message"));
	}
}
