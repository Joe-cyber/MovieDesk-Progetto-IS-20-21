package org.movied.test;

import static org.junit.jupiter.api.Assertions.*;
import java.io.IOException;
import javax.servlet.ServletException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.movied.control.db.MovieDB;
import org.movied.control.redirect.InsertContent;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockHttpSession;

class InsertContentTest {

	private InsertContent servlet;
	private MockHttpServletRequest request;
	private MockHttpServletResponse response;
	private MockHttpSession session;
	@BeforeEach
	void setUp() throws Exception {
		servlet = new InsertContent();
		request = new MockHttpServletRequest();
		response = new MockHttpServletResponse();
		new MovieDB("jdbc:mysql://localhost:3306/db_moviedb","StandardUser","Password1");
		session = new MockHttpSession();
		request.setSession(session);
	}
	
	@Test
	public void testInsertFilmSuccess() throws ServletException, IOException{	
		request.setParameter("genere1", "Film");
		request.setParameter("genere2", "Anime");
		request.setParameter("Regista", "regista");
		request.setParameter("Durata", "50.00");
		request.setParameter("Titolo", "titolo");
		request.setParameter("AnnoDiProduzione", "2000");
		request.setParameter("Sinossi", "sinossi");
		request.setParameter("Cast", "cast");
		request.setParameter("ImgCopertina", "https://www.google.com/url?sa=i&url=https%3A%2F%2Ftech.everyeye.it%2Fnotizie%2Fblackouttuesday-profili-instagram-tingono-nero-combattere-razzismo-449483.html&psig=AOvVaw3Buh2hisn6BQV1QZy3oBxk&ust=1610641942854000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCPDI3fqqme4CFQAAAAAdAAAAABAD");
		request.setParameter("Trailer", "https://www.youtube.com/embed/SP-cnRf7imM");
		request.setParameter("Valutazione", "3.5");
		servlet.doGet(request, response);
		assertEquals("Aggiunta avvenuta con successo.",request.getAttribute("message"));
	}
	
	@Test
	public void testInsertFilmFail() throws ServletException, IOException{	
		request.setParameter("genere1", "Film");
		request.setParameter("genere2", "Anime");
		request.setParameter("Regista", "regista");
		request.setParameter("Durata", "50.00");
		request.setParameter("Titolo", "titolo");
		request.setParameter("AnnoDiProduzione", "20000");
		request.setParameter("Sinossi", "sinossi");
		request.setParameter("Cast", "cast");
		request.setParameter("ImgCopertina", "https://www.google.com/url?sa=i&url=https%3A%2F%2Ftech.everyeye.it%2Fnotizie%2Fblackouttuesday-profili-instagram-tingono-nero-combattere-razzismo-449483.html&psig=AOvVaw3Buh2hisn6BQV1QZy3oBxk&ust=1610641942854000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCPDI3fqqme4CFQAAAAAdAAAAABAD");
		request.setParameter("Trailer","https://www.youtube.com/embed/SP-cnRf7imM");
		request.setParameter("Valutazione", "6.0");
		servlet.doGet(request, response);
		assertEquals("L'anno di produzione non rispetta la lunghezza richiesta.",request.getAttribute("message"));
	}
	@Test
	public void testInsertFilmFail2() throws ServletException, IOException{	
		request.setParameter("Titolo","Palm Springs Vivi come se non ci fosse un domaniiii");
		request.setParameter("ImgCopertina", "https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
		request.setParameter("Trailer","https://www.youtube.com/embed/jblwJhOhUQk");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Durata", "1.00");
		request.setParameter("genere1","Fantasy");
		request.setParameter("Cast","Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O�Malley, Clifford V. Johnson.");
		request.setParameter("Sinossi","Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra.");
		request.setParameter("Regista","Max Barbakow");
		request.setParameter("Valutazione","1.3");
		servlet.doGet(request, response);
		assertEquals("Il titolo non rispetta la lunghezza richiesta.",request.getAttribute("message"));
	}
	@Test
	public void testInsertSerieSuccess() throws ServletException, IOException{	
		request.setParameter("genere1", "Film");
		request.setParameter("genere2", "Anime");
		request.setParameter("Stagioni", "5");
		request.setParameter("Puntate", "10");
		request.setParameter("DurataEp", "10.00");
		request.setParameter("Titolo", "titolo");
		request.setParameter("AnnoDiProduzione", "2000");
		request.setParameter("Sinossi", "sinossi");
		request.setParameter("Cast", "cast");
		request.setParameter("ImgCopertina",  "https://www.google.com/url?sa=i&url=https%3A%2F%2Ftech.everyeye.it%2Fnotizie%2Fblackouttuesday-profili-instagram-tingono-nero-combattere-razzismo-449483.html&psig=AOvVaw3Buh2hisn6BQV1QZy3oBxk&ust=1610641942854000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCPDI3fqqme4CFQAAAAAdAAAAABAD");
		request.setParameter("Trailer","https://www.youtube.com/embed/SP-cnRf7imM");
		request.setParameter("Valutazione", "3.5");
		servlet.doGet(request, response);
		assertEquals("Aggiunta avvenuta con successo.",request.getAttribute("message"));
	}
	
	@Test
	public void testInsertFilmFail3() throws ServletException, IOException{	
		request.setParameter("Titolo","Palm Springs_Vivi come se non ci fosse un domani");
		request.setParameter("ImgCopertina", "https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
		request.setParameter("Trailer","https://www.youtube.com/embed/jblwJhOhUQk");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Durata", "1.00");
		request.setParameter("genere1","Fantasy");
		request.setParameter("Cast","Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O�Malley, Clifford V. Johnson.");
		request.setParameter("Sinossi","Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra.");
		request.setParameter("Regista","Max Barbakow");
		request.setParameter("Valutazione","1.3");
		servlet.doGet(request, response);
		assertEquals("Il titolo non rispetta il formato richiesto.",request.getAttribute("message"));
	}
	@Test
	public void testInsertFilmFail4() throws ServletException, IOException{	
		request.setParameter("Titolo","Palm Springs Vivi come se non ci fosse un domani");
		request.setParameter("ImgCopertina", "https://magazinepragma.com/wp-content/uploads/2020/11/palmspringsssssssssssssssssssswefu2hr4iu2thewknfwlekniewjmfqowp3fjeof43ijt539tu856580uy5ijoglqgjhribioervirnbietjhiothiuhbeojgoirjgiijtkfegvmkmvkfotnbhotuhgoiqwiekdowqkdpoewjfoirhg3g5hg0924fjelwpifjio5hgoughoiwjfoqwkd�ofhoiewwwwwwwwwwwwwfhhhhhhhhhhhhhhhhhhuerighiehgiurhegeuh�itgAeghuiaherughuihetighiuhjksVNkdndsmnv,dmvnmnvlknsfjvnkjebuerbgoiwrhokdfmkdmclkdavnkjnvjnbdfurngvoirwhfl  wiojdmsmwklmelkvndbn kjfdnbjunhutughioerujgipjrpvmdksmvsbnjkfbfgijerughnwiojfoewkdfedlwkgirjgiornbkfbnlsfnbkjsfnbfibnroeijgopewjgiorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughioorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohhregowkgnegkqopfjirhgoigswwwwwwwwwwwwwfhhhhhhhhhhhhhhhhhhuerighiehgiurhegeuh�itgAeghuiaherughuihetighiuhjksVNkdndsmnv,dmvnmnvlknsfjvnkjebuerbgoiwrhokdfmkdmclkdavnkjnvjnbdfurngvoirwhfl  wiojdmsmwklmelkvndbn kjfdnbjunhutughioerujgipjrpvmdksmvsbnjkfbfgijerughnwiojfoewkdfedlwkgirjgiornbkfbnlsfnbkjsfnbfibnroeijgopewjgiorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughioorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksd.jpg");
		request.setParameter("Trailer","https://www.youtube.com/embed/jblwJhOhUQk");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Durata", "1.00");
		request.setParameter("genere1","Fantasy");
		request.setParameter("Cast","Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O�Malley, Clifford V. Johnson.");
		request.setParameter("Sinossi","Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra.");
		request.setParameter("Regista","Max Barbakow");
		request.setParameter("Valutazione","1.3");
		servlet.doGet(request, response);
		assertEquals("L'immagine di copertina non rispetta la lunghezza richiesta.",request.getAttribute("message"));
	}
	@Test
	public void testInsertFilmFail5() throws ServletException, IOException{	
		request.setParameter("Titolo","Palm Springs Vivi come se non ci fosse un domani");
		request.setParameter("ImgCopertina", "magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
		request.setParameter("Trailer","https://www.youtube.com/embed/jblwJhOhUQk");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Durata", "1.00");
		request.setParameter("genere1","Fantasy");
		request.setParameter("Cast","Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O�Malley, Clifford V. Johnson.");
		request.setParameter("Sinossi","Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra.");
		request.setParameter("Regista","Max Barbakow");
		request.setParameter("Valutazione","1.3");
		servlet.doGet(request, response);
		assertEquals("L'immagine di copertina non rispetta il formato richiesto.",request.getAttribute("message"));
	}
	@Test
	public void testInsertFilmFail6() throws ServletException, IOException{	
		request.setParameter("Titolo","Palm Springs Vivi come se non ci fosse un domani");
		request.setParameter("ImgCopertina", "https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
		request.setParameter("Trailer","https://www.youtube.com/watch?v=jblwJhOhUfjhwpalmspringsssssssssssssssssssswefu2hr4iu2thewknfwlekniewjmfqowp3fjeof43ijt539tu856580uy5ijoglqgjhribioervirnbietjhiothiuhbeojgoirjgiijtkfegvmkmvkfotnbhotuhgoiqwiekdowqkdpoewjfoirhg3g5hg0924fjelwpifjio5hgoughoiwjfoqwkd�ofhoiewwwwwwwwwwwwwfhhhhhhhhhhhhhhhhhhuerighiehgiurhegeuh�itgAeghuiaherughuihetighiuhjksVNkdndsmnv,dmvnmnvlknsfjvnkjebuerbgoiwrhokdfmkdmclkdavnkjnvjnbdfurngvoirwhflwiojdmsmwklmelkvndbnkjfdnbjunhutughioerujgipjrpvmdksmvsbnjkfbfgijerughnwiojfoewkdfedlwkgirjgiornbkfbnlsfnbkjsfnbfibnroeijgopewjgiorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughioorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohhregowkgnegkqopfjirhgoigifuhwoieghowigQkuhjksVNkdndsmnv,dmvnmnvlknsfjvnkjebuerbgoiwrhokdfmkdmclkdavnkjnvjnbdfurngvoirwhflwiojdmsmwklmelkvndbnkjfdnbjunhutughioerujgipjrpvmdksmvsbnjkfbfgijerughnwiojfoewkdfedlwkgirjgiornbkfbnlsfnbkjsfnbfibnroeijgopewjgiorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughioorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndj");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Durata", "1.00");
		request.setParameter("genere1","Fantasy");
		request.setParameter("Cast","Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O�Malley, Clifford V. Johnson.");
		request.setParameter("Sinossi","Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra.");
		request.setParameter("Regista","Max Barbakow");
		request.setParameter("Valutazione","1.3");
		servlet.doGet(request, response);
		assertEquals("Il trailer non rispetta la lunghezza richiesta.",request.getAttribute("message"));
	}
	
	@Test
	public void testInsertFilmFail7() throws ServletException, IOException{	
		request.setParameter("Titolo","Palm Springs Vivi come se non ci fosse un domani");
		request.setParameter("ImgCopertina", "https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
		request.setParameter("Trailer","youtube.com/watch?v=jblwJhOhUQk");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Durata", "1.00");
		request.setParameter("genere1","Fantasy");
		request.setParameter("Cast","Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O�Malley, Clifford V. Johnson.");
		request.setParameter("Sinossi","Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra.");
		request.setParameter("Regista","Max Barbakow");
		request.setParameter("Valutazione","1.3");
		servlet.doGet(request, response);
		assertEquals("Il trailer non rispetta il formato richiesto.",request.getAttribute("message"));
	}
	@Test
	public void testInsertFilmFail8() throws ServletException, IOException{	
		request.setParameter("Titolo","Palm Springs Vivi come se non ci fosse un domani");
		request.setParameter("ImgCopertina", "https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
		request.setParameter("Trailer","https://www.youtube.com/embed/jblwJhOhUQk");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Durata", "1.00");
		request.setParameter("genere1","Fantasy");
		request.setParameter("Cast","Andy Samberg nei panni di Nyles, Cristin Milioti nei panni di Sarah Wilder, Peter Gallagher nei panni di Howard Wilder, J. K. Simmons nei panni di Roy, Meredith Hagner nei panni di Misty, Camila Mendes nei panni di Tala Anne Wilder, Tyler Hoechlin nei panni di Abraham Eugene Trent �Abe� Schlieffen, Chris Pang nei panni di Trevor, Jacqueline Obradors nei panni di Pia Wilder, June Squibb nei panni di Nana Schlieffen, Jena Friedman nei panni di Daisy, Tongayi Chirisa nei panni di Jerry, Dale Dickey nei panni di Darla, Conner O�Malley nei panni di Randy, Clifford V. Johnson nei panni del professore");
		request.setParameter("Sinossi","Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra.");
		request.setParameter("Regista","Max Barbakow");
		request.setParameter("Valutazione","1.3");
		servlet.doGet(request, response);
		assertEquals("Il cast non rispetta la lunghezza richiesta.",request.getAttribute("message"));
	}

	@Test
	public void testInsertFilmFail9() throws ServletException, IOException{	
		request.setParameter("Titolo","Palm Springs Vivi come se non ci fosse un domani");
		request.setParameter("ImgCopertina", "https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
		request.setParameter("Trailer","https://www.youtube.com/embed/jblwJhOhUQk");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Durata", "1.00");
		request.setParameter("genere1","Fantasy");
		request.setParameter("Cast","Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O�Malley, Clifford V. Johnson!");
		request.setParameter("Sinossi","Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra.");
		request.setParameter("Regista","Max Barbakow");
		request.setParameter("Valutazione","1.3");
		servlet.doGet(request, response);
		assertEquals("Il cast non rispetta il formato richiesto.",request.getAttribute("message"));
	}
	
	@Test
	public void testInsertFilmFail10() throws ServletException, IOException{	
		request.setParameter("Titolo","Palm Springs Vivi come se non ci fosse un domani");
		request.setParameter("ImgCopertina", "https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
		request.setParameter("Trailer","https://www.youtube.com/embed/jblwJhOhUQk");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Durata", "1.00");
		request.setParameter("genere1","Fantasy");
		request.setParameter("Cast","Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O'Malley, Clifford V. Johnson.");
		request.setParameter("Sinossi","La mattina del 9 novembre, per Nyles, inizia svegliandosi di fianco alla fidanzata Misty, con la prospettiva di una giornata da trascorrere tra piscina e celebrazioni in un resort nel deserto di Palm Springs. La coppia � l� per partecipare al matrimonio tra Abe e Tala, un'amica di Misty. Un momento speciale che per� Nyles sembra trattare con fin troppa svagatezza, brindando agli sposi in camicia hawaiana e salvando Sarah, sorella di Tala, da un discorso pubblico che la ragazza non vuole fare. Scappati insieme verso il deserto, Sarah vedr� Nyles trascinato in una grotta misteriosa, che ormai da tempo immemore lo costringe a rivivere la giornata del matrimonio senza soluzione di continuit�.");
		request.setParameter("Regista","Max Barbakow");
		request.setParameter("Valutazione","1.3");
		servlet.doGet(request, response);
		assertEquals("La sinossi non rispetta la lunghezza richiesta.",request.getAttribute("message"));
	}
	@Test
	public void testInsertFilmFail11() throws ServletException, IOException{	
		request.setParameter("Titolo","Palm Springs Vivi come se non ci fosse un domani");
		request.setParameter("ImgCopertina", "https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
		request.setParameter("Trailer","https://www.youtube.com/embed/jblwJhOhUQk");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Durata", "1.00");
		request.setParameter("genere1","Fantasy");
		request.setParameter("Cast","Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O'Malley, Clifford V. Johnson.");
		request.setParameter("Sinossi","Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm_Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra!!!");
		request.setParameter("Regista","Max Barbakow");
		request.setParameter("Valutazione","1.3");
		servlet.doGet(request, response);
		assertEquals("La sinossi non rispetta il formato richiesto.",request.getAttribute("message"));
	}
	@Test
	public void testInsertFilmFail12() throws ServletException, IOException{	
		request.setParameter("Titolo","Palm Springs Vivi come se non ci fosse un domani");
		request.setParameter("ImgCopertina", "https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
		request.setParameter("Trailer","https://www.youtube.com/embed/jblwJhOhUQk");
		request.setParameter("AnnoDiProduzione","20200");
		request.setParameter("Durata", "1.00");
		request.setParameter("genere1","Fantasy");
		request.setParameter("Cast","Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O'Malley, Clifford V. Johnson.");
		request.setParameter("Sinossi","Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra");
		request.setParameter("Regista","Max Barbakow");
		request.setParameter("Valutazione","1.3");
		servlet.doGet(request, response);
		assertEquals("L'anno di produzione non rispetta la lunghezza richiesta.",request.getAttribute("message"));
	}
	@Test
	public void testInsertFilmFail13() throws ServletException, IOException{	
		request.setParameter("Titolo","Palm Springs Vivi come se non ci fosse un domani");
		request.setParameter("ImgCopertina", "https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
		request.setParameter("Trailer","https://www.youtube.com/embed/jblwJhOhUQk");
		request.setParameter("AnnoDiProduzione","202o");
		request.setParameter("Durata", "1.00");
		request.setParameter("genere1","Fantasy");
		request.setParameter("Cast","Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O'Malley, Clifford V. Johnson.");
		request.setParameter("Sinossi","Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra");
		request.setParameter("Regista","Max Barbakow");
		request.setParameter("Valutazione","1.3");
		servlet.doGet(request, response);
		assertEquals("L'anno di produzione non rispetta il formato richiesto.",request.getAttribute("message"));
	}
	@Test
	public void testInsertFilmFail14() throws ServletException, IOException{	
		request.setParameter("Titolo","Palm Springs Vivi come se non ci fosse un domani");
		request.setParameter("ImgCopertina", "https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
		request.setParameter("Trailer","https://www.youtube.com/embed/jblwJhOhUQk");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Durata", "1000.00");
		request.setParameter("genere1","Fantasy");
		request.setParameter("Cast","Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O'Malley, Clifford V. Johnson.");
		request.setParameter("Sinossi","Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra");
		request.setParameter("Regista","Max Barbakow");
		request.setParameter("Valutazione","1.3");
		servlet.doGet(request, response);
		assertEquals("La durata non rispetta la lunghezza richiesta.",request.getAttribute("message"));
	}
	@Test
	public void testInsertFilmFail15() throws ServletException, IOException{	
		request.setParameter("Titolo","Palm Springs Vivi come se non ci fosse un domani");
		request.setParameter("ImgCopertina", "https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
		request.setParameter("Trailer","https://www.youtube.com/embed/jblwJhOhUQk");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Durata", "Ora");
		request.setParameter("genere1","Fantasy");
		request.setParameter("Cast","Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O'Malley, Clifford V. Johnson.");
		request.setParameter("Sinossi","Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra");
		request.setParameter("Regista","Max Barbakow");
		request.setParameter("Valutazione","1.3");
		servlet.doGet(request, response);
		assertEquals("La durata non rispetta il formato richiesto.",request.getAttribute("message"));
	}
	@Test
	public void testInsertFilmFail16() throws ServletException, IOException{	
		request.setParameter("Titolo","Palm Springs Vivi come se non ci fosse un domani");
		request.setParameter("ImgCopertina", "https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
		request.setParameter("Trailer","https://www.youtube.com/embed/jblwJhOhUQk");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Durata", "1.00");
		request.setParameter("genere1","Fantasy");
		request.setParameter("Cast","Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O'Malley, Clifford V. Johnson.");
		request.setParameter("Sinossi","Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra");
		request.setParameter("Regista","Max Barbakow � un regista e scrittore di Los Angeles in California. Max ha conseguito il suo MFA in regia presso il Conservatorio AFI.");
		request.setParameter("Valutazione","1.3");
		servlet.doGet(request, response);
		assertEquals("Il regista non rispetta la lunghezza richiesta.",request.getAttribute("message"));
	}
	@Test
	public void testInsertFilmFail17() throws ServletException, IOException{	
		request.setParameter("Titolo","Palm Springs Vivi come se non ci fosse un domani");
		request.setParameter("ImgCopertina", "https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
		request.setParameter("Trailer","https://www.youtube.com/embed/jblwJhOhUQk");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Durata", "1.00");
		request.setParameter("genere1","Fantasy");
		request.setParameter("Cast","Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O'Malley, Clifford V. Johnson.");
		request.setParameter("Sinossi","Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra");
		request.setParameter("Regista","Max_Barbakow");
		request.setParameter("Valutazione","1.3");
		servlet.doGet(request, response);
		assertEquals("Il regista non rispetta il formato richiesto.",request.getAttribute("message"));
	}
	@Test
	public void testInsertFilmFail18() throws ServletException, IOException{	
		request.setParameter("Titolo","Palm Springs Vivi come se non ci fosse un domani");
		request.setParameter("ImgCopertina", "https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
		request.setParameter("Trailer","https://www.youtube.com/embed/jblwJhOhUQk");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Durata", "1.00");
		request.setParameter("Cast","Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O'Malley, Clifford V. Johnson.");
		request.setParameter("Sinossi","Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra");
		request.setParameter("Regista","Max Barbakow");
		request.setParameter("Valutazione","1.3");
		servlet.doGet(request, response);
		assertEquals("Il genere non � stato selezionato.",request.getAttribute("message"));
	}
	@Test
	public void testInsertFilmFail19() throws ServletException, IOException{	
		request.setParameter("Titolo","Palm Springs Vivi come se non ci fosse un domani");
		request.setParameter("ImgCopertina", "https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
		request.setParameter("Trailer","https://www.youtube.com/embed/jblwJhOhUQk");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Durata", "1.00");
		request.setParameter("genere1","Fantasy");
		request.setParameter("Cast","Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O'Malley, Clifford V. Johnson.");
		request.setParameter("Sinossi","Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra");
		request.setParameter("Regista","Max Barbakow");
		request.setParameter("Valutazione","6.0");
		servlet.doGet(request, response);
		assertEquals("Le valutazioni non rispettano il formato richiesto.",request.getAttribute("message"));
	}
	
	@Test
	public void testInsertSerieFail() throws ServletException, IOException{	
		request.setParameter("genere1", "Film");
		request.setParameter("genere2", "Anime");
		request.setParameter("Stagioni", "5");
		request.setParameter("Puntate", "10");
		request.setParameter("DurataEp", "10.00");
		request.setParameter("Titolo", "titolo");
		request.setParameter("AnnoDiProduzione", "2000");
		request.setParameter("Sinossi", "sinossi");
		request.setParameter("Cast", "cast");
		request.setParameter("ImgCopertina",  "https://www.google.com/url?sa=i&url=https%3A%2F%2Ftech.everyeye.it%2Fnotizie%2Fblackouttuesday-profili-instagram-tingono-nero-combattere-razzismo-449483.html&psig=AOvVaw3Buh2hisn6BQV1QZy3oBxk&ust=1610641942854000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCPDI3fqqme4CFQAAAAAdAAAAABAD");
		request.setParameter("Trailer","https://www.youtube.com/embed/SP-cnRf7imM");
		request.setParameter("Valutazione", "6.0");
		servlet.doGet(request, response);
		assertEquals("Le valutazioni non rispettano il formato richiesto.",request.getAttribute("message"));
	}
	@Test
	public void testInsertSerieFail2() throws ServletException, IOException{	
		request.setParameter("Titolo","High School Musical The Musical The Series The Sing Along");
		request.setParameter("ImgCopertina","https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
		request.setParameter("Trailer","https://www.youtube.com/embed/RlaV8sJGhfc");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Stagioni","1");
		request.setParameter("Puntate","10");
		request.setParameter("genere1","Drammatico");
		request.setParameter("Cast","Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O�Malley, Clifford V. Johnson.");
		request.setParameter("Sinossi","In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale.");
		request.setParameter("DurataEp","0.28");
		request.setParameter("Valutazione","5.0");
		servlet.doGet(request, response);
		assertEquals("Il titolo non rispetta la lunghezza richiesta.",request.getAttribute("message"));
	}

	@Test
	public void testInsertSerieFail3() throws ServletException, IOException{	
		request.setParameter("Titolo","High School Musical The Series The Sing Along!");
		request.setParameter("ImgCopertina","https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
		request.setParameter("Trailer","https://www.youtube.com/embed/RlaV8sJGhfc");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Stagioni","1");
		request.setParameter("Puntate","10");
		request.setParameter("genere1","Drammatico");
		request.setParameter("Cast","Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O�Malley, Clifford V. Johnson.");
		request.setParameter("Sinossi","In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale.");
		request.setParameter("DurataEp","0.28");
		request.setParameter("Valutazione","5.0");
		servlet.doGet(request, response);
		assertEquals("Il titolo non rispetta il formato richiesto.",request.getAttribute("message"));
	}
	@Test
	public void testInsertSerieFail4() throws ServletException, IOException{	
		request.setParameter("Titolo","High School Musical The Series The Sing Along");
		request.setParameter("ImgCopertina","https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoirh8C7345146ghowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoirh8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
		request.setParameter("Trailer","https://www.youtube.com/embed/RlaV8sJGhfc");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Stagioni","1");
		request.setParameter("Puntate","10");
		request.setParameter("genere1","Drammatico");
		request.setParameter("Cast","Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O�Malley, Clifford V. Johnson.");
		request.setParameter("Sinossi","In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale.");
		request.setParameter("DurataEp","0.28");
		request.setParameter("Valutazione","5.0");
		servlet.doGet(request, response);
		assertEquals("L'immagine di copertina non rispetta la lunghezza richiesta.",request.getAttribute("message"));
	}
	@Test
	public void testInsertSerieFail5() throws ServletException, IOException{	
		request.setParameter("Titolo","High School Musical The Series The Sing Along");
		request.setParameter("ImgCopertina","delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
		request.setParameter("Trailer","https://www.youtube.com/embed/RlaV8sJGhfc");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Stagioni","1");
		request.setParameter("Puntate","10");
		request.setParameter("genere1","Drammatico");
		request.setParameter("Cast","Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O�Malley, Clifford V. Johnson.");
		request.setParameter("Sinossi","In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale.");
		request.setParameter("DurataEp","0.28");
		request.setParameter("Valutazione","5.0");
		servlet.doGet(request, response);
		assertEquals("L'immagine di copertina non rispetta il formato richiesto.",request.getAttribute("message"));
	}
	@Test
	public void testInsertSerieFail6() throws ServletException, IOException{	
		request.setParameter("Titolo","High School Musical The Series The Sing Along");
		request.setParameter("ImgCopertina","https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
		request.setParameter("Trailer","://www.youtube.com/watch?v=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV://www.youtube.com/watch?v=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaVcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Stagioni","1");
		request.setParameter("Puntate","10");
		request.setParameter("genere1","Drammatico");
		request.setParameter("Cast","Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O�Malley, Clifford V. Johnson.");
		request.setParameter("Sinossi","In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale.");
		request.setParameter("DurataEp","0.28");
		request.setParameter("Valutazione","5.0");
		servlet.doGet(request, response);
		assertEquals("Il trailer non rispetta la lunghezza richiesta.",request.getAttribute("message"));
	}
	@Test
	public void testInsertSerieFail7() throws ServletException, IOException{	
		request.setParameter("Titolo","High School Musical The Series The Sing Along");
		request.setParameter("ImgCopertina","https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
		request.setParameter("Trailer","youtube.com/embed/RlaV8sJGhfc");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Stagioni","1");
		request.setParameter("Puntate","10");
		request.setParameter("genere1","Drammatico");
		request.setParameter("Cast","Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O�Malley, Clifford V. Johnson.");
		request.setParameter("Sinossi","In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale.");
		request.setParameter("DurataEp","0.28");
		request.setParameter("Valutazione","5.0");
		servlet.doGet(request, response);
		assertEquals("Il trailer non rispetta il formato richiesto.",request.getAttribute("message"));
	}
	@Test
	public void testInsertSerieFail8() throws ServletException, IOException{	
		request.setParameter("Titolo","High School Musical The Series The Sing Along");
		request.setParameter("ImgCopertina","https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
		request.setParameter("Trailer","https://www.youtube.com/embed/RlaV8sJGhfc");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Stagioni","1");
		request.setParameter("Puntate","10");
		request.setParameter("genere1","Drammatico");
		request.setParameter("Cast","Olivia Rodrigo nei panni di Nini Salazar-Roberts, un'appassionata di teatro musicale, che interpreta il ruolo di Gabriella Montez. Joshua Bassett nei panni di Ricky Bowen, un chitarrista e skateboarder che in precedenza ha frequentato Nini, che � stato scelto come Troy Bolton nonostante la sua iniziale mancanza di interesse per il musical.Matt Cornett nei panni di E.  J. Caswell, un atleta appassionato di teatro che Nini aveva gi� incontrato al campo di teatro, che � stato scelto per interpretare Chad Danforth e il sostituto di Troy.Sofia Wylie nel ruolo di Gina Porter, una studentessa trasferita con ambizioni teatrali, che interpreta Taylor McKessie e la sostituta di Gabriella.Larry Saperstein nei panni di Big Red, il migliore amico di Ricky, che sostituisce il direttore di scena per la produzione ogni volta che Natalie non � disponibile, nonostante la sua mancanza di conoscenza del teatro. Successivamente gli viene mostrato di possedere talenti nascosti nel tip tap e nella conoscenza dell'elettronica.Julia Lester nei panni di Ashlyn Caswell,  cugina di E. J. e aspirante cantautrice, che interpreta la signora Darbus..");
		request.setParameter("Sinossi","In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale.");
		request.setParameter("DurataEp","0.28");
		request.setParameter("Valutazione","5.0");
		servlet.doGet(request, response);
		assertEquals("Il cast non rispetta la lunghezza richiesta.",request.getAttribute("message"));
	}
	@Test
	public void testInsertSerieFail9() throws ServletException, IOException{	
		request.setParameter("Titolo","High School Musical The Series The Sing Along");
		request.setParameter("ImgCopertina","https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
		request.setParameter("Trailer","https://www.youtube.com/embed/RlaV8sJGhfc");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Stagioni","1");
		request.setParameter("Puntate","10");
		request.setParameter("genere1","Drammatico");
		request.setParameter("Cast","Olivia Rodrigo-Joshua Basset-Matt Cornett-Sofia Wylie-Julia Lester-Larry Saperstein-Frankie Rodriguez-Dara Rene�-Mark St. Cyr-Kate Reinders");
		request.setParameter("Sinossi","In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale.");
		request.setParameter("DurataEp","0.28");
		request.setParameter("Valutazione","5.0");
		servlet.doGet(request, response);
		assertEquals("Il cast non rispetta il formato richiesto.",request.getAttribute("message"));
	}
	@Test
	public void testInsertSerieFail10() throws ServletException, IOException{	
		request.setParameter("Titolo","High School Musical The Series The Sing Along");
		request.setParameter("ImgCopertina","https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
		request.setParameter("Trailer","https://www.youtube.com/embed/RlaV8sJGhfc");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Stagioni","1");
		request.setParameter("Puntate","10");
		request.setParameter("genere1","Drammatico");
		request.setParameter("Cast","Olivia Rodrigo, Joshua Basset-Matt Cornett, Sofia Wylie,Julia Lester,Larry Saperstein,Frankie Rodriguez.");
		request.setParameter("Sinossi","La notte di capodanno, due ragazzi, Troy e Gabriella, si incontrano ad una festa. Entrambi vengono scelti per cantare un duetto al karaoke (Start of Something New). Terminata l'esibizione, i due si scambiano i numeri di telefono. In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale");
		request.setParameter("DurataEp","0.28");
		request.setParameter("Valutazione","5.0");
		servlet.doGet(request, response);
		assertEquals("La sinossi non rispetta la lunghezza richiesta.",request.getAttribute("message"));
	}
	@Test
	public void testInsertSerieFail11() throws ServletException, IOException{	
		request.setParameter("Titolo","High School Musical The Series The Sing Along");
		request.setParameter("ImgCopertina","https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
		request.setParameter("Trailer","https://www.youtube.com/embed/RlaV8sJGhfc");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Stagioni","1");
		request.setParameter("Puntate","10");
		request.setParameter("genere1","Drammatico");
		request.setParameter("Cast","Olivia Rodrigo, Joshua Basset-Matt Cornett, Sofia Wylie,Julia Lester,Larry Saperstein,Frankie Rodriguez.");
		request.setParameter("Sinossi","In una versione romanzata della East_High_School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High_School_Musical: The_Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale!");
		request.setParameter("DurataEp","0.28");
		request.setParameter("Valutazione","5.0");
		servlet.doGet(request, response);
		assertEquals("La sinossi non rispetta il formato richiesto.",request.getAttribute("message"));
	}
	@Test
	public void testInsertSerieFail12() throws ServletException, IOException{	
		request.setParameter("Titolo","High School Musical The Series The Sing Along");
		request.setParameter("ImgCopertina","https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
		request.setParameter("Trailer","https://www.youtube.com/embed/RlaV8sJGhfc");
		request.setParameter("AnnoDiProduzione","20200");
		request.setParameter("Stagioni","1");
		request.setParameter("Puntate","10");
		request.setParameter("genere1","Drammatico");
		request.setParameter("Cast","Olivia Rodrigo, Joshua Basset-Matt Cornett, Sofia Wylie,Julia Lester,Larry Saperstein,Frankie Rodriguez.");
		request.setParameter("Sinossi","In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale");
		request.setParameter("DurataEp","0.28");
		request.setParameter("Valutazione","5.0");
		servlet.doGet(request, response);
		assertEquals("L'anno di produzione non rispetta la lunghezza richiesta.",request.getAttribute("message"));
	}
	@Test
	public void testInsertSerieFail13() throws ServletException, IOException{	
		request.setParameter("Titolo","High School Musical The Series The Sing Along");
		request.setParameter("ImgCopertina","https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
		request.setParameter("Trailer","https://www.youtube.com/embed/RlaV8sJGhfc");
		request.setParameter("AnnoDiProduzione","202o");
		request.setParameter("Stagioni","1");
		request.setParameter("Puntate","10");
		request.setParameter("genere1","Drammatico");
		request.setParameter("Cast","Olivia Rodrigo, Joshua Basset-Matt Cornett, Sofia Wylie,Julia Lester,Larry Saperstein,Frankie Rodriguez.");
		request.setParameter("Sinossi","In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale");
		request.setParameter("DurataEp","0.28");
		request.setParameter("Valutazione","5.0");
		servlet.doGet(request, response);
		assertEquals("L'anno di produzione non rispetta il formato richiesto.",request.getAttribute("message"));
	}
	@Test
	public void testInsertSerieFail14() throws ServletException, IOException{	
		request.setParameter("Titolo","High School Musical The Series The Sing Along");
		request.setParameter("ImgCopertina","https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
		request.setParameter("Trailer","https://www.youtube.com/embed/RlaV8sJGhfc");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Stagioni","1");
		request.setParameter("Puntate","10");
		request.setParameter("genere1","Drammatico");
		request.setParameter("Cast","Olivia Rodrigo, Joshua Basset-Matt Cornett, Sofia Wylie,Julia Lester,Larry Saperstein,Frankie Rodriguez.");
		request.setParameter("Sinossi","In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale");
		request.setParameter("DurataEp","100000.00");
		request.setParameter("Valutazione","5.0");
		servlet.doGet(request, response);
		assertEquals("La durata media episodio non rispetta la lunghezza richiesta.",request.getAttribute("message"));
	}
	@Test
	public void testInsertSerieFail15() throws ServletException, IOException{	
		request.setParameter("Titolo","High School Musical The Series The Sing Along");
		request.setParameter("ImgCopertina","https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
		request.setParameter("Trailer","https://www.youtube.com/embed/RlaV8sJGhfc");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Stagioni","1");
		request.setParameter("Puntate","10");
		request.setParameter("genere1","Drammatico");
		request.setParameter("Cast","Olivia Rodrigo, Joshua Basset-Matt Cornett, Sofia Wylie,Julia Lester,Larry Saperstein,Frankie Rodriguez.");
		request.setParameter("Sinossi","In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale");
		request.setParameter("DurataEp","uno");
		request.setParameter("Valutazione","5.0");
		servlet.doGet(request, response);
		assertEquals("La durata media episodio non rispetta il formato richiesto.",request.getAttribute("message"));
	}
	@Test
	public void testInsertSerieFail16() throws ServletException, IOException{	
		request.setParameter("Titolo","High School Musical The Series The Sing Along");
		request.setParameter("ImgCopertina","https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
		request.setParameter("Trailer","https://www.youtube.com/embed/RlaV8sJGhfc");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Stagioni","1");
		request.setParameter("Puntate","100000");
		request.setParameter("genere1","Drammatico");
		request.setParameter("Cast","Olivia Rodrigo, Joshua Basset-Matt Cornett, Sofia Wylie,Julia Lester,Larry Saperstein,Frankie Rodriguez.");
		request.setParameter("Sinossi","In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale");
		request.setParameter("DurataEp","0.28");
		request.setParameter("Valutazione","5.0");
		servlet.doGet(request, response);
		assertEquals("Il numero di puntate non rispetta la lunghezza richiesta.",request.getAttribute("message"));
	}
	@Test
	public void testInsertSerieFail17() throws ServletException, IOException{	
		request.setParameter("Titolo","High School Musical The Series The Sing Along");
		request.setParameter("ImgCopertina","https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
		request.setParameter("Trailer","https://www.youtube.com/embed/RlaV8sJGhfc");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Stagioni","1");
		request.setParameter("Puntate","uno");
		request.setParameter("genere1","Drammatico");
		request.setParameter("Cast","Olivia Rodrigo, Joshua Basset-Matt Cornett, Sofia Wylie,Julia Lester,Larry Saperstein,Frankie Rodriguez.");
		request.setParameter("Sinossi","In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale");
		request.setParameter("DurataEp","0.28");
		request.setParameter("Valutazione","5.0");
		servlet.doGet(request, response);
		assertEquals("Il numero di puntate non rispetta il formato richiesto.",request.getAttribute("message"));
	}
	@Test
	public void testInsertSerieFail18() throws ServletException, IOException{	
		request.setParameter("Titolo","High School Musical The Series The Sing Along");
		request.setParameter("ImgCopertina","https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
		request.setParameter("Trailer","https://www.youtube.com/embed/RlaV8sJGhfc");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Stagioni","1");
		request.setParameter("Puntate","10");
		request.setParameter("Cast","Olivia Rodrigo, Joshua Basset-Matt Cornett, Sofia Wylie,Julia Lester,Larry Saperstein,Frankie Rodriguez.");
		request.setParameter("Sinossi","In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale");
		request.setParameter("DurataEp","0.28");
		request.setParameter("Valutazione","5.0");
		servlet.doGet(request, response);
		assertEquals("Il genere non � stato selezionato.",request.getAttribute("message"));
	}
	@Test
	public void testInsertSerieFail19() throws ServletException, IOException{	
		request.setParameter("Titolo","High School Musical The Series The Sing Along");
		request.setParameter("ImgCopertina","https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
		request.setParameter("Trailer","https://www.youtube.com/embed/RlaV8sJGhfc");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Stagioni","100000.00");
		request.setParameter("Puntate","10");
		request.setParameter("genere1","Drammatico");
		request.setParameter("Cast","Olivia Rodrigo, Joshua Basset-Matt Cornett, Sofia Wylie,Julia Lester,Larry Saperstein,Frankie Rodriguez.");
		request.setParameter("Sinossi","In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale");
		request.setParameter("DurataEp","0.28");
		request.setParameter("Valutazione","5.0");
		servlet.doGet(request, response);
		assertEquals("Il numero di stagioni non rispetta la lunghezza richiesta.",request.getAttribute("message"));
	}
	@Test
	public void testInsertSerieFail20() throws ServletException, IOException{	
		request.setParameter("Titolo","High School Musical The Series The Sing Along");
		request.setParameter("ImgCopertina","https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
		request.setParameter("Trailer","https://www.youtube.com/embed/RlaV8sJGhfc");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Stagioni","una");
		request.setParameter("Puntate","10");
		request.setParameter("genere1","Drammatico");
		request.setParameter("Cast","Olivia Rodrigo, Joshua Basset-Matt Cornett, Sofia Wylie,Julia Lester,Larry Saperstein,Frankie Rodriguez.");
		request.setParameter("Sinossi","In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale");
		request.setParameter("DurataEp","0.28");
		request.setParameter("Valutazione","5.0");
		servlet.doGet(request, response);
		assertEquals("Il numero di stagioni non rispetta il formato richiesto.",request.getAttribute("message"));
	}
	@Test
	public void testInsertSerieFail21() throws ServletException, IOException{	
		request.setParameter("Titolo","High School Musical The Series The Sing Along");
		request.setParameter("ImgCopertina","https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
		request.setParameter("Trailer","https://www.youtube.com/embed/RlaV8sJGhfc");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Stagioni","1");
		request.setParameter("Puntate","10");
		request.setParameter("genere1","Drammatico");
		request.setParameter("Cast","Olivia Rodrigo, Joshua Basset-Matt Cornett, Sofia Wylie,Julia Lester,Larry Saperstein,Frankie Rodriguez.");
		request.setParameter("Sinossi","In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale");
		request.setParameter("DurataEp","0.28");
		request.setParameter("Valutazione","5000.0");
		servlet.doGet(request, response);
		assertEquals("Le valutazioni non rispettano la lunghezza richiesta.",request.getAttribute("message"));
	}
	@Test
	public void testInsertSerieFail22() throws ServletException, IOException{	
		request.setParameter("Titolo","High School Musical The Series The Sing Along");
		request.setParameter("ImgCopertina","https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
		request.setParameter("Trailer","https://www.youtube.com/embed/RlaV8sJGhfc");
		request.setParameter("AnnoDiProduzione","2020");
		request.setParameter("Stagioni","1");
		request.setParameter("Puntate","10");
		request.setParameter("genere1","Drammatico");
		request.setParameter("Cast","Olivia Rodrigo, Joshua Basset-Matt Cornett, Sofia Wylie,Julia Lester,Larry Saperstein,Frankie Rodriguez.");
		request.setParameter("Sinossi","In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale");
		request.setParameter("DurataEp","0.28");
		request.setParameter("Valutazione","tre");
		servlet.doGet(request, response);
		assertEquals("Le valutazioni non rispettano il formato richiesto.",request.getAttribute("message"));
	}
}
