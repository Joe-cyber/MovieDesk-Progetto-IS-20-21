package org.movied.test;

import static org.junit.jupiter.api.Assertions.*;
import java.io.IOException;
import javax.servlet.ServletException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.movied.control.db.MovieDB;
import org.movied.control.redirect.PlatformList;
import org.movied.model.dao.PiattaformaDao;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

class PlatformListTest {

	private PlatformList servlet;
	private MockHttpServletRequest request;
	private MockHttpServletResponse response;
	@BeforeEach
	void setUp() throws Exception {
		servlet = new PlatformList();
		request = new MockHttpServletRequest();
		response = new MockHttpServletResponse();
		new MovieDB("jdbc:mysql://localhost:3306/db_moviedb","StandardUser","Password1");
	}

	@Test
	public void testListAll() throws ServletException, IOException{	
		servlet.doPost(request, response);
		assertEquals(new PiattaformaDao().selectPlatform(),request.getAttribute("piattaforme"));
	}

}
