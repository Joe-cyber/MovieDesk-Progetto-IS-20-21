package org.movied.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.movied.control.db.MovieDB;
import org.movied.model.bean.Film;
import org.movied.model.bean.Piattaforma;
import org.movied.model.bean.Contenuto.Genere;
import org.movied.model.dao.FilmDao;
import org.movied.model.dao.PiattaformaDao;

class FilmDaoTest {

	private FilmDao dao;
	private Film film;
	
	@BeforeEach
	void setUp() throws Exception {
		dao=new FilmDao();
		new MovieDB("jdbc:mysql://localhost:3306/db_moviedb","StandardUser","Password1");
		ArrayList<Genere> generi=new ArrayList<>();
		generi.add(Genere.Anime);
		generi.add(Genere.Bambini);
		ArrayList<Piattaforma> piattaforme=new ArrayList<>();
		piattaforme.add(new PiattaformaDao().selectSinglePlatform("Netflix"));
		film=new Film(1,"titolo","2000","sinossi","cast","www.imgCopertina.it","www.trailer.com",generi,piattaforme,50.0f,"regista",0,4.0f);
	}
	
	@Test
	void testInsertFilmSuccess() {
		assertEquals(1,dao.insertFilmContent(film));
	}
	
	@Test
	void testInsertFilmFail() {
		film.setValutazione(0.0f);
		assertEquals(0,dao.insertFilmContent(film));
	}
}
