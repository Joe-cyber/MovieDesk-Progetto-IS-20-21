package org.movied.test;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

import javax.servlet.ServletException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.movied.control.db.MovieDB;
import org.movied.control.redirect.ResetPassword;
import org.movied.model.bean.UtenteRegistrato;
import org.movied.model.dao.UtenteRegistratoDao;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockHttpSession;

class ResetPasswordTest {

	private ResetPassword servlet;
	private MockHttpServletRequest request;
	private MockHttpServletResponse response;
	private MockHttpSession session;
	@BeforeEach
	void setUp() throws Exception {
		servlet = new ResetPassword();
		request = new MockHttpServletRequest();
		response = new MockHttpServletResponse();
		new MovieDB("jdbc:mysql://localhost:3306/db_moviedb","StandardUser","Password1");
		session = new MockHttpSession();
		request.setSession(session);
	}
	
	@Test
	public void testResetPasswordFail() throws ServletException, IOException{	
		request.setParameter("email", "mmanager@email.com");
		servlet.doGet(request, response);
		assertEquals("� stato riscontrato un problema durante l'esecuzione dell'operazione",request.getAttribute("message"));
	}

	@Test
	public void testResetPasswordSuccess() throws ServletException, IOException{			
		request.setParameter("email", "mmanager@mail.com");
		servlet.doGet(request, response);
		assertEquals("� stata inviata una nuova password. Controlla l'indirizzo di posta elettronica.",request.getAttribute("message"));
		UtenteRegistrato user=new UtenteRegistratoDao().findUtente("mmanager@mail.com");
		user.setPassword("MediaManager01");
		new UtenteRegistratoDao().updatePersonalData(user);
	}
}
