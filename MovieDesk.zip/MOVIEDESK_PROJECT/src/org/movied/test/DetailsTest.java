package org.movied.test;

import static org.junit.jupiter.api.Assertions.*;
import java.io.IOException;
import javax.servlet.ServletException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.movied.control.db.MovieDB;
import org.movied.control.redirect.Details;
import org.movied.model.dao.ContenutoDao;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

class DetailsTest {

	private Details servlet;
	private MockHttpServletRequest request;
	private MockHttpServletResponse response;
	@BeforeEach
	void setUp() throws Exception {
		servlet = new Details();
		request = new MockHttpServletRequest();
		response = new MockHttpServletResponse();
		new MovieDB("jdbc:mysql://localhost:3306/db_moviedb","StandardUser","Password1");
	}

	@Test
	public void testWithId() throws ServletException, IOException{	
		request.setParameter("id", "1");
		servlet.doPost(request, response);
		assertEquals(new ContenutoDao().getContentDetails(1),request.getAttribute("content"));
	}

	@Test
	public void testWithout() throws ServletException, IOException{	
		servlet.doPost(request, response);
	}
}
