package org.movied.test;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Connection;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.movied.control.db.MovieDB;


class MovieDBTest {


	@Test
	void testGetConnection() {
		MovieDB.getConnection();
		MovieDB.releaseConnection(MovieDB.getConnection());
		List<Connection> conn=MovieDB.getFreeDbConnection();
		assertEquals(conn.get(0),MovieDB.getConnection());
	}

	@Test
	void testReleaseConnection() {
		new MovieDB("jdbc:mysql://localhost:3306/","StandardUser","Password1");
		MovieDB.releaseConnection(MovieDB.getConnection());
		List<Connection> conn=MovieDB.getFreeDbConnection();
		assertEquals(conn.get(0),MovieDB.getConnection());
	}

	@Test
	void testGetUrl() {
		MovieDB db=new MovieDB("jdbc:mysql://localhost:3306/","StandardUser","Password1");
		assertEquals("jdbc:mysql://localhost:3306/",db.getUrl());
	}

	@Test
	void testGetUsername() {
		new MovieDB("jdbc:mysql://localhost:3306/","StandardUser","Password1");
		assertEquals("StandardUser",MovieDB.getUsername());
	}

	@Test
	void testGetPassword() {
		new MovieDB("jdbc:mysql://localhost:3306/","StandardUser","Password1");
		assertEquals("Password1",MovieDB.getPassword());
	}
	
	@Test
	void testSetUsername() {
		new MovieDB("jdbc:mysql://localhost:3306/","StandardUser","Password1");
		MovieDB.setUsername("otherUsername");
		assertEquals("otherUsername", MovieDB.getUsername());
	}

	@Test
	void testSetPassword() {
		new MovieDB("jdbc:mysql://localhost:3306/","StandardUser","Password1");
		MovieDB.setPassword("otherPassword");
		assertEquals("otherPassword", MovieDB.getPassword());
	}

	@Test
	void testSetUrl() {
		MovieDB db=new MovieDB("jdbc:mysql://localhost:3306/","StandardUser","Password1");
		MovieDB.setUrl("otherUrl");
		assertEquals("otherUrl", db.getUrl());
	}

}
