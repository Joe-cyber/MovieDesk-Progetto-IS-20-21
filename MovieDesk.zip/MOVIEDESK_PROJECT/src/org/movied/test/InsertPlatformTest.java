package org.movied.test;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

import javax.servlet.ServletException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.movied.control.db.MovieDB;
import org.movied.control.redirect.InsertPlatform;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockHttpSession;

class InsertPlatformTest {

	private InsertPlatform servlet;
	private MockHttpServletRequest request;
	private MockHttpServletResponse response;
	private MockHttpSession session;
	@BeforeEach
	void setUp() throws Exception {
		servlet = new InsertPlatform();
		request = new MockHttpServletRequest();
		response = new MockHttpServletResponse();
		new MovieDB("jdbc:mysql://localhost:3306/db_moviedb","StandardUser","Password1");
		session = new MockHttpSession();
		request.setSession(session);
	}
	
	@Test
	public void testInsertPlatformSuccess() throws ServletException, IOException{	
		request.setParameter("imgPiattaforma", "https://www.google.com/url?sa=i&url=https%3A%2F%2Ftech.everyeye.it%2Fnotizie%2Fblackouttuesday-profili-instagram-tingono-nero-combattere-razzismo-449483.html&psig=AOvVaw3Buh2hisn6BQV1QZy3oBxk&ust=1610641942854000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCPDI3fqqme4CFQAAAAAdAAAAABAD");
		request.setParameter("nomePiattaforma", "Piattaforma");
		request.setParameter("link", "https://www.google.com/");
		request.setParameter("abbonamentoMinimo", "10.00");
		servlet.doGet(request, response);
		assertEquals("Aggiunta avvenuta con successo.",request.getAttribute("message"));
	}

	@Test
	public void testInsertPlatformFail() throws ServletException, IOException{	
		request.setParameter("imgPiattaforma", "https://www.google.com/url?sa=i&url=https%3A%2F%2Ftech.everyeye.it%2Fnotizie%2Fblackouttuesday-profili-instagram-tingono-nero-combattere-razzismo-449483.html&psig=AOvVaw3Buh2hisn6BQV1QZy3oBxk&ust=1610641942854000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCPDI3fqqme4CFQAAAAAdAAAAABAD");
		request.setParameter("nomePiattaforma", "Netflix");
		request.setParameter("link", "https://www.google.com/");
		request.setParameter("abbonamentoMinimo", "100.00");
		servlet.doGet(request, response);
		assertEquals("L'abbonamento minimo non rispetta la lunghezza richiesta.",request.getAttribute("message"));
	}
}
