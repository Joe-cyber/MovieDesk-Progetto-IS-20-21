package org.movied.test.system;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

class FiltraggioDeiContenutiPerAnnoDiProduzione {

	private String url="http://127.0.0.1/MOVIEDESK_PROJECT/ContentList";
	
	@Test
	void tc_01(){
		  System.setProperty("webdriver.chrome.driver","C:\\Users\\calie\\OneDrive\\Desktop\\chromedriver.exe");
	      WebDriver browser = new ChromeDriver();
	      browser.get(url.concat("?year"));
	      assertEquals("Seleziona un anno di produzione per filtrare la visualizzazione.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	
	@Test
	void tc_02(){
		  System.setProperty("webdriver.chrome.driver","C:\\Users\\calie\\OneDrive\\Desktop\\chromedriver.exe");
	      WebDriver browser = new ChromeDriver();
	      browser.get(url);
	      browser.findElement(By.name("year")).sendKeys("2003");	
	      browser.findElement(By.id("submitFilter")).click();
	      assertEquals("Pirati dei caraibi la maledizione della prima luna",browser.findElement(By.id("content-title")).getText());
	      browser.close();
	}
}
