package org.movied.test.system;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

class AggiuntaDiUnContenutoDiTipoFilm {

	private WebDriver browser;
	private String url="http://127.0.0.1/MOVIEDESK_PROJECT/PersonalArea#p-view-6#collapseSix";
	@BeforeEach
	void initSession() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\calie\\OneDrive\\Desktop\\chromedriver.exe");
		browser = new ChromeDriver();
	    browser.get(url);
	    browser.findElement(By.id("email2")).sendKeys("mmanager@mail.com");
	    browser.findElement(By.id("password2")).sendKeys("MediaManager01");
	    browser.findElement(By.id("submitform")).click();		
	    browser.findElement(By.id("add")).click();	
	    browser.findElement(By.id("addFilm")).click();	
	}
	
	@Test
	void tc_01() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo")).sendKeys("Palm Springs Vivi come se non ci fosse un domaniiii");
	      browser.findElement(By.id("ImgCopertina")).sendKeys("https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
	      browser.findElement(By.id("Trailer")).sendKeys("https://www.youtube.com/embed/jblwJhOhUQk");
	      browser.findElement(By.id("AnnoDiProduzione")).sendKeys("2020");
	      browser.findElement(By.id("Durata")).sendKeys("1.00");
	      browser.findElement(By.id("Genere1")).sendKeys("Fantasy");
	      browser.findElement(By.id("Cast")).sendKeys("Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O�Malley, Clifford V. Johnson.");
	      browser.findElement(By.id("Sinossi")).sendKeys("Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra.");
	      browser.findElement(By.id("Regista")).sendKeys("Max Barbakow");
	      browser.findElement(By.id("Valutazione")).sendKeys("1.3");
	      browser.findElement(By.id("submitFilm")).click();	
	      Thread.sleep(1100);
	      assertEquals("Il titolo non rispetta la lunghezza richiesta.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	
	@Test
	void tc_02() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo")).sendKeys("Palm Springs_Vivi come se non ci fosse un domani");
	      browser.findElement(By.id("ImgCopertina")).sendKeys("https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
	      browser.findElement(By.id("Trailer")).sendKeys("https://www.youtube.com/embed/jblwJhOhUQk");
	      browser.findElement(By.id("AnnoDiProduzione")).sendKeys("2020");
	      browser.findElement(By.id("Durata")).sendKeys("1.00");
	      browser.findElement(By.id("Genere1")).sendKeys("Fantasy");
	      browser.findElement(By.id("Cast")).sendKeys("Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O�Malley, Clifford V. Johnson.");
	      browser.findElement(By.id("Sinossi")).sendKeys("Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra.");
	      browser.findElement(By.id("Regista")).sendKeys("Max Barbakow");
	      browser.findElement(By.id("Valutazione")).sendKeys("1.3");
	      browser.findElement(By.id("submitFilm")).click();	
	      Thread.sleep(1100);
	      assertEquals("Il titolo non rispetta il formato richiesto.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	
	@Test
	void tc_03() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo")).sendKeys("Palm Springs Vivi come se non ci fosse un domani");
	      browser.findElement(By.id("ImgCopertina")).sendKeys("https://magazinepragma.com/wp-content/uploads/2020/11/palmspringsssssssssssssssssssswefu2hr4iu2thewknfwlekniewjmfqowp3fjeof43ijt539tu856580uy5ijoglqgjhribioervirnbietjhiothiuhbeojgoirjgiijtkfegvmkmvkfotnbhotuhgoiqwiekdowqkdpoewjfoirhg3g5hg0924fjelwpifjio5hgoughoiwjfoqwkd�ofhoiewwwwwwwwwwwwwfhhhhhhhhhhhhhhhhhhuerighiehgiurhegeuh�itgAeghuiaherughuihetighiuhjksVNkdndsmnv,dmvnmnvlknsfjvnkjebuerbgoiwrhokdfmkdmclkdavnkjnvjnbdfurngvoirwhfl  wiojdmsmwklmelkvndbn kjfdnbjunhutughioerujgipjrpvmdksmvsbnjkfbfgijerughnwiojfoewkdfedlwkgirjgiornbkfbnlsfnbkjsfnbfibnroeijgopewjgiorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughioorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohhregowkgnegkqopfjirhgoigswwwwwwwwwwwwwfhhhhhhhhhhhhhhhhhhuerighiehgiurhegeuh�itgAeghuiaherughuihetighiuhjksVNkdndsmnv,dmvnmnvlknsfjvnkjebuerbgoiwrhokdfmkdmclkdavnkjnvjnbdfurngvoirwhfl  wiojdmsmwklmelkvndbn kjfdnbjunhutughioerujgipjrpvmdksmvsbnjkfbfgijerughnwiojfoewkdfedlwkgirjgiornbkfbnlsfnbkjsfnbfibnroeijgopewjgiorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughioorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksd.jpg");
	      browser.findElement(By.id("Trailer")).sendKeys("https://www.youtube.com/embed/jblwJhOhUQk");
	      browser.findElement(By.id("AnnoDiProduzione")).sendKeys("2020");
	      browser.findElement(By.id("Durata")).sendKeys("1.00");
	      browser.findElement(By.id("Genere1")).sendKeys("Fantasy");
	      browser.findElement(By.id("Cast")).sendKeys("Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O�Malley, Clifford V. Johnson.");
	      browser.findElement(By.id("Sinossi")).sendKeys("Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra.");
	      browser.findElement(By.id("Regista")).sendKeys("Max Barbakow");
	      browser.findElement(By.id("Valutazione")).sendKeys("1.3");
	      browser.findElement(By.id("submitFilm")).click();	
	      Thread.sleep(1100);
	      assertEquals("L'immagine di copertina non rispetta la lunghezza richiesta.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	
	@Test
	void tc_04() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo")).sendKeys("Palm Springs Vivi come se non ci fosse un domani");
	      browser.findElement(By.id("ImgCopertina")).sendKeys("magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
	      browser.findElement(By.id("Trailer")).sendKeys("https://www.youtube.com/embed/jblwJhOhUQk");
	      browser.findElement(By.id("AnnoDiProduzione")).sendKeys("2020");
	      browser.findElement(By.id("Durata")).sendKeys("1.00");
	      browser.findElement(By.id("Genere1")).sendKeys("Fantasy");
	      browser.findElement(By.id("Cast")).sendKeys("Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O'Malley, Clifford V. Johnson.");
	      browser.findElement(By.id("Sinossi")).sendKeys("Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra.");
	      browser.findElement(By.id("Regista")).sendKeys("Max Barbakow");
	      browser.findElement(By.id("Valutazione")).sendKeys("1.3");
	      browser.findElement(By.id("submitFilm")).click();	
	      Thread.sleep(1100);
	      assertEquals("L'immagine di copertina non rispetta il formato richiesto.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	
	@Test
	void tc_05() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo")).sendKeys("Palm Springs Vivi come se non ci fosse un domani");
	      browser.findElement(By.id("ImgCopertina")).sendKeys("https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
	      browser.findElement(By.id("Trailer")).sendKeys("https://www.youtube.com/watch?v=jblwJhOhUfjhwpalmspringsssssssssssssssssssswefu2hr4iu2thewknfwlekniewjmfqowp3fjeof43ijt539tu856580uy5ijoglqgjhribioervirnbietjhiothiuhbeojgoirjgiijtkfegvmkmvkfotnbhotuhgoiqwiekdowqkdpoewjfoirhg3g5hg0924fjelwpifjio5hgoughoiwjfoqwkd�ofhoiewwwwwwwwwwwwwfhhhhhhhhhhhhhhhhhhuerighiehgiurhegeuh�itgAeghuiaherughuihetighiuhjksVNkdndsmnv,dmvnmnvlknsfjvnkjebuerbgoiwrhokdfmkdmclkdavnkjnvjnbdfurngvoirwhflwiojdmsmwklmelkvndbnkjfdnbjunhutughioerujgipjrpvmdksmvsbnjkfbfgijerughnwiojfoewkdfedlwkgirjgiornbkfbnlsfnbkjsfnbfibnroeijgopewjgiorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughioorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohhregowkgnegkqopfjirhgoigifuhwoieghowigQkuhjksVNkdndsmnv,dmvnmnvlknsfjvnkjebuerbgoiwrhokdfmkdmclkdavnkjnvjnbdfurngvoirwhflwiojdmsmwklmelkvndbnkjfdnbjunhutughioerujgipjrpvmdksmvsbnjkfbfgijerughnwiojfoewkdfedlwkgirjgiornbkfbnlsfnbkjsfnbfibnroeijgopewjgiorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughioorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndjtungioerughiohorjgovmlsbnlsdnblakdmvlwrvmjirugjiojernglknvblsdknblksdbkndj");
	      browser.findElement(By.id("AnnoDiProduzione")).sendKeys("2020");
	      browser.findElement(By.id("Durata")).sendKeys("1.00");
	      browser.findElement(By.id("Genere1")).sendKeys("Fantasy");
	      browser.findElement(By.id("Cast")).sendKeys("Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O'Malley, Clifford V. Johnson.");
	      browser.findElement(By.id("Sinossi")).sendKeys("Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra.");
	      browser.findElement(By.id("Regista")).sendKeys("Max Barbakow");
	      browser.findElement(By.id("Valutazione")).sendKeys("1.3");
	      browser.findElement(By.id("submitFilm")).click();	
	      Thread.sleep(1100);
	      assertEquals("Il trailer non rispetta la lunghezza richiesta.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	
	@Test
	void tc_06() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo")).sendKeys("Palm Springs Vivi come se non ci fosse un domani");
	      browser.findElement(By.id("ImgCopertina")).sendKeys("https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
	      browser.findElement(By.id("Trailer")).sendKeys("youtube.com/watch?v=jblwJhOhUQk");
	      browser.findElement(By.id("AnnoDiProduzione")).sendKeys("2020");
	      browser.findElement(By.id("Durata")).sendKeys("1.00");
	      browser.findElement(By.id("Genere1")).sendKeys("Fantasy");
	      browser.findElement(By.id("Cast")).sendKeys("Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O'Malley, Clifford V. Johnson.");
	      browser.findElement(By.id("Sinossi")).sendKeys("Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra.");
	      browser.findElement(By.id("Regista")).sendKeys("Max Barbakow");
	      browser.findElement(By.id("Valutazione")).sendKeys("1.3");
	      browser.findElement(By.id("submitFilm")).click();	
	      Thread.sleep(1100);
	      assertEquals("Il trailer non rispetta il formato richiesto.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	
	@Test
	void tc_07() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo")).sendKeys("Palm Springs Vivi come se non ci fosse un domani");
	      browser.findElement(By.id("ImgCopertina")).sendKeys("https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
	      browser.findElement(By.id("Trailer")).sendKeys("https://www.youtube.com/embed/jblwJhOhUQk");
	      browser.findElement(By.id("AnnoDiProduzione")).sendKeys("2020");
	      browser.findElement(By.id("Durata")).sendKeys("1.00");
	      browser.findElement(By.id("Genere1")).sendKeys("Fantasy");
	      browser.findElement(By.id("Cast")).sendKeys("Andy Samberg nei panni di Nyles, Cristin Milioti nei panni di Sarah Wilder, Peter Gallagher nei panni di Howard Wilder, J. K. Simmons nei panni di Roy, Meredith Hagner nei panni di Misty, Camila Mendes nei panni di Tala Anne Wilder, Tyler Hoechlin nei panni di Abraham Eugene Trent �Abe� Schlieffen, Chris Pang nei panni di Trevor, Jacqueline Obradors nei panni di Pia Wilder, June Squibb nei panni di Nana Schlieffen, Jena Friedman nei panni di Daisy, Tongayi Chirisa nei panni di Jerry, Dale Dickey nei panni di Darla, Conner O�Malley nei panni di Randy, Clifford V. Johnson nei panni del professore");
	      browser.findElement(By.id("Sinossi")).sendKeys("Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra.");
	      browser.findElement(By.id("Regista")).sendKeys("Max Barbakow");
	      browser.findElement(By.id("Valutazione")).sendKeys("1.3");
	      browser.findElement(By.id("submitFilm")).click();	
	      Thread.sleep(1100);
	      assertEquals("Il cast non rispetta la lunghezza richiesta.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	
	@Test
	void tc_08() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo")).sendKeys("Palm Springs Vivi come se non ci fosse un domani");
	      browser.findElement(By.id("ImgCopertina")).sendKeys("https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
	      browser.findElement(By.id("Trailer")).sendKeys("https://www.youtube.com/embed/jblwJhOhUQk");
	      browser.findElement(By.id("AnnoDiProduzione")).sendKeys("2020");
	      browser.findElement(By.id("Durata")).sendKeys("1.00");
	      browser.findElement(By.id("Genere1")).sendKeys("Fantasy");
	      browser.findElement(By.id("Cast")).sendKeys("Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O�Malley, Clifford V. Johnson!");
	      browser.findElement(By.id("Sinossi")).sendKeys("Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra.");
	      browser.findElement(By.id("Regista")).sendKeys("Max Barbakow");
	      browser.findElement(By.id("Valutazione")).sendKeys("1.3");
	      browser.findElement(By.id("submitFilm")).click();	
	      Thread.sleep(1100);
	      assertEquals("Il cast non rispetta il formato richiesto.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	
	@Test
	void tc_09() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo")).sendKeys("Palm Springs Vivi come se non ci fosse un domani");
	      browser.findElement(By.id("ImgCopertina")).sendKeys("https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
	      browser.findElement(By.id("Trailer")).sendKeys("https://www.youtube.com/embed/jblwJhOhUQk");
	      browser.findElement(By.id("AnnoDiProduzione")).sendKeys("2020");
	      browser.findElement(By.id("Durata")).sendKeys("1.00");
	      browser.findElement(By.id("Genere1")).sendKeys("Fantasy");
	      browser.findElement(By.id("Cast")).sendKeys("Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O'Malley, Clifford V. Johnson.");
	      browser.findElement(By.id("Sinossi")).sendKeys("La mattina del 9 novembre, per Nyles, inizia svegliandosi di fianco alla fidanzata Misty, con la prospettiva di una giornata da trascorrere tra piscina e celebrazioni in un resort nel deserto di Palm Springs. La coppia � l� per partecipare al matrimonio tra Abe e Tala, un'amica di Misty. Un momento speciale che per� Nyles sembra trattare con fin troppa svagatezza, brindando agli sposi in camicia hawaiana e salvando Sarah, sorella di Tala, da un discorso pubblico che la ragazza non vuole fare. Scappati insieme verso il deserto, Sarah vedr� Nyles trascinato in una grotta misteriosa, che ormai da tempo immemore lo costringe a rivivere la giornata del matrimonio senza soluzione di continuit�.");
	      browser.findElement(By.id("Regista")).sendKeys("Max Barbakow");
	      browser.findElement(By.id("Valutazione")).sendKeys("1.3");
	      browser.findElement(By.id("submitFilm")).click();	
	      Thread.sleep(1100);
	      assertEquals("La sinossi non rispetta la lunghezza richiesta.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	
	@Test
	void tc_10() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo")).sendKeys("Palm Springs Vivi come se non ci fosse un domani");
	      browser.findElement(By.id("ImgCopertina")).sendKeys("https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
	      browser.findElement(By.id("Trailer")).sendKeys("https://www.youtube.com/embed/jblwJhOhUQk");
	      browser.findElement(By.id("AnnoDiProduzione")).sendKeys("2020");
	      browser.findElement(By.id("Durata")).sendKeys("1.00");
	      browser.findElement(By.id("Genere1")).sendKeys("Fantasy");
	      browser.findElement(By.id("Cast")).sendKeys("Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O'Malley, Clifford V. Johnson.");
	      browser.findElement(By.id("Sinossi")).sendKeys("Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm_Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra!!!");
	      browser.findElement(By.id("Regista")).sendKeys("Max Barbakow");
	      browser.findElement(By.id("Valutazione")).sendKeys("1.3");
	      browser.findElement(By.id("submitFilm")).click();	
	      Thread.sleep(1100);
	      assertEquals("La sinossi non rispetta il formato richiesto.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	
	@Test
	void tc_11() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo")).sendKeys("Palm Springs Vivi come se non ci fosse un domani");
	      browser.findElement(By.id("ImgCopertina")).sendKeys("https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
	      browser.findElement(By.id("Trailer")).sendKeys("https://www.youtube.com/embed/jblwJhOhUQk");
	      browser.findElement(By.id("AnnoDiProduzione")).sendKeys("20200");
	      browser.findElement(By.id("Durata")).sendKeys("1.00");
	      browser.findElement(By.id("Genere1")).sendKeys("Fantasy");
	      browser.findElement(By.id("Cast")).sendKeys("Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O'Malley, Clifford V. Johnson.");
	      browser.findElement(By.id("Sinossi")).sendKeys("Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra");
	      browser.findElement(By.id("Regista")).sendKeys("Max Barbakow");
	      browser.findElement(By.id("Valutazione")).sendKeys("1.3");
	      browser.findElement(By.id("submitFilm")).click();	
	      Thread.sleep(1100);
	      assertEquals("L'anno di produzione non rispetta la lunghezza richiesta.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_12() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo")).sendKeys("Palm Springs Vivi come se non ci fosse un domani");
	      browser.findElement(By.id("ImgCopertina")).sendKeys("https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
	      browser.findElement(By.id("Trailer")).sendKeys("https://www.youtube.com/embed/jblwJhOhUQk");
	      browser.findElement(By.id("AnnoDiProduzione")).sendKeys("202o");
	      browser.findElement(By.id("Durata")).sendKeys("1.00");
	      browser.findElement(By.id("Genere1")).sendKeys("Fantasy");
	      browser.findElement(By.id("Cast")).sendKeys("Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O'Malley, Clifford V. Johnson.");
	      browser.findElement(By.id("Sinossi")).sendKeys("Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra");
	      browser.findElement(By.id("Regista")).sendKeys("Max Barbakow");
	      browser.findElement(By.id("Valutazione")).sendKeys("1.3");
	      browser.findElement(By.id("submitFilm")).click();	
	      Thread.sleep(1100);
	      assertEquals("L'anno di produzione non rispetta il formato richiesto.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_13() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo")).sendKeys("Palm Springs Vivi come se non ci fosse un domani");
	      browser.findElement(By.id("ImgCopertina")).sendKeys("https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
	      browser.findElement(By.id("Trailer")).sendKeys("https://www.youtube.com/embed/jblwJhOhUQk");
	      browser.findElement(By.id("AnnoDiProduzione")).sendKeys("2020");
	      browser.findElement(By.id("Durata")).sendKeys("1000.00");
	      browser.findElement(By.id("Genere1")).sendKeys("Fantasy");
	      browser.findElement(By.id("Cast")).sendKeys("Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O'Malley, Clifford V. Johnson.");
	      browser.findElement(By.id("Sinossi")).sendKeys("Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra");
	      browser.findElement(By.id("Regista")).sendKeys("Max Barbakow");
	      browser.findElement(By.id("Valutazione")).sendKeys("1.3");
	      browser.findElement(By.id("submitFilm")).click();	
	      Thread.sleep(1100);
	      assertEquals("La durata non rispetta la lunghezza richiesta.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_14() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo")).sendKeys("Palm Springs Vivi come se non ci fosse un domani");
	      browser.findElement(By.id("ImgCopertina")).sendKeys("https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
	      browser.findElement(By.id("Trailer")).sendKeys("https://www.youtube.com/embed/jblwJhOhUQk");
	      browser.findElement(By.id("AnnoDiProduzione")).sendKeys("2020");
	      browser.findElement(By.id("Durata")).sendKeys("Ora");
	      browser.findElement(By.id("Genere1")).sendKeys("Fantasy");
	      browser.findElement(By.id("Cast")).sendKeys("Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O'Malley, Clifford V. Johnson.");
	      browser.findElement(By.id("Sinossi")).sendKeys("Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra");
	      browser.findElement(By.id("Regista")).sendKeys("Max Barbakow");
	      browser.findElement(By.id("Valutazione")).sendKeys("1.3");
	      browser.findElement(By.id("submitFilm")).click();	
	      Thread.sleep(1100);
	      assertEquals("La durata non rispetta il formato richiesto.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_15() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo")).sendKeys("Palm Springs Vivi come se non ci fosse un domani");
	      browser.findElement(By.id("ImgCopertina")).sendKeys("https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
	      browser.findElement(By.id("Trailer")).sendKeys("https://www.youtube.com/embed/jblwJhOhUQk");
	      browser.findElement(By.id("AnnoDiProduzione")).sendKeys("2020");
	      browser.findElement(By.id("Durata")).sendKeys("1.00");
	      browser.findElement(By.id("Genere1")).sendKeys("Fantasy");
	      browser.findElement(By.id("Cast")).sendKeys("Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O'Malley, Clifford V. Johnson.");
	      browser.findElement(By.id("Sinossi")).sendKeys("Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra");
	      browser.findElement(By.id("Regista")).sendKeys("Max Barbakow � un regista e scrittore di Los Angeles in California. Max ha conseguito il suo MFA in regia presso il Conservatorio AFI.");
	      browser.findElement(By.id("Valutazione")).sendKeys("1.3");
	      browser.findElement(By.id("submitFilm")).click();	
	      Thread.sleep(1100);
	      assertEquals("Il regista non rispetta la lunghezza richiesta.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_16() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo")).sendKeys("Palm Springs Vivi come se non ci fosse un domani");
	      browser.findElement(By.id("ImgCopertina")).sendKeys("https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
	      browser.findElement(By.id("Trailer")).sendKeys("https://www.youtube.com/embed/jblwJhOhUQk");
	      browser.findElement(By.id("AnnoDiProduzione")).sendKeys("2020");
	      browser.findElement(By.id("Durata")).sendKeys("1.00");
	      browser.findElement(By.id("Genere1")).sendKeys("Fantasy");
	      browser.findElement(By.id("Cast")).sendKeys("Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O'Malley, Clifford V. Johnson.");
	      browser.findElement(By.id("Sinossi")).sendKeys("Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra");
	      browser.findElement(By.id("Regista")).sendKeys("Max_Barbakow");
	      browser.findElement(By.id("Valutazione")).sendKeys("1.3");
	      browser.findElement(By.id("submitFilm")).click();	
	      Thread.sleep(1100);
	      assertEquals("Il regista non rispetta il formato richiesto.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	
	@Test
	void tc_17() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo")).sendKeys("Palm Springs Vivi come se non ci fosse un domani");
	      browser.findElement(By.id("ImgCopertina")).sendKeys("https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
	      browser.findElement(By.id("Trailer")).sendKeys("https://www.youtube.com/embed/jblwJhOhUQk");
	      browser.findElement(By.id("AnnoDiProduzione")).sendKeys("2020");
	      browser.findElement(By.id("Durata")).sendKeys("1.00");
	      browser.findElement(By.id("Genere1")).sendKeys("");
	      browser.findElement(By.id("Cast")).sendKeys("Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O'Malley, Clifford V. Johnson.");
	      browser.findElement(By.id("Sinossi")).sendKeys("Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra");
	      browser.findElement(By.id("Regista")).sendKeys("Max Barbakow");
	      browser.findElement(By.id("Valutazione")).sendKeys("1.3");
	      browser.findElement(By.id("submitFilm")).click();	
	      Thread.sleep(1100);
	      assertEquals("Il genere non � stato selezionato.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_18() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo")).sendKeys("Palm Springs Vivi come se non ci fosse un domani");
	      browser.findElement(By.id("ImgCopertina")).sendKeys("https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
	      browser.findElement(By.id("Trailer")).sendKeys("https://www.youtube.com/embed/jblwJhOhUQk");
	      browser.findElement(By.id("AnnoDiProduzione")).sendKeys("2020");
	      browser.findElement(By.id("Durata")).sendKeys("1.00");
	      browser.findElement(By.id("Genere1")).sendKeys("Fantasy");
	      browser.findElement(By.id("Cast")).sendKeys("Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O'Malley, Clifford V. Johnson.");
	      browser.findElement(By.id("Sinossi")).sendKeys("Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra");
	      browser.findElement(By.id("Regista")).sendKeys("Max Barbakow");
	      browser.findElement(By.id("Valutazione")).sendKeys("5000.00");
	      browser.findElement(By.id("submitFilm")).click();	
	      Thread.sleep(1100);
	      assertEquals("Le valutazioni non rispettano la lunghezza richiesta.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_19() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo")).sendKeys("Palm Springs Vivi come se non ci fosse un domani");
	      browser.findElement(By.id("ImgCopertina")).sendKeys("https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
	      browser.findElement(By.id("Trailer")).sendKeys("https://www.youtube.com/embed/jblwJhOhUQk");
	      browser.findElement(By.id("AnnoDiProduzione")).sendKeys("2020");
	      browser.findElement(By.id("Durata")).sendKeys("1.00");
	      browser.findElement(By.id("Genere1")).sendKeys("Fantasy");
	      browser.findElement(By.id("Cast")).sendKeys("Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O'Malley, Clifford V. Johnson.");
	      browser.findElement(By.id("Sinossi")).sendKeys("Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra");
	      browser.findElement(By.id("Regista")).sendKeys("Max Barbakow");
	      browser.findElement(By.id("Valutazione")).sendKeys("6.0");
	      browser.findElement(By.id("submitFilm")).click();	
	      Thread.sleep(1100);
	      assertEquals("Le valutazioni non rispettano il formato richiesto.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_20() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo")).sendKeys("Palm Springs Vivi come se non ci fosse un domani");
	      browser.findElement(By.id("ImgCopertina")).sendKeys("https://magazinepragma.com/wp-content/uploads/2020/11/palm-springs.jpg");
	      browser.findElement(By.id("Trailer")).sendKeys("https://www.youtube.com/embed/jblwJhOhUQk");
	      browser.findElement(By.id("AnnoDiProduzione")).sendKeys("2020");
	      browser.findElement(By.id("Durata")).sendKeys("1.00");
	      browser.findElement(By.id("Genere1")).sendKeys("Fantasy");
	      browser.findElement(By.id("Cast")).sendKeys("Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O'Malley, Clifford V. Johnson.");
	      browser.findElement(By.id("Sinossi")).sendKeys("Lo spensierato Nyles e la riluttante damigella d'onore Sarah si incontrano per caso a un matrimonio a Palm Springs. Per entrambi le cose si complicano quando la mattina successiva non riescono in alcun modo ad andare via dal posto o a allontanarsi l'uno dall'altra");
	      browser.findElement(By.id("Regista")).sendKeys("Max Barbakow");
	      browser.findElement(By.id("Valutazione")).sendKeys("1.3");
	      browser.findElement(By.id("submitFilm")).click();	
	      Thread.sleep(1100);
	      assertEquals("Aggiunta avvenuta con successo.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
}
