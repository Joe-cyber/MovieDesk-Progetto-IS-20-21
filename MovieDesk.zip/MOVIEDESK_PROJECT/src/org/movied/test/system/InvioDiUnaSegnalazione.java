package org.movied.test.system;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

class InvioDiUnaSegnalazione {

	private WebDriver browser;
	private String url="http://127.0.0.1/MOVIEDESK_PROJECT/Report";
	@BeforeEach
	void initSession() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\calie\\OneDrive\\Desktop\\chromedriver.exe");
		browser = new ChromeDriver();
	    browser.get(url);
	    browser.findElement(By.id("email2")).sendKeys("ustandard@mail.com");
	    browser.findElement(By.id("password2")).sendKeys("UtenteStandard01");
	    browser.findElement(By.id("submitform")).click();		
	}
	
	@Test
	void tc_01() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("object")).sendKeys("Piattaforma mancante per il film Venom");
	      browser.findElement(By.id("message")).sendKeys("Venom � presente anche su Infinity");
	      browser.findElement(By.id("sendSubmit")).click();	
	      Thread.sleep(1100);
	      assertEquals("L'oggetto della segnalazione non rispetta la lunghezza richiesta.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	
	@Test
	void tc_02() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("object")).sendKeys("Piattaforma_mancante");
	      browser.findElement(By.id("message")).sendKeys("Venom � presente anche su Infinity");
	      browser.findElement(By.id("sendSubmit")).click();	
	      Thread.sleep(1100);
	      assertEquals("L'oggetto della segnalazione non rispetta il formato richiesto.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	
	@Test
	void tc_03() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("object")).sendKeys("Piattaforma mancante");
	      browser.findElement(By.id("message")).sendKeys("Venom � presente anche sulla piattaforma di streaming di nome Infinity");
	      browser.findElement(By.id("sendSubmit")).click();	
	      Thread.sleep(1100);
	      assertEquals("Il messaggio della segnalazione non rispetta la lunghezza richiesta.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	
	@Test
	void tc_04() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("object")).sendKeys("Piattaforma mancante");
	      browser.findElement(By.id("message")).sendKeys("Venom � presente anche su Infinity!!!");
	      browser.findElement(By.id("sendSubmit")).click();	
	      Thread.sleep(1100);
	      assertEquals("Il messaggio della segnalazione non rispetta il formato richiesto.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	
	@Test
	void tc_05() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("object")).sendKeys("Piattaforma mancante");
	      browser.findElement(By.id("message")).sendKeys("Venom � presente anche su Infinity");
	      browser.findElement(By.id("sendSubmit")).click();	
	      Thread.sleep(1100);
	      assertEquals("Segnalazione inviata con successo.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
}
