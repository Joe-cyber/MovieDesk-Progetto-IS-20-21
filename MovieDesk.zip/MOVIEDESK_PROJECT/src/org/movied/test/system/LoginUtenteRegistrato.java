package org.movied.test.system;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

class LoginUtenteRegistrato {

	private WebDriver browser;
	private String url="http://127.0.0.1/MOVIEDESK_PROJECT/PersonalArea";
	@Test
	void tc_01() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\calie\\OneDrive\\Desktop\\chromedriver.exe");
		browser = new ChromeDriver();
	    browser.get(url);
	    browser.findElement(By.id("email2")).sendKeys("jwrogniwnrigjwrogniwnrigjwrogniwnrigjwrogniwnrigjwrogniwnrigjwrogniwnrigjwrogniwnrigjwrogniwnrigjwrogniwnrigjwrogniwnrigjwrogniwnrigjwrogniwnrigjwrogniwnrigjwrogniwnrigjwrogniwnrigjwrogniwnrigjwrogniwnrigjwrogniwnrigjwrogni@gmail.com");
	    browser.findElement(By.id("password2")).sendKeys("UnaPassword1");
	    browser.findElement(By.id("submitform")).click();		
	    assertEquals("L'email non rispetta la lunghezza richiesta.",browser.findElement(By.id("message")).getText());
	    browser.close();
	}
	@Test
	void tc_02() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\calie\\OneDrive\\Desktop\\chromedriver.exe");
		browser = new ChromeDriver();
	    browser.get(url);
	    browser.findElement(By.id("email2")).sendKeys("paololipizzi?@mail.com");
	    browser.findElement(By.id("password2")).sendKeys("UnaPassword1");
	    browser.findElement(By.id("submitform")).click();		
	    assertEquals("L'email non rispetta il formato richiesto.",browser.findElement(By.id("message")).getText());
	    browser.close();
	}
	@Test
	void tc_03() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\calie\\OneDrive\\Desktop\\chromedriver.exe");
		browser = new ChromeDriver();
	    browser.get(url);
	    browser.findElement(By.id("email2")).sendKeys("paololipizzi@gmail.com");
	    browser.findElement(By.id("password2")).sendKeys("UnaPassword1");
	    browser.findElement(By.id("submitform")).click();		
	    assertEquals("Email o password errati.",browser.findElement(By.id("message")).getText());
	    browser.close();
	}
	@Test
	void tc_04() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\calie\\OneDrive\\Desktop\\chromedriver.exe");
		browser = new ChromeDriver();
	    browser.get(url);
	    browser.findElement(By.id("email2")).sendKeys("paololipizzi@gmail.com");
	    browser.findElement(By.id("password2")).sendKeys("1234567891011121314151617181920212223");
	    browser.findElement(By.id("submitform")).click();		
	    assertEquals("La password non rispetta la lunghezza richiesta.",browser.findElement(By.id("message")).getText());
	    browser.close();
	}
	@Test
	void tc_05() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\calie\\OneDrive\\Desktop\\chromedriver.exe");
		browser = new ChromeDriver();
	    browser.get(url);
	    browser.findElement(By.id("email2")).sendKeys("paololipizzi@gmail.com");
	    browser.findElement(By.id("password2")).sendKeys("Pass*_++");
	    browser.findElement(By.id("submitform")).click();		
	    assertEquals("La password non rispetta il formato richiesto.",browser.findElement(By.id("message")).getText());
	    browser.close();
	}
	@Test
	void tc_06() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\calie\\OneDrive\\Desktop\\chromedriver.exe");
		browser = new ChromeDriver();
	    browser.get(url);
	    browser.findElement(By.id("email2")).sendKeys("mmanager@mail.com");
	    browser.findElement(By.id("password2")).sendKeys("UnaPassword1");
	    browser.findElement(By.id("submitform")).click();		
	    assertEquals("Email o password errati.",browser.findElement(By.id("message")).getText());
	    browser.close();
	}
	@Test
	void tc_07() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\calie\\OneDrive\\Desktop\\chromedriver.exe");
		browser = new ChromeDriver();
	    browser.get(url);
	    browser.findElement(By.id("email2")).sendKeys("mmanager@mail.com");
	    browser.findElement(By.id("password2")).sendKeys("UtenteStandard01");
	    browser.findElement(By.id("submitform")).click();		
	    assertEquals("Email o password errati.",browser.findElement(By.id("message")).getText());
	    browser.close();
	}
	
	@Test
	void tc_08() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\calie\\OneDrive\\Desktop\\chromedriver.exe");
		browser = new ChromeDriver();
	    browser.get(url);
	    browser.findElement(By.id("email2")).sendKeys("mmanager@mail.com");
	    browser.findElement(By.id("password2")).sendKeys("MediaManager01");
	    browser.findElement(By.id("submitform")).click();		
	    assertEquals("http://127.0.0.1/MOVIEDESK_PROJECT/PersonalArea",browser.getCurrentUrl());
	    browser.close();
	}
}
