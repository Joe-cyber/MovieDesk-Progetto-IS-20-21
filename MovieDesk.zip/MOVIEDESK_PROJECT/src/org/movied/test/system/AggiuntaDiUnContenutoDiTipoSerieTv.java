package org.movied.test.system;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

class AggiuntaDiUnContenutoDiTipoSerieTv {

	private WebDriver browser;
	private String url="http://127.0.0.1/MOVIEDESK_PROJECT/PersonalArea#p-view-6#collapseSeven";
	@BeforeEach
	void initSession() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\calie\\OneDrive\\Desktop\\chromedriver.exe");
		browser = new ChromeDriver();
	    browser.get(url);
	    browser.findElement(By.id("email2")).sendKeys("mmanager@mail.com");
	    browser.findElement(By.id("password2")).sendKeys("MediaManager01");
	    browser.findElement(By.id("submitform")).click();		
	    browser.findElement(By.id("add")).click();	
	    browser.findElement(By.id("addSerie")).click();	
	}
	
	@Test
	void tc_01() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo2")).sendKeys("High School Musical The Musical The Series The Sing Along");
	      browser.findElement(By.id("ImgCopertina2")).sendKeys("https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
	      browser.findElement(By.id("Trailer2")).sendKeys("https://www.youtube.com/embed/RlaV8sJGhfc");
	      browser.findElement(By.id("AnnoDiProduzione2")).sendKeys("2020");
	      browser.findElement(By.id("Stagioni")).sendKeys("1");
	      browser.findElement(By.id("Puntate")).sendKeys("10");
	      browser.findElement(By.id("genere1")).sendKeys("Drammatico");
	      browser.findElement(By.id("Cast2")).sendKeys("Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O�Malley, Clifford V. Johnson.");
	      browser.findElement(By.id("Sinossi2")).sendKeys("In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale.");
	      browser.findElement(By.id("DurataEp")).sendKeys("0.28");
	      browser.findElement(By.id("Valutazione2")).sendKeys("5.0");
	      browser.findElement(By.id("submitSerie")).click();	
	      Thread.sleep(1100);
	      assertEquals("Il titolo non rispetta la lunghezza richiesta.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	
	@Test
	void tc_02() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo2")).sendKeys("High School Musical The Series The Sing Along!");
	      browser.findElement(By.id("ImgCopertina2")).sendKeys("https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
	      browser.findElement(By.id("Trailer2")).sendKeys("https://www.youtube.com/embed/RlaV8sJGhfc");
	      browser.findElement(By.id("AnnoDiProduzione2")).sendKeys("2020");
	      browser.findElement(By.id("Stagioni")).sendKeys("1");
	      browser.findElement(By.id("Puntate")).sendKeys("10");
	      browser.findElement(By.id("genere1")).sendKeys("Drammatico");
	      browser.findElement(By.id("Cast2")).sendKeys("Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O�Malley, Clifford V. Johnson.");
	      browser.findElement(By.id("Sinossi2")).sendKeys("In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale.");
	      browser.findElement(By.id("DurataEp")).sendKeys("0.28");
	      browser.findElement(By.id("Valutazione2")).sendKeys("5.0");
	      browser.findElement(By.id("submitSerie")).click();	
	      Thread.sleep(1100);
	      assertEquals("Il titolo non rispetta il formato richiesto.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	
	@Test
	void tc_03() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo2")).sendKeys("High School Musical The Series The Sing Along");
	      browser.findElement(By.id("ImgCopertina2")).sendKeys("https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoirh8C7345146ghowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiDC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoiC4E8348526199AB20CC6Cr�egjoitghoiehgioh�righowrhoirh8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
	      browser.findElement(By.id("Trailer2")).sendKeys("https://www.youtube.com/embed/RlaV8sJGhfc");
	      browser.findElement(By.id("AnnoDiProduzione2")).sendKeys("2020");
	      browser.findElement(By.id("Stagioni")).sendKeys("1");
	      browser.findElement(By.id("Puntate")).sendKeys("10");
	      browser.findElement(By.id("genere1")).sendKeys("Drammatico");
	      browser.findElement(By.id("Cast2")).sendKeys("Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O�Malley, Clifford V. Johnson.");
	      browser.findElement(By.id("Sinossi2")).sendKeys("In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale.");
	      browser.findElement(By.id("DurataEp")).sendKeys("0.28");
	      browser.findElement(By.id("Valutazione2")).sendKeys("5.0");
	      browser.findElement(By.id("submitSerie")).click();	
	      Thread.sleep(1100);
	      assertEquals("L'immagine di copertina non rispetta la lunghezza richiesta.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_04() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo2")).sendKeys("High School Musical The Series The Sing Along");
	      browser.findElement(By.id("ImgCopertina2")).sendKeys("delivery.disney-plus.net/v1/variant/disney/3017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
	      browser.findElement(By.id("Trailer2")).sendKeys("https://www.youtube.com/embed/RlaV8sJGhfc");
	      browser.findElement(By.id("AnnoDiProduzione2")).sendKeys("2020");
	      browser.findElement(By.id("Stagioni")).sendKeys("1");
	      browser.findElement(By.id("Puntate")).sendKeys("10");
	      browser.findElement(By.id("genere1")).sendKeys("Drammatico");
	      browser.findElement(By.id("Cast2")).sendKeys("Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O�Malley, Clifford V. Johnson.");
	      browser.findElement(By.id("Sinossi2")).sendKeys("In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale.");
	      browser.findElement(By.id("DurataEp")).sendKeys("0.28");
	      browser.findElement(By.id("Valutazione2")).sendKeys("5.0");
	      browser.findElement(By.id("submitSerie")).click();	
	      Thread.sleep(1100);
	      assertEquals("L'immagine di copertina non rispetta il formato richiesto.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_05() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo2")).sendKeys("High School Musical The Series The Sing Along");
	      browser.findElement(By.id("ImgCopertina2")).sendKeys("https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
	      browser.findElement(By.id("Trailer2")).sendKeys("://www.youtube.com/watch?v=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV://www.youtube.com/watch?v=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaVcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV8sJGhfcv=RlaV");
	      browser.findElement(By.id("AnnoDiProduzione2")).sendKeys("2020");
	      browser.findElement(By.id("Stagioni")).sendKeys("1");
	      browser.findElement(By.id("Puntate")).sendKeys("10");
	      browser.findElement(By.id("genere1")).sendKeys("Drammatico");
	      browser.findElement(By.id("Cast2")).sendKeys("Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O�Malley, Clifford V. Johnson.");
	      browser.findElement(By.id("Sinossi2")).sendKeys("In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale.");
	      browser.findElement(By.id("DurataEp")).sendKeys("0.28");
	      browser.findElement(By.id("Valutazione2")).sendKeys("5.0");
	      browser.findElement(By.id("submitSerie")).click();	
	      Thread.sleep(1100);
	      assertEquals("Il trailer non rispetta la lunghezza richiesta.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_06() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo2")).sendKeys("High School Musical The Series The Sing Along");
	      browser.findElement(By.id("ImgCopertina2")).sendKeys("https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
	      browser.findElement(By.id("Trailer2")).sendKeys("youtube.com/embed/RlaV8sJGhfc");
	      browser.findElement(By.id("AnnoDiProduzione2")).sendKeys("2020");
	      browser.findElement(By.id("Stagioni")).sendKeys("1");
	      browser.findElement(By.id("Puntate")).sendKeys("10");
	      browser.findElement(By.id("genere1")).sendKeys("Drammatico");
	      browser.findElement(By.id("Cast2")).sendKeys("Andy Samberg, Cristin Milioti, Peter Gallagher, J. K. Simmons, Meredith Hagner, Camila Mendes,Tyler Hoechlin, Chris Pang, Jacqueline Obradors, June Squibb, Jena Friedman, Tongayi Chirisa, Dale Dickey, Conner O�Malley, Clifford V. Johnson.");
	      browser.findElement(By.id("Sinossi2")).sendKeys("In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale.");
	      browser.findElement(By.id("DurataEp")).sendKeys("0.28");
	      browser.findElement(By.id("Valutazione2")).sendKeys("5.0");
	      browser.findElement(By.id("submitSerie")).click();	
	      Thread.sleep(1100);
	      assertEquals("Il trailer non rispetta il formato richiesto.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_07() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo2")).sendKeys("High School Musical The Series The Sing Along");
	      browser.findElement(By.id("ImgCopertina2")).sendKeys("https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
	      browser.findElement(By.id("Trailer2")).sendKeys("https://www.youtube.com/embed/RlaV8sJGhfc");
	      browser.findElement(By.id("AnnoDiProduzione2")).sendKeys("2020");
	      browser.findElement(By.id("Stagioni")).sendKeys("1");
	      browser.findElement(By.id("Puntate")).sendKeys("10");
	      browser.findElement(By.id("genere1")).sendKeys("Drammatico");
	      browser.findElement(By.id("Cast2")).sendKeys("Olivia Rodrigo nei panni di Nini Salazar-Roberts, un'appassionata di teatro musicale, che interpreta il ruolo di Gabriella Montez. Joshua Bassett nei panni di Ricky Bowen, un chitarrista e skateboarder che in precedenza ha frequentato Nini, che � stato scelto come Troy Bolton nonostante la sua iniziale mancanza di interesse per il musical.Matt Cornett nei panni di E.  J. Caswell, un atleta appassionato di teatro che Nini aveva gi� incontrato al campo di teatro, che � stato scelto per interpretare Chad Danforth e il sostituto di Troy.Sofia Wylie nel ruolo di Gina Porter, una studentessa trasferita con ambizioni teatrali, che interpreta Taylor McKessie e la sostituta di Gabriella.Larry Saperstein nei panni di Big Red, il migliore amico di Ricky, che sostituisce il direttore di scena per la produzione ogni volta che Natalie non � disponibile, nonostante la sua mancanza di conoscenza del teatro. Successivamente gli viene mostrato di possedere talenti nascosti nel tip tap e nella conoscenza dell'elettronica.Julia Lester nei panni di Ashlyn Caswell,  cugina di E. J. e aspirante cantautrice, che interpreta la signora Darbus..");
	      browser.findElement(By.id("Sinossi2")).sendKeys("In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale.");
	      browser.findElement(By.id("DurataEp")).sendKeys("0.28");
	      browser.findElement(By.id("Valutazione2")).sendKeys("5.0");
	      browser.findElement(By.id("submitSerie")).click();	
	      Thread.sleep(1100);
	      assertEquals("Il cast non rispetta la lunghezza richiesta.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_08() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo2")).sendKeys("High School Musical The Series The Sing Along");
	      browser.findElement(By.id("ImgCopertina2")).sendKeys("https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
	      browser.findElement(By.id("Trailer2")).sendKeys("https://www.youtube.com/embed/RlaV8sJGhfc");
	      browser.findElement(By.id("AnnoDiProduzione2")).sendKeys("2020");
	      browser.findElement(By.id("Stagioni")).sendKeys("1");
	      browser.findElement(By.id("Puntate")).sendKeys("10");
	      browser.findElement(By.id("genere1")).sendKeys("Drammatico");
	      browser.findElement(By.id("Cast2")).sendKeys("Olivia Rodrigo-Joshua Basset-Matt Cornett-Sofia Wylie-Julia Lester-Larry Saperstein-Frankie Rodriguez-Dara Rene�-Mark St. Cyr-Kate Reinders");
	      browser.findElement(By.id("Sinossi2")).sendKeys("In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale.");
	      browser.findElement(By.id("DurataEp")).sendKeys("0.28");
	      browser.findElement(By.id("Valutazione2")).sendKeys("5.0");
	      browser.findElement(By.id("submitSerie")).click();	
	      Thread.sleep(1100);
	      assertEquals("Il cast non rispetta il formato richiesto.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_09() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo2")).sendKeys("High School Musical The Series The Sing Along");
	      browser.findElement(By.id("ImgCopertina2")).sendKeys("https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
	      browser.findElement(By.id("Trailer2")).sendKeys("https://www.youtube.com/embed/RlaV8sJGhfc");
	      browser.findElement(By.id("AnnoDiProduzione2")).sendKeys("2020");
	      browser.findElement(By.id("Stagioni")).sendKeys("1");
	      browser.findElement(By.id("Puntate")).sendKeys("10");
	      browser.findElement(By.id("genere1")).sendKeys("Drammatico");
	      browser.findElement(By.id("Cast2")).sendKeys("Olivia Rodrigo, Joshua Basset-Matt Cornett, Sofia Wylie,Julia Lester,Larry Saperstein,Frankie Rodriguez.");
	      browser.findElement(By.id("Sinossi2")).sendKeys("La notte di capodanno, due ragazzi, Troy e Gabriella, si incontrano ad una festa. Entrambi vengono scelti per cantare un duetto al karaoke (Start of Something New). Terminata l'esibizione, i due si scambiano i numeri di telefono. In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale.");
	      browser.findElement(By.id("DurataEp")).sendKeys("0.28");
	      browser.findElement(By.id("Valutazione2")).sendKeys("5.0");
	      browser.findElement(By.id("submitSerie")).click();	
	      Thread.sleep(1100);
	      assertEquals("La sinossi non rispetta la lunghezza richiesta.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_10() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo2")).sendKeys("High School Musical The Series The Sing Along");
	      browser.findElement(By.id("ImgCopertina2")).sendKeys("https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
	      browser.findElement(By.id("Trailer2")).sendKeys("https://www.youtube.com/embed/RlaV8sJGhfc");
	      browser.findElement(By.id("AnnoDiProduzione2")).sendKeys("2020");
	      browser.findElement(By.id("Stagioni")).sendKeys("1");
	      browser.findElement(By.id("Puntate")).sendKeys("10");
	      browser.findElement(By.id("genere1")).sendKeys("Drammatico");
	      browser.findElement(By.id("Cast2")).sendKeys("Olivia Rodrigo, Joshua Basset-Matt Cornett, Sofia Wylie,Julia Lester,Larry Saperstein,Frankie Rodriguez.");
	      browser.findElement(By.id("Sinossi2")).sendKeys("In una versione romanzata della East_High_School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High_School_Musical: The_Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale!");
	      browser.findElement(By.id("DurataEp")).sendKeys("0.28");
	      browser.findElement(By.id("Valutazione2")).sendKeys("5.0");
	      browser.findElement(By.id("submitSerie")).click();	
	      Thread.sleep(1100);
	      assertEquals("La sinossi non rispetta il formato richiesto.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_11() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo2")).sendKeys("High School Musical The Series The Sing Along");
	      browser.findElement(By.id("ImgCopertina2")).sendKeys("https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
	      browser.findElement(By.id("Trailer2")).sendKeys("https://www.youtube.com/embed/RlaV8sJGhfc");
	      browser.findElement(By.id("AnnoDiProduzione2")).sendKeys("20200");
	      browser.findElement(By.id("Stagioni")).sendKeys("1");
	      browser.findElement(By.id("Puntate")).sendKeys("10");
	      browser.findElement(By.id("genere1")).sendKeys("Drammatico");
	      browser.findElement(By.id("Cast2")).sendKeys("Olivia Rodrigo, Joshua Basset-Matt Cornett, Sofia Wylie,Julia Lester,Larry Saperstein,Frankie Rodriguez.");
	      browser.findElement(By.id("Sinossi2")).sendKeys("In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale.");
	      browser.findElement(By.id("DurataEp")).sendKeys("0.28");
	      browser.findElement(By.id("Valutazione2")).sendKeys("5.0");
	      browser.findElement(By.id("submitSerie")).click();	
	      Thread.sleep(1100);
	      assertEquals("L'anno di produzione non rispetta la lunghezza richiesta.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_12() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo2")).sendKeys("High School Musical The Series The Sing Along");
	      browser.findElement(By.id("ImgCopertina2")).sendKeys("https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
	      browser.findElement(By.id("Trailer2")).sendKeys("https://www.youtube.com/embed/RlaV8sJGhfc");
	      browser.findElement(By.id("AnnoDiProduzione2")).sendKeys("202o");
	      browser.findElement(By.id("Stagioni")).sendKeys("1");
	      browser.findElement(By.id("Puntate")).sendKeys("10");
	      browser.findElement(By.id("genere1")).sendKeys("Drammatico");
	      browser.findElement(By.id("Cast2")).sendKeys("Olivia Rodrigo, Joshua Basset-Matt Cornett, Sofia Wylie,Julia Lester,Larry Saperstein,Frankie Rodriguez.");
	      browser.findElement(By.id("Sinossi2")).sendKeys("In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale.");
	      browser.findElement(By.id("DurataEp")).sendKeys("0.28");
	      browser.findElement(By.id("Valutazione2")).sendKeys("5.0");
	      browser.findElement(By.id("submitSerie")).click();	
	      Thread.sleep(1100);
	      assertEquals("L'anno di produzione non rispetta il formato richiesto.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_13() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo2")).sendKeys("High School Musical The Series The Sing Along");
	      browser.findElement(By.id("ImgCopertina2")).sendKeys("https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
	      browser.findElement(By.id("Trailer2")).sendKeys("https://www.youtube.com/embed/RlaV8sJGhfc");
	      browser.findElement(By.id("AnnoDiProduzione2")).sendKeys("2020");
	      browser.findElement(By.id("Stagioni")).sendKeys("1");
	      browser.findElement(By.id("Puntate")).sendKeys("10");
	      browser.findElement(By.id("genere1")).sendKeys("Drammatico");
	      browser.findElement(By.id("Cast2")).sendKeys("Olivia Rodrigo, Joshua Basset-Matt Cornett, Sofia Wylie,Julia Lester,Larry Saperstein,Frankie Rodriguez.");
	      browser.findElement(By.id("Sinossi2")).sendKeys("In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale.");
	      browser.findElement(By.id("DurataEp")).sendKeys("100000.00");
	      browser.findElement(By.id("Valutazione2")).sendKeys("5.0");
	      browser.findElement(By.id("submitSerie")).click();	
	      Thread.sleep(1100);
	      assertEquals("La durata media episodio non rispetta la lunghezza richiesta.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_14() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo2")).sendKeys("High School Musical The Series The Sing Along");
	      browser.findElement(By.id("ImgCopertina2")).sendKeys("https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
	      browser.findElement(By.id("Trailer2")).sendKeys("https://www.youtube.com/embed/RlaV8sJGhfc");
	      browser.findElement(By.id("AnnoDiProduzione2")).sendKeys("2020");
	      browser.findElement(By.id("Stagioni")).sendKeys("1");
	      browser.findElement(By.id("Puntate")).sendKeys("10");
	      browser.findElement(By.id("genere1")).sendKeys("Drammatico");
	      browser.findElement(By.id("Cast2")).sendKeys("Olivia Rodrigo, Joshua Basset-Matt Cornett, Sofia Wylie,Julia Lester,Larry Saperstein,Frankie Rodriguez.");
	      browser.findElement(By.id("Sinossi2")).sendKeys("In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale.");
	      browser.findElement(By.id("DurataEp")).sendKeys("uno");
	      browser.findElement(By.id("Valutazione2")).sendKeys("5.0");
	      browser.findElement(By.id("submitSerie")).click();	
	      Thread.sleep(1100);
	      assertEquals("La durata media episodio non rispetta il formato richiesto.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_15() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo2")).sendKeys("High School Musical The Series The Sing Along");
	      browser.findElement(By.id("ImgCopertina2")).sendKeys("https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
	      browser.findElement(By.id("Trailer2")).sendKeys("https://www.youtube.com/embed/RlaV8sJGhfc");
	      browser.findElement(By.id("AnnoDiProduzione2")).sendKeys("2020");
	      browser.findElement(By.id("Stagioni")).sendKeys("1");
	      browser.findElement(By.id("Puntate")).sendKeys("100000");
	      browser.findElement(By.id("genere1")).sendKeys("Drammatico");
	      browser.findElement(By.id("Cast2")).sendKeys("Olivia Rodrigo, Joshua Basset-Matt Cornett, Sofia Wylie,Julia Lester,Larry Saperstein,Frankie Rodriguez.");
	      browser.findElement(By.id("Sinossi2")).sendKeys("In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale.");
	      browser.findElement(By.id("DurataEp")).sendKeys("0.28");
	      browser.findElement(By.id("Valutazione2")).sendKeys("5.0");
	      browser.findElement(By.id("submitSerie")).click();	
	      Thread.sleep(1100);
	      assertEquals("Il numero di puntate non rispetta la lunghezza richiesta.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_16() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo2")).sendKeys("High School Musical The Series The Sing Along");
	      browser.findElement(By.id("ImgCopertina2")).sendKeys("https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
	      browser.findElement(By.id("Trailer2")).sendKeys("https://www.youtube.com/embed/RlaV8sJGhfc");
	      browser.findElement(By.id("AnnoDiProduzione2")).sendKeys("2020");
	      browser.findElement(By.id("Stagioni")).sendKeys("1");
	      browser.findElement(By.id("Puntate")).sendKeys("uno");
	      browser.findElement(By.id("genere1")).sendKeys("Drammatico");
	      browser.findElement(By.id("Cast2")).sendKeys("Olivia Rodrigo, Joshua Basset-Matt Cornett, Sofia Wylie,Julia Lester,Larry Saperstein,Frankie Rodriguez.");
	      browser.findElement(By.id("Sinossi2")).sendKeys("In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale.");
	      browser.findElement(By.id("DurataEp")).sendKeys("0.28");
	      browser.findElement(By.id("Valutazione2")).sendKeys("5.0");
	      browser.findElement(By.id("submitSerie")).click();	
	      Thread.sleep(1100);
	      assertEquals("Il numero di puntate non rispetta il formato richiesto.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_17() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo2")).sendKeys("High School Musical The Series The Sing Along");
	      browser.findElement(By.id("ImgCopertina2")).sendKeys("https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
	      browser.findElement(By.id("Trailer2")).sendKeys("https://www.youtube.com/embed/RlaV8sJGhfc");
	      browser.findElement(By.id("AnnoDiProduzione2")).sendKeys("2020");
	      browser.findElement(By.id("Stagioni")).sendKeys("1");
	      browser.findElement(By.id("Puntate")).sendKeys("10");
	      browser.findElement(By.id("genere1")).sendKeys("");
	      browser.findElement(By.id("Cast2")).sendKeys("Olivia Rodrigo, Joshua Basset-Matt Cornett, Sofia Wylie,Julia Lester,Larry Saperstein,Frankie Rodriguez.");
	      browser.findElement(By.id("Sinossi2")).sendKeys("In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale.");
	      browser.findElement(By.id("DurataEp")).sendKeys("0.28");
	      browser.findElement(By.id("Valutazione2")).sendKeys("5.0");
	      browser.findElement(By.id("submitSerie")).click();	
	      Thread.sleep(1100);
	      assertEquals("Il genere non � stato selezionato.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_18() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo2")).sendKeys("High School Musical The Series The Sing Along");
	      browser.findElement(By.id("ImgCopertina2")).sendKeys("https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
	      browser.findElement(By.id("Trailer2")).sendKeys("https://www.youtube.com/embed/RlaV8sJGhfc");
	      browser.findElement(By.id("AnnoDiProduzione2")).sendKeys("2020");
	      browser.findElement(By.id("Stagioni")).sendKeys("100000.00");
	      browser.findElement(By.id("Puntate")).sendKeys("10");
	      browser.findElement(By.id("genere1")).sendKeys("Drammatico");
	      browser.findElement(By.id("Cast2")).sendKeys("Olivia Rodrigo, Joshua Basset-Matt Cornett, Sofia Wylie,Julia Lester,Larry Saperstein,Frankie Rodriguez.");
	      browser.findElement(By.id("Sinossi2")).sendKeys("In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale.");
	      browser.findElement(By.id("DurataEp")).sendKeys("0.28");
	      browser.findElement(By.id("Valutazione2")).sendKeys("5.0");
	      browser.findElement(By.id("submitSerie")).click();	
	      Thread.sleep(1100);
	      assertEquals("Il numero di stagioni non rispetta la lunghezza richiesta.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_19() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo2")).sendKeys("High School Musical The Series The Sing Along");
	      browser.findElement(By.id("ImgCopertina2")).sendKeys("https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
	      browser.findElement(By.id("Trailer2")).sendKeys("https://www.youtube.com/embed/RlaV8sJGhfc");
	      browser.findElement(By.id("AnnoDiProduzione2")).sendKeys("2020");
	      browser.findElement(By.id("Stagioni")).sendKeys("una");
	      browser.findElement(By.id("Puntate")).sendKeys("10");
	      browser.findElement(By.id("genere1")).sendKeys("Drammatico");
	      browser.findElement(By.id("Cast2")).sendKeys("Olivia Rodrigo, Joshua Basset-Matt Cornett, Sofia Wylie,Julia Lester,Larry Saperstein,Frankie Rodriguez.");
	      browser.findElement(By.id("Sinossi2")).sendKeys("In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale.");
	      browser.findElement(By.id("DurataEp")).sendKeys("0.28");
	      browser.findElement(By.id("Valutazione2")).sendKeys("5.0");
	      browser.findElement(By.id("submitSerie")).click();	
	      Thread.sleep(1100);
	      assertEquals("Il numero di stagioni non rispetta il formato richiesto.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_20() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo2")).sendKeys("High School Musical The Series The Sing Along");
	      browser.findElement(By.id("ImgCopertina2")).sendKeys("https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
	      browser.findElement(By.id("Trailer2")).sendKeys("https://www.youtube.com/embed/RlaV8sJGhfc");
	      browser.findElement(By.id("AnnoDiProduzione2")).sendKeys("2020");
	      browser.findElement(By.id("Stagioni")).sendKeys("1");
	      browser.findElement(By.id("Puntate")).sendKeys("10");
	      browser.findElement(By.id("genere1")).sendKeys("Drammatico");
	      browser.findElement(By.id("Cast2")).sendKeys("Olivia Rodrigo, Joshua Basset-Matt Cornett, Sofia Wylie,Julia Lester,Larry Saperstein,Frankie Rodriguez.");
	      browser.findElement(By.id("Sinossi2")).sendKeys("In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale.");
	      browser.findElement(By.id("DurataEp")).sendKeys("0.28");
	      browser.findElement(By.id("Valutazione2")).sendKeys("5000.0");
	      browser.findElement(By.id("submitSerie")).click();	
	      Thread.sleep(1100);
	      assertEquals("Le valutazioni non rispettano la lunghezza richiesta.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_21() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo2")).sendKeys("High School Musical The Series The Sing Along");
	      browser.findElement(By.id("ImgCopertina2")).sendKeys("https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
	      browser.findElement(By.id("Trailer2")).sendKeys("https://www.youtube.com/embed/RlaV8sJGhfc");
	      browser.findElement(By.id("AnnoDiProduzione2")).sendKeys("2020");
	      browser.findElement(By.id("Stagioni")).sendKeys("1");
	      browser.findElement(By.id("Puntate")).sendKeys("10");
	      browser.findElement(By.id("genere1")).sendKeys("Drammatico");
	      browser.findElement(By.id("Cast2")).sendKeys("Olivia Rodrigo, Joshua Basset-Matt Cornett, Sofia Wylie,Julia Lester,Larry Saperstein,Frankie Rodriguez.");
	      browser.findElement(By.id("Sinossi2")).sendKeys("In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale.");
	      browser.findElement(By.id("DurataEp")).sendKeys("0.28");
	      browser.findElement(By.id("Valutazione2")).sendKeys("tre");
	      browser.findElement(By.id("submitSerie")).click();	
	      Thread.sleep(1100);
	      assertEquals("Le valutazioni non rispettano il formato richiesto.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	
	@Test
	void tc_22() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("Titolo2")).sendKeys("High School Musical The Series The Sing Along");
	      browser.findElement(By.id("ImgCopertina2")).sendKeys("https://prod-ripcut-delivery.disney-plus.net/v1/variant/disney/C38CA129A7AB55BCC9F2CF61553017F91DC4E8348526199AB20CC6C8C7345146/scale?width=1200&aspectRatio=1.78&format=jpeg");
	      browser.findElement(By.id("Trailer2")).sendKeys("https://www.youtube.com/embed/RlaV8sJGhfc");
	      browser.findElement(By.id("AnnoDiProduzione2")).sendKeys("2020");
	      browser.findElement(By.id("Stagioni")).sendKeys("1");
	      browser.findElement(By.id("Puntate")).sendKeys("10");
	      browser.findElement(By.id("genere1")).sendKeys("Drammatico");
	      browser.findElement(By.id("Cast2")).sendKeys("Olivia Rodrigo, Joshua Basset-Matt Cornett, Sofia Wylie,Julia Lester,Larry Saperstein,Frankie Rodriguez.");
	      browser.findElement(By.id("Sinossi2")).sendKeys("In una versione romanzata della East High School in Salt Lake City, dove sono stati girati gli originali film di High School Musical, un ex membro del cast di fondo, Miss Jenn, inizia il suo lavoro come nuova insegnante di teatro. L'insegnante decide di allestire uno spettacolo di High School Musical: The Musical per la sua prima produzione teatrale invernale per celebrare l'affiliazione della scuola con il film originale.");
	      browser.findElement(By.id("DurataEp")).sendKeys("0.28");
	      browser.findElement(By.id("Valutazione2")).sendKeys("5");
	      browser.findElement(By.id("submitSerie")).click();	
	      Thread.sleep(1100);
	      assertEquals("Aggiunta avvenuta con successo.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
}
