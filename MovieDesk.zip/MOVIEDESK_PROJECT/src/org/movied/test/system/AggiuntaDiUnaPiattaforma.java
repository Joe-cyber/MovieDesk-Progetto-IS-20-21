package org.movied.test.system;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

class AggiuntaDiUnaPiattaforma {

	private WebDriver browser;
	private String url="http://127.0.0.1/MOVIEDESK_PROJECT/PersonalArea#p-view-7#collapseTen";
	@BeforeEach
	void initSession() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\calie\\OneDrive\\Desktop\\chromedriver.exe");
		browser = new ChromeDriver();
	    browser.get(url);
	    browser.findElement(By.id("email2")).sendKeys("mmanager@mail.com");
	    browser.findElement(By.id("password2")).sendKeys("MediaManager01");
	    browser.findElement(By.id("submitform")).click();		
	    browser.findElement(By.id("addPlatform")).click();	
	    browser.findElement(By.id("addPlatform2")).click();	
	}
	@Test
	void tc_01() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("nomePiattaforma")).sendKeys("YouTube Premiummmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm");
	      browser.findElement(By.id("link")).sendKeys("https://www.youtube.com/premium");
	      browser.findElement(By.id("imgPiattaforma")).sendKeys("https://cordcuttersnews.com/wp-content/uploads/2016/10/YouTube-icon-full_color-1024x721.png");
	      browser.findElement(By.id("abbonamentoMinimo")).sendKeys("11.99");
	      browser.findElement(By.id("submitPlatform")).click();	
	      Thread.sleep(1100);
	      assertEquals("Il nome della piattaforma non rispetta la lunghezza richiesta.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_02() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("nomePiattaforma")).sendKeys("YouTube_Premium");
	      browser.findElement(By.id("link")).sendKeys("https://www.youtube.com/premium");
	      browser.findElement(By.id("imgPiattaforma")).sendKeys("https://cordcuttersnews.com/wp-content/uploads/2016/10/YouTube-icon-full_color-1024x721.png");
	      browser.findElement(By.id("abbonamentoMinimo")).sendKeys("11.99");
	      browser.findElement(By.id("submitPlatform")).click();	
	      Thread.sleep(1100);
	      assertEquals("Il nome della piattaforma non rispetta il formato richiesto.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_03() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("nomePiattaforma")).sendKeys("YouTube Premium");
	      browser.findElement(By.id("link")).sendKeys("https://www.youtube.com/premium");
	      browser.findElement(By.id("imgPiattaforma")).sendKeys("wp-content/uploads/2016/10/YouTube-icon-full_coloricon-full_coloricon-full_coloricon-full_coloricon-full_coloricon-full_coloricon-full_coloricon-full_coloricon-full_coloricon-full_coloricon-full_coloricon-full_coloricon-full_coloricon-full_colorvicon-full_colorvicon-full_colorvicon-full_coloricon-full_colorvicon-full_coloricon-full_coloricon-full_coloricon-full_coloricon-full_coloricon-full_colorvicon-full_coloricon-full_coloricon-full_coloricon-full_coloricon-full_coloricon-full_coloricon-full_coloricon-full_coloricon-full_coloricon-full_coloricon-full_coloricon-full_colorvicon-full_coloricon-full_coloricon-full_coloril_coloricon-full_coloricon-full_coloricon-full_coloricon-full_colorv-1024x721l_coloricon-full_coloricon-full_coloricon-full_coloricon-full_colorv-1024x721l_coloricon-full_coloricon-full_coloricon-full_coloricon-full_colorv-1024x721l_coloricon-full_coloricon-full_coloricon-full_coloricon-full_colorv-1024x721l_coloricon-full_coloricon-full_coloricon-full_coloricon-full_colorv-1024xfull_coloricon-full_colorv-1024x721l_coloricon-full_coloricon-full_coloricon-full_coloricon-full_colorv-1024x721l_coloricon-full_coloricon-full_coloricon-full_coloricon-full_colorv-1024x721l_co721l_coloricon-full_coloricon-full_coloricon-full_coloricon-full_colorv-1024x721l_coloricon-full_coloricon-full_coloricon-full_coloricon-full_colorv-1024x721l_coloricon-full_coloricon-full_coloricon-full_coloricon-full_colorv-1024x721l_coloricon-full_coloricon-full_coloricon-full_coloricon-full_colorv-1024x721l_coloricon-full_coloricon-full_coloricon-full_coloricon-full_colorv-1024x721l_coloricon-full_coloricon-full_coloricon-full_coloricon-full_colorv-1024x721l_coloricon-full_coloricon-full_coloricon-full_coloricon-full_colorv-1024x721l_coloricon-full_coloricon-full_coloricon-full_coloricon-full_colorv-1024x721l_coloricon-full_coloricon-full_coloricon-full_coloricon-full_colorv-1024x721l_coloricon-full_coloricon-full_coloricon-full_coloricon-full_colorv-1024x721l_coloricon-full_ full_colorv-1024x721con-full_coloricon-full_coloricon-full_coloricon-full_colorv-1024x721.png");
	      browser.findElement(By.id("abbonamentoMinimo")).sendKeys("11.99");
	      browser.findElement(By.id("submitPlatform")).click();	
	      Thread.sleep(1100);
	      assertEquals("L'immagine della piattaforma non rispetta la lunghezza richiesta.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_04() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("nomePiattaforma")).sendKeys("YouTube Premium");
	      browser.findElement(By.id("link")).sendKeys("https://www.youtube.com/premium");
	      browser.findElement(By.id("imgPiattaforma")).sendKeys("wp-content/uploads/2016/10/YouTube-icon-full_color-1024x721.png");
	      browser.findElement(By.id("abbonamentoMinimo")).sendKeys("11.99");
	      browser.findElement(By.id("submitPlatform")).click();	
	      Thread.sleep(1100);
	      assertEquals("L'immagine della piattaforma non rispetta il formato richiesto.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_05() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("nomePiattaforma")).sendKeys("YouTube Premium");
	      browser.findElement(By.id("link")).sendKeys("https://www.youtube.com/premium");
	      browser.findElement(By.id("imgPiattaforma")).sendKeys("https://cordcuttersnews.com/wp-content/uploads/2016/10/YouTube-icon-full_color-1024x721.png");
	      browser.findElement(By.id("abbonamentoMinimo")).sendKeys("11000000.00");
	      browser.findElement(By.id("submitPlatform")).click();	
	      Thread.sleep(1100);
	      assertEquals("L'abbonamento minimo non rispetta la lunghezza richiesta.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_06() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("nomePiattaforma")).sendKeys("YouTube Premium");
	      browser.findElement(By.id("link")).sendKeys("https://www.youtube.com/premium");
	      browser.findElement(By.id("imgPiattaforma")).sendKeys("https://cordcuttersnews.com/wp-content/uploads/2016/10/YouTube-icon-full_color-1024x721.png");
	      browser.findElement(By.id("abbonamentoMinimo")).sendKeys("uno");
	      browser.findElement(By.id("submitPlatform")).click();	
	      Thread.sleep(1100);
	      assertEquals("L'abbonamento minimo non rispetta il formato richiesto.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_07() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("nomePiattaforma")).sendKeys("YouTube Premium");
	      browser.findElement(By.id("link")).sendKeys("https://www.youtube.com/premiumjhgoirghowirgooiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iboroiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iboroiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iboroiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iboroiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iboroiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iboroiwrnkmvkenv�iborbjhgoirghowirgoiw�iborbjhgoirghowirgoiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iboroiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iboroiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iboriwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborbmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iboriwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iboriwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborhowirgoiwrnkmvkenv�iboroiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iboroiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iboroiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iboroiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iboroiwrnkmvkenv�iborbjhgoirghowirgoiw�iborbjhgoirghowirgoiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iboroiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iboroiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iboriwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborbmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iboriwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�iboriwrnkmvkenv�iborbjhgoirghowirgoiwrnkmvkenv�ibor");
	      browser.findElement(By.id("imgPiattaforma")).sendKeys("https://cordcuttersnews.com/wp-content/uploads/2016/10/YouTube-icon-full_color-1024x721.png");
	      browser.findElement(By.id("abbonamentoMinimo")).sendKeys("11.99");
	      browser.findElement(By.id("submitPlatform")).click();	
	      Thread.sleep(1100);
	      assertEquals("Il link di riferimento non rispetta la lunghezza richiesta.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_08() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("nomePiattaforma")).sendKeys("YouTube Premium");
	      browser.findElement(By.id("link")).sendKeys("youtube.com/premium");
	      browser.findElement(By.id("imgPiattaforma")).sendKeys("https://cordcuttersnews.com/wp-content/uploads/2016/10/YouTube-icon-full_color-1024x721.png");
	      browser.findElement(By.id("abbonamentoMinimo")).sendKeys("11.99");
	      browser.findElement(By.id("submitPlatform")).click();	
	      Thread.sleep(1100);
	      assertEquals("Il link di riferimento non rispetta il formato richiesto.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
	@Test
	void tc_09() throws InterruptedException{
	      browser.get(url);
	      browser.findElement(By.id("nomePiattaforma")).sendKeys("YouTube Premium");
	      browser.findElement(By.id("link")).sendKeys("https://www.youtube.com/premium");
	      browser.findElement(By.id("imgPiattaforma")).sendKeys("https://cordcuttersnews.com/wp-content/uploads/2016/10/YouTube-icon-full_color-1024x721.png");
	      browser.findElement(By.id("abbonamentoMinimo")).sendKeys("11.99");
	      browser.findElement(By.id("submitPlatform")).click();	
	      Thread.sleep(1100);
	      assertEquals("Aggiunta avvenuta con successo.",browser.findElement(By.id("message")).getText());
	      browser.close();
	}
}
