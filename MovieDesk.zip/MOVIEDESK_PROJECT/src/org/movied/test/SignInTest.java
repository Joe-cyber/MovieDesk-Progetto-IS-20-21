package org.movied.test;

import java.io.IOException;
import javax.servlet.ServletException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.movied.control.db.MovieDB;
import org.movied.control.redirect.SignIn;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockHttpSession;

class SignInTest {

	private SignIn servlet;
	private MockHttpServletRequest request;
	private MockHttpServletResponse response;
	private MockHttpSession session;
	@BeforeEach
	void setUp() throws Exception {
		servlet = new SignIn();
		request = new MockHttpServletRequest();
		response = new MockHttpServletResponse();
		new MovieDB("jdbc:mysql://localhost:3306/db_moviedb","StandardUser","Password1");
		session = new MockHttpSession();
		request.setSession(session);
	}

	@Test
	public void testSignInSuccessMM() throws ServletException, IOException{	
		request.addParameter("j_username", "mmanager@mail.com");
		request.addParameter("j_password", "MediaManager01");
		request.setSession(session);
		servlet.doGet(request, response);
	}
	
	@Test
	public void testSignInSuccessUS() throws ServletException, IOException{	
		request.addParameter("j_username", "ustandard@mail.com");
		request.addParameter("j_password", "UtenteStandard01");
		request.setSession(session);
		servlet.doGet(request, response);
	}
	
	@Test
	public void testSignInFail() throws ServletException, IOException{	
		request.addParameter("j_username", "mmanager@mail.com");
		request.addParameter("j_password", "MediaManager0i");
		request.setSession(session);
		servlet.doGet(request, response);
	}
}
