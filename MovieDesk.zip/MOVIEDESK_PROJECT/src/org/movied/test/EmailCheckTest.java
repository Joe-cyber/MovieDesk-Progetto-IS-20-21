package org.movied.test;

import static org.junit.jupiter.api.Assertions.*;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.movied.control.db.MovieDB;
import org.movied.control.redirect.EmailCheck;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

class EmailCheckTest {
	private EmailCheck servlet;
	private MockHttpServletRequest request;
	private MockHttpServletResponse response;
	@BeforeEach
	void setUp() throws Exception {
		servlet = new EmailCheck();
		request = new MockHttpServletRequest();
		response = new MockHttpServletResponse();
		new MovieDB("jdbc:mysql://localhost:3306/db_moviedb","StandardUser","Password1");
	}

	@Test
	public void testWithId() throws ServletException, IOException{	
		request.setParameter("email", "mmanager@mail.com");
		servlet.doPost(request, response);
		assertEquals(HttpServletResponse.SC_ACCEPTED,response.getStatus());
	}

	@Test
	public void testWithout() throws ServletException, IOException{	
		request.setParameter("email", "mmanager@email.com");
		servlet.doPost(request, response);
		assertEquals(HttpServletResponse.SC_FORBIDDEN,response.getStatus());
	}
}
