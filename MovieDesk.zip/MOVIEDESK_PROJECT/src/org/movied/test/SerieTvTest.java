package org.movied.test;

import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import org.junit.jupiter.api.Test;
import org.movied.model.bean.Contenuto.Genere;
import org.movied.model.bean.Piattaforma;
import org.movied.model.bean.SerieTv;

class SerieTvTest {

	//INIZIO TEST GET
	@Test
	void testGetStagioni() {
		SerieTv s=new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"5","",0.0f,0,0.0f);
		assertEquals("5",s.getStagioni());
	}

	@Test
	void testGetPuntate() {
		SerieTv s=new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"","10",0.0f,0,0.0f);
		assertEquals("10",s.getPuntate());
	}

	@Test
	void testGetDurataEpisodio() {
		SerieTv s=new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"5","",10.0f,0,0.0f);
		assertEquals(10.0f,s.getDurataEpisodio());
	}
	
	//FINE TEST GET
	//INIZIO TEST SET
	
	@Test
	void testSetStagioni() {
		SerieTv s=new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"5","",0.0f,0,0.0f);
		s.setStagioni("10");
		assertEquals("10",s.getStagioni());
	}

	@Test
	void testSetPuntate() {
		SerieTv s=new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"","10",0.0f,0,0.0f);
		s.setPuntate("5");
		assertEquals("5",s.getPuntate());
	}

	@Test
	void testSetDurataEpisodio() {
		SerieTv s=new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"5","",10.0f,0,0.0f);
		s.setDurataEpisodio(50.0f);
		assertEquals(50.0f,s.getDurataEpisodio());
	}
	
	//FINE TEST SET

	@Test
	void testEqualsSuccess1() {
		SerieTv s1=new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"","10",0.0f,0,0.0f);
		SerieTv s2=new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"","10",0.0f,0,0.0f);
		assertTrue(s1.equals(s2));
	}
	
	@Test
	void testEqualsFail1() {
		SerieTv s1=new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"","10",0.0f,0,0.0f);
		SerieTv s2=new SerieTv(1,null,"","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"","10",0.0f,0,0.0f);
		assertFalse(s1.equals(s2));
	}
	
	@Test
	void testEqualsFail2() {
		SerieTv s1=new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"","10",null,0,0.0f);
		SerieTv s2=new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"","10",null,0,0.0f);
		assertTrue(s1.equals(s2));
	}
	
	@Test
	void testEqualsFail3() {
		SerieTv s1=new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"","10",null,0,0.0f);
		SerieTv s2=new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"","10",0.0f,0,0.0f);
		assertFalse(s1.equals(s2));
	}
	
	@Test
	void testEqualsFail4() {
		SerieTv s1=new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"","10",0.0f,0,0.0f);
		SerieTv s2=new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"","10",1.0f,0,0.0f);
		assertFalse(s1.equals(s2));
	}
	
	@Test
	void testEqualsFail5() {
		SerieTv s1=new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"",null,null,0,0.0f);
		SerieTv s2=new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"",null,null,0,0.0f);
		assertTrue(s1.equals(s2));
	}
	
	@Test
	void testEqualsFail6() {
		SerieTv s1=new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"",null,null,0,0.0f);
		SerieTv s2=new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"","10",null,0,0.0f);
		assertFalse(s1.equals(s2));
	}
	
	@Test
	void testEqualsFail7() {
		SerieTv s1=new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"","10",null,0,0.0f);
		SerieTv s2=new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"","11",null,0,0.0f);
		assertFalse(s1.equals(s2));
	}
	
	@Test
	void testEqualsFail8() {
		SerieTv s1=new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),null,null,null,0,0.0f);
		SerieTv s2=new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),null,null,null,0,0.0f);
		assertTrue(s1.equals(s2));
	}
	
	@Test
	void testEqualsFail9() {
		SerieTv s1=new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),null,null,null,0,0.0f);
		SerieTv s2=new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"",null,null,0,0.0f);
		assertFalse(s1.equals(s2));
	}
	
	@Test
	void testEqualsFail10() {
		SerieTv s1=new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"",null,null,0,0.0f);
		SerieTv s2=new SerieTv(1,"","","","","","",new ArrayList<Genere>(),new ArrayList<Piattaforma>(),"5",null,null,0,0.0f);
		assertFalse(s1.equals(s2));
	}
}
