package org.movied.test;

import java.io.IOException;
import javax.servlet.ServletException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.movied.control.db.MovieDB;
import org.movied.control.redirect.Mark;
import org.movied.model.dao.UtenteRegistratoDao;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockHttpSession;

class MarkTest {

	private Mark servlet;
	private MockHttpServletRequest request;
	private MockHttpServletResponse response;
	private MockHttpSession session;
	@BeforeEach
	void setUp() throws Exception {
		servlet = new Mark();
		request = new MockHttpServletRequest();
		response = new MockHttpServletResponse();
		session = new MockHttpSession();
		request.setSession(session);
		new MovieDB("jdbc:mysql://localhost:3306/db_moviedb","StandardUser","Password1");
	}

	@Test
	public void testWithoutUser() throws ServletException, IOException{	
		request.setParameter("id", "1");
		request.setParameter("tag", "Preferito");
		servlet.doGet(request, response);
	}

	@Test
	public void testWithUser() throws ServletException, IOException{	
		request.setParameter("id", "2");
		request.setParameter("tag", "Preferito");
		session.setAttribute("utente", new UtenteRegistratoDao().findUtente("mmanager@mail.com", "MediaManager01"));
		request.setSession(session);
		servlet.doPost(request, response);
	}
	
	@Test
	public void testWithUserFailMark() throws ServletException, IOException{	
		request.setParameter("id", "2");
		request.setParameter("tag", "Preferito");
		session.setAttribute("utente", new UtenteRegistratoDao().findUtente("mmanager@mail.com", "MediaManager01"));
		request.setSession(session);
		servlet.doPost(request, response);
	}
}
