package org.movied.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.movied.control.db.MovieDB;
import org.movied.model.dao.UtenteRegistratoDao;

class UtenteRegistratoDaoTest {

	private UtenteRegistratoDao dao;
	
	@BeforeEach
	void setUp() throws Exception {
		dao=new UtenteRegistratoDao();
		new MovieDB("jdbc:mysql://localhost:3306/db_moviedb","StandardUser","Password1");
	}
	
	@Test
	void testFindUtenteSuccess() {
		assertNotNull(dao.findUtente("mmanager@mail.com", "MediaManager01"));
	}
	
	@Test
	void testFindUtenteFail() {
		assertNull(dao.findUtente("mmanager@mail.com", "MediaManager02"));
	}
	
	@Test
	void testFindUtenteMailSuccess() {
		assertNotNull(dao.findUtente("mmanager@mail.com"));
	}
	
	@Test
	void testFindUtenteMailFail() {
		assertNull(dao.findUtente("mediamanager2@mail.it"));
	}
	
	@Test
	void testInsertLike() {
		assertEquals(1, dao.insertMark("1", "Piaciuto", dao.findUtente("mmanager@mail.com", "MediaManager01")));
	}
	
	@Test
	void testInsertPreferred() {
		assertEquals(1, dao.insertMark("1", "Preferito", dao.findUtente("mmanager@mail.com", "MediaManager01")));
	}
	
	@Test
	void testInsertSeen() {
		assertEquals(1, dao.insertMark("1", "Visto", dao.findUtente("mmanager@mail.com", "MediaManager01")));
	}
	
	@Test
	void testInsertError() {
		assertEquals(0, dao.insertMark("1", "Default", dao.findUtente("mmanager@mail.com", "MediaManager01")));
	}
	
	@Test
	void testFindPiaciuti() {
		assertNotNull(dao.findPiaciuti("mmanager@mail.com"));
	}
	
	@Test
	void testFindVisti() {
		assertNotNull(dao.findVisti("mmanager@mail.com"));
	}
	
	@Test
	void testFindPreferiti() {
		assertNotNull(dao.findPreferiti("mmanager@mail.com"));
	}
	
	@Test
	void testFindEmailSuccess() {
		assertTrue(dao.findEmail("mmanager@mail.com"));
	}
	
	@Test
	void testFindEmailFail() {
		assertFalse(dao.findEmail("mmmanager@mail.com"));
	}
	
}
