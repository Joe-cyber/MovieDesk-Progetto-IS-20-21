/**
 * 
 * 
 * @param inputtxt is the email that you want to validate
 * @returns true if the value is not null and match the regex
 * @returns false if the value is longer than 200 characters or less than 1
 * @returns false if doesn't match the regex
 */
function checkEmail(inputtxt){
	var email=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3}){1,200}$/;
	if(inputtxt.value.match(email)){
		return true;
	}else if(inputtxt.value.length>200 || inputtxt.value.length<1){
		alert("l\x27email inserita ha troppi caratteri.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}else{
		alert("L\x27email inserita non rispetta il formato.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}
}
/**
 * 
 * 
 * @param inputtxt is the password that you want to validate
 * @returns true if the value is not null and match the regex
 * @returns false if the value is longer than 32 characters or less than 1
 * @returns false if doesn't match the regex
 */
function checkPassword(inputtxt){
	var password=/^[A-Za-z0-9]{8,32}$/;
	if(inputtxt.value.match(password)){
		return true;
	}else if(inputtxt.value.length>32 || inputtxt.value.length<1){
		alert("la password inserita non rispetta la lunghezza");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}else{
		alert("Password non valida");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}
}
/**
 * 
 * 
 * @param inputtxt is the movie director that you want to validate
 * @returns true if the value is not null and match the regex
 * @returns false if the value is longer than 50 characters or less than 1
 * @returns false if doesn't match the regex
 */
function checkRegista(inputtxt){

	var regista=/^[A-Za-z0-9',-.òàèùì\s]{1,50}$/;
	if(inputtxt.value.match(regista)){
		return true;
	}else if(inputtxt.value.length>50){
		alert("Il regista non rispetta la lunghezza richiesta.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}else{
		alert("Il regista non rispetta il formato richiesto.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}
}
/**
 * 
 * 
 * @param inputtxt is the year that you want to validate
 * @returns true if the value is not null and match the regex
 * @returns false if the value is longer than 4 characters or less than 1
 * @returns false if doesn't match the regex
 */
function checkAnno(inputtxt){
	var anno=/^\d{4}/;
	if(inputtxt.value.match(anno)){
		return true;
	}else if(inputtxt.value.length>4 || inputtxt.value.length<1 ){
		alert("L\x27anno di produzione non rispetta la lunghezza richiesta.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}else{
		alert("L\x27anno di produzione non rispetta il formato richiesto.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}
}
/** 
 * 
 * @param inputtxt is the cast that you want to validate
 * @returns true if the value is not null and match the regex
 * @returns false if the value is longer than 500 characters or less than 1
 * @returns false if doesn't match the regex
 */
function checkCast(inputtxt)
{
	var cast=/^[A-Za-z0-9',-.'àèùòì\s]{1,500}$/;
	if(inputtxt.value.match(cast)){
		return true;
	}else if(inputtxt.value.length>500 || inputtxt.value.length<1 ){
		alert("Il cast non rispetta ia lunghezza richiesta.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}else{
		alert("Il cast non rispetta il formato richiesto.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}
}



/**
 * 
 * 
 * @param inputtxt is the trailer that you want to validate
 * @returns true if the value is not null and match the regex
 * @returns false if the value is longer than 2048 characters or less than 1
 * @returns false if doesn't match the regex
 */



function checkTrailer(inputtxt){
	var link=/^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/;
	if(inputtxt.value.match(link)){
		return true;
	}else if(inputtxt.value.length>2048 || inputtxt.value.length<1 ){
		alert("Il trailer non rispetta la lunghezza richiesta.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}else{
		alert("Il trailer non rispetta il formato richiesto.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}

}

/**
 * 
 * 
 * @param inputtxt is the title that you want to validate
 * @returns true if the value is not null and match the regex
 * @returns false if the value is longer than 50 characters or less than 1
 * @returns false if doesn't match the regex
 */
function checkTitolo(inputtxt){
	var titolo=/^[A-Za-z0-9',-.òàèùì\s]{1,50}$/;
	if(inputtxt.value.match(titolo)){
		return true;
	}
	else if(inputtxt.value.length>50 || inputtxt.value.length<1){
		alert("Il titolo non rispetta la lunghezza richiesta.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}else{
		alert("Il titolo non rispetta il formato richiesto.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}
}
/**
 * 
 * 
 * @param inputtxt is the research that you want to validate
 * @returns true if the value is not null and match the regex
 * @returns false if the value is longer than 50 characters or less than 1
 * @returns false if doesn't match the regex
 */

function checkRicerca(inputtxt){
	var titolo=/^[A-Za-z0-9',-.òàèùì\s]{1,50}$/;
	if(inputtxt.value.match(titolo)){
		return true;
	}else if(inputtxt.value.length>50 || inputtxt.value.length<1 ){
		alert("Il titolo non rispetta la lunghezza richiesta.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}else{
		alert("Il titolo non rispetta il formato richiesto.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}
}
/**
 * 
 * 
 * @param inputtxt is the cover that you want to validate
 * @returns true if the value is not null and match the regex
 * @returns false if the value is longer than 2048 characters or less than 1
 * @returns false if doesn't match the regex
 */


function checkImmagineCopertina(inputtxt){
	var img=/^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/;
	if(inputtxt.value.match(img)){
		return true;
	}else if(inputtxt.value.length>2048 || inputtxt.value.length<1){
		alert("L\x27immagine di copertina non rispetta la lunghezza richiesta.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}else{
		alert("L\x27immagine di copertina non rispetta il formato richiesto.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}
}


/**
 * 
 * 
 * @param inputtxt is the rating that you want to validate
 * @returns true if the value is not null and match the regex
 * @returns false if the value is longer than 3 characters or less than 1
 * @returns false if doesn't match the regex
 */


function checkValutazione(inputtxt){
	var valutazione=/^[1-4][.][0-9]$|^[1-5]$/;
	if(inputtxt.value.match(valutazione)){
		return true;
	}else if(inputtxt.value.length>3 || inputtxt.value.length<1){
		alert("La valutazione non rispetta la lunghezza richiesta.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}else{
		alert("La valutazione non rispetta il formato richiesto.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}
}


/**
 * 
 * 
 * @param inputtxt is the synopsis that you want to validate
 * @returns true if the value is not null and match the regex
 * @returns false if the value is longer than 100 characters or less than 1
 * @returns false if doesn't match the regex
 */


function checkSinossi(inputtxt){
	var sinossi=/^[A-Za-z0-9',-:.'àèùòì\s]{1,500}$/;
	if(inputtxt.value.match(sinossi)){
		return true;
	}else if(inputtxt.value.length>500 || inputtxt.value.length<1){
		alert("La sinossi non rispetta la lunghezza richiesta.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}else{
		alert("La sinossi non rispetta il formato richiesto.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}
}


/**
 * 
 * 
 * @param inputtxt is the movie length that you want to validate
 * @returns true if the value is not null and match the regex
 * @returns false if the value is longer than 5 characters or less than 1
 * @returns false if doesn't match the regex
 */


function checkDurata(inputtxt){
	var durata=/^(\d{1,3}\.[0-5][0-9])$/;
	if(inputtxt.value.match(durata)){
		return true;
	}else if(inputtxt.value.length>5 || inputtxt.value.length<1){
		alert("La durata non rispetta la lunghezza richiesta.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}else{
		alert("La durata non rispetta il formato richiesto.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}

}

/**
 * 
 * 
 * @param inputtxt is the number of seasons that you want to validate
 * @returns true if the value is not null and match the regex
 * @returns false if the value is longer than 2 characters or less than 1
 * @returns false if doesn't match the regex
 */

function checkNumStagioni(inputtxt){
	var numStagioni=/^\d{1,2}$/;
	if(inputtxt.value.match(numStagioni)){
		return true;	
	}else if(inputtxt.value.length>2 || inputtxt.value.length<1){
		alert("Il numero di stagiorni non rispetta la lunghezza richiesta.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}else{
		alert("Il numero di stagiorni non rispetta il formato richiesto.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}
}


/**
 * 
 * 
 * @param inputtxt is the number of episodes that you want to validate
 * @returns true if the value is not null and match the regex
 * @returns false if the value is longer than 4 characters or less than 1
 * @returns false if doesn't match the regex
 */

function checkNumEpisodi(inputtxt){
	var numEpisodi=/^\d{1,4}$/;
	if(inputtxt.value.match(numEpisodi)){
		return true;
	}else if(inputtxt.value.length>4 || inputtxt.value.length<1){
		alert("Il numero di puntate non rispetta la lunghezza richiesta.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}else{
		alert("Il numero di puntate non rispetta il formato richiesto.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}
}


/**
 * 
 * 
 * @param inputtxt is the episode length that you want to validate
 * @returns true if the value is not null and match the regex
 * @returns false if the value is longer than 6 characters or less than 1
 * @returns false if doesn't match the regex
 */

function checkDurataEp(inputtxt){
	var durataEp=/^(\d{1,3}\.[0-5][0-9])$/;
	if(inputtxt.value.match(durataEp)){
		return true;
	}else if(inputtxt.value.length>5 || inputtxt.value.length<1){
		alert("La durata media episodio non rispetta la lunghezza richiesta.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}else{
		alert("La durata media episodio non rispetta il formato richiesto.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}
}
/**
 * 
 * 
 * @param inputtxt is the platform's name that you want to validate
 * @returns true if the value is not null and match the regex
 * @returns false if the value is longer than 50 characters or less than 1
 * @returns false if doesn't match the regex
 */

function checkNomePiattaforma(inputtxt){
	var nomePiattaforma=/^[A-Za-z0-9',-.àèùòì\s]{1,50}$/;
	if(inputtxt.value.match(nomePiattaforma)){
		return true;
	}else if(inputtxt.value.length>50 || inputtxt.value.length<1){
		alert("Il nome non rispetta la lunghezza richiesta.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}else{
		alert("Il nome non rispetta il formato richiesto.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}
}
/**
 * 
 * 
 * @param inputtxt is the platform's link that you want to validate
 * @returns true if the value is not null and match the regex
 * @returns false if the value is longer than 2048 characters or less than 1
 * @returns false if doesn't match the regex
 */
function checkLinkPiattaforma(inputtxt){
	var link=/^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/;
	if(inputtxt.value.match(link)){
		return true;
	}else if(inputtxt.value.length>2048 || inputtxt.value.length<1){
		alert("Il link di riferimento non rispetta la lunghezza richiesta.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}else{
		alert("Il link di riferimento non rispetta il formato richiesto.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}
}

/**
 * 
 * 
 * @param inputtxt is the platform's image that you want to validate
 * @returns true if the value is not null and match the regex
 * @returns false if the value is longer than 2048 characters or less than 1
 * @returns false if doesn't match the regex
 */
function checkLinkImgPiattaforma(inputtxt){
	var linkImg=/^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/;
	if(inputtxt.value.match(linkImg)){
		return true;
	}else if(inputtxt.value.length>2048 || inputtxt.value.length<1){
		alert("L'immagine della piattaforma non rispetta la lunghezza richiesta.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}else{
		alert("L'immagine della piattaforma non rispetta il formato richiesto.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}
}

/**
 * 
 * 
 * @param inputtxt is the platform's price that you want to validate
 * @returns true if the value is not null and match the regex
 * @returns false if the value is longer than 3 characters or less than 1
 * @returns false if doesn't match the regex
 */
function checkAbbonamento(inputtxt){
	var prezzo=/^[0-9]{1,2}(\.\d{2})$|^\d{1,5}$/;
	if(inputtxt.value.match(prezzo)){
		return true;
	}else if(inputtxt.value.length>5 || inputtxt.value.length<1){
		alert("L'abbonamento minimo non rispetta la lunghezza richiesta.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}else{
		alert("L'abbonamento minimo non rispetta il formato richiesto.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}
}

/**
 * 
 * 
 * @param inputtxt is the object that you want to validate
 * @returns true if the value is not null and match the regex
 * @returns false if the value is longer than 25 characters or less than 1
 * @returns false if doesn't match the regex
 */
function checkOggetto(inputtxt){
	var oggetto=/^[A-Za-z0-9',-.'àèùòì\s]{1,26}$/;
	if(inputtxt.value.match(oggetto)){
		return true;
	}else if(inputtxt.value.length>25 || inputtxt.value.length<1){
		alert("L'oggetto della segnalazione non rispetta la lunghezza richiesta.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}else{
		alert("L'oggetto della segnalazione non rispetta il formato richiesto.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}
}
/**
 * 
 * 
 * @param inputtxt is the message that you want to validate
 * @returns true if the value is not null and match the regex
 * @returns false if the value is longer than 50 characters or less than 1
 * @returns false if doesn't match the regex
 */
function checkMessaggio(inputtxt){
	var messaggio=/^[A-Za-z0-9',-.'àèùòì\s]{1,51}$/;
	if(inputtxt.value.match(messaggio)){
		return true;
	}else if(inputtxt.value.length>50 || inputtxt.value.length<1){
		alert("Il messaggio della segnalazione non rispetta la lunghezza richiesta.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}else{
		alert("Il messaggio della segnalazione non rispetta il formato richiesto.");
		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}
}

/**
 * 
 * 
 * @param filtro is the filter that you want to validate
 * @returns true if the value is not null
 * @returns false if the value is null
 */
function checkFiltro(filtro){

	if(filtro.value=="-- Anno --"){
		alert("Seleziona un anno di produzione per filtrare la visualizzazione.");
		filtro.focus();
		event.preventDefault(); 
		return false;
	}else
		return true;
}



/**
 * 
 * 
 * @param 
 * @returns true if all the checks functions return true 
 * @returns false if one of the function 'check' return false
 */
function validateLogin(){
	var email= document.getElementById("email2");
	var password= document.getElementById("password2");
	if(checkEmail(email)){
		if(checkPassword(password)){
			document.getElementById("submitform").submit();
		}
	}
	return false;

}


/**
 * 
 * 
 * @param 
 * @returns true if all the checks functions return true 
 * @returns false if one of the function 'check' return false
 */

function validateRecoverPassword(){
	var email= document.getElementById("email");
	if(checkEmail(email)){
		document.getElementById("submit").submit();
	}
	return false;
}

/**
 * 
 * 
 * @param 
 * @returns true if all the checks functions return true 
 * @returns false if one of the function 'check' return false
 */
function validateFilm(){
	var titolo= document.getElementById("Titolo");
	var imgCopertina= document.getElementById("ImgCopertina");
	var	anno= document.getElementById("AnnoDiProduzione");
	var durata= document.getElementById("Durata");
	var cast= document.getElementById("Cast");
	var trailer= document.getElementById("Trailer");
	var sinossi= document.getElementById("Sinossi");
	var regista= document.getElementById("Regista");
	var valutazione= document.getElementById("Valutazione");
	if(checkTitolo(titolo)){
		if(checkImmagineCopertina(imgCopertina)){}
		if(checkAnno(anno)){
			if(checkDurata(durata)){
				if(checkCast(cast)){
					if(checkTrailer(trailer)){	
						if(checkSinossi(sinossi)){
							if(checkRegista(regista)){
								if(checkValutazione(valutazione)){		
									document.getElementById("submit3").submit();
								}
							}	
						}
					}
				}
			}
		}
	}
}


/**
 * 
 * 
 * @param 
 * @returns true if all the checks functions return true 
 * @returns false if one of the function 'check' return false
 */
function validateSerie(){
	var titolo= document.getElementById("Titolo2");
	var imgCopertina= document.getElementById("ImgCopertina2");
	var stagioni=document.getElementById("Stagioni");
	var puntate=document.getElementById("Puntate");
	var durataEp= document.getElementById("DurataEp");
	var	anno= document.getElementById("AnnoDiProduzione2");
	var trailer= document.getElementById("Trailer2");
	var cast= document.getElementById("Cast2");
	var sinossi= document.getElementById("Sinossi2");
	var valutazione= document.getElementById("Valuazione2");
	if(checkTitolo(titolo)){
		if(checkImmagineCopertina(imgCopertina)){
			if(checkNumStagioni(stagioni)){
				if(checkNumEpisodi(puntate)){
					if(checkDurataEp(durataEp)){
						if(checkAnno(anno)){
							if(checkAnno(anno)){
								if(checkTrailer(trailer)){
									if(checkCast(cast)){
										if(checkSinossi(sinossi)){
											if(checkValutazione(valutazione)){
												document.getElementById("submit4").submit();
											}
										}
									}

								}
							}
						}
					}
				}
			}
		}
	}
}



/**
 * 
 * 
 * @param 
 * @returns true if all the checks functions return true 
 * @returns false if one of the function 'check' return false
 */

function validatePiattaforma(){
	var nomePiattaforma= document.getElementById("nomePiattaforma");
	var link= document.getElementById("link");
	var linkImg=document.getElementById("imgPiattaforma");
	var abbonamento=document.getElementById("abbonamentoMinimo");
	if(checkNomePiattaforma(nomePiattaforma)){
		if(checkLinkPiattaforma(link)){
			if(checkLinkImgPiattaforma(linkImg)){
				if(checkAbbonamento(abbonamento)){
					document.getElementById("submit5").submit();
				}
			}
		}
	}
}

/*Validazione dei dati personali di un utente (?Probabili modifiche da effettuare)*/


function validateDatiPersonali(){

	var nome= document.getElementById("username");
	var password= document.getElementById("password");
	var conferma= document.getElementById("conferma");
	if(checkNome(username)){
		if(checkPassword(password)){
			if(checkPassword(conferma)){
				if(!(password.value==conferma.value)){
					alert("Le password non corrispondono");
					conferma.focus();
					return false;
				}else{
					document.getElementById("submit").submit();
				}
			}
		}
	}
	return false;
}
/**
 * 
 * 
 * @param 
 * @returns true if all the checks functions return true 
 * @returns false if one of the function 'check' return false
 */
function validateSegnalazione(){
	var oggetto= document.getElementById("object");
	var messaggio= document.getElementById("message");
	if(checkOggetto(oggetto)){
		if(checkMessaggio(messaggio)){
			document.getElementById("submit3").submit();
		}
	}
}

/**
 * 
 * 
 * @param 
 * @returns true if all the checks functions return true 
 * @returns false if one of the function 'check' return false
 */

function validateRicerca(){
	var ricerca=document.getElementById("title");
	if(checkRicerca(ricerca)){
		document.getElementById("ricerca").submit();
	}
}
/**
 * 
 * 
 * @param 
 * @returns true if all the checks functions return true 
 * @returns false if one of the function 'check' return false
 */
function validateFiltro(){
	var filtro=document.getElementById("filtro");
	if(checkFiltro(filtro)){
		document.getElementById("filtrosubmit").submit();
	}
}


